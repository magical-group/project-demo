package DB;

// 导入sqlitejdbc-v056.jar
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import txt.CTxtHelp;

public class CDBHelper {
    static String dataPath = "";
    static String dataName = "Data.db3";
    static String dataDir = System.getProperty("user.dir") + File.separator + "soft" + File.separator;
    static Connection connection;
    static Lock instanceLock = new ReentrantLock();// 加锁
    
    public CDBHelper() {
        dataPath = dataDir + dataName;
    }

    private static class DBStoreHolder {
        private static final CDBHelper instance = new CDBHelper();
    }

    public static CDBHelper getInstance() {
        return DBStoreHolder.instance;
    }

    public synchronized String Init() {
        File dbDir = new File(dataDir);

        if (!dbDir.exists()) {
            dbDir.mkdirs();
        }
        
        File dbFile = new File(dataPath);

        if (!dbFile.exists()) {
            return "数据库文件不存在" + dataName;
        }
        
        try { Class.forName("org.sqlite.JDBC"); } catch (ClassNotFoundException ex) { CTxtHelp.AppendLog("[Error] [CDBHelper]<Init>:" + ex.getMessage()); }

        try {
            connection = DriverManager.getConnection("jdbc:sqlite:" + dataPath);
            connection.setAutoCommit(true);
        } 
        catch (SQLException e) {
            return "数据库连接错误" + dataName;
        }
        
        return "";
    }

    public int Execute(String sql) {
    	int result = 0;
        
        instanceLock.lock();
        
        try {
            sql = sql + ";";
            
            try {
                Statement statement = connection.createStatement();
                result = statement.executeUpdate(sql);
            } 
            catch (SQLException e) {
                CTxtHelp.AppendLog("[Error] Execute,Message=" + e.getMessage());
            }
            
            if (result == 0) {
                CTxtHelp.AppendLog("[DB] Execute,result==0,sql=" + sql);
            }
        } finally {
            instanceLock.unlock();
        }

        return result;
    }

    public QueryEntity Query(String sql) {
        QueryEntity entity = new QueryEntity();
        
        instanceLock.lock();
        
        try {
            sql = sql + ";";
            
            try {
                ResultSet result = null;
                Statement statement = connection.createStatement();
                statement.setQueryTimeout(30);
                result = statement.executeQuery(sql); 

                if (null != result) 
                {
                    if (result.isBeforeFirst()) 
                    {
                        entity.hasData = true;
                        entity.dataStmt = statement;
                        entity.dataRs = result;
                    }
                    else 
                    {
                        result.close();
                        statement.close();
                    }
                }
                else
                {
                    statement.close();
                }
            } 
            catch (SQLException e) {
                CTxtHelp.AppendLog("[Error] Query,Message=" + e.getMessage() + ",sql:" + sql);
            }
        } 
        finally {
            instanceLock.unlock();
        }

        return entity;
    }
    
    public QueryEntity QueryWithCount(String sql) {
        QueryEntity entity = new QueryEntity();
        
        instanceLock.lock();
        
        try {
            sql = sql + ";";
            
            try {
                ResultSet result = null;
                Statement statement = connection.createStatement();
                statement.setQueryTimeout(30);
                result = statement.executeQuery(sql); 

                if (null != result) 
                {
                    int rowcount = 0;
                    while (result.next()) rowcount++;
                    
                    if (0 != rowcount) 
                    {
                        result = statement.executeQuery(sql); 
                        entity.hasData = true;
                        entity.rowCount = rowcount;
                        entity.dataStmt = statement;
                        entity.dataRs = result;
                    }
                    else 
                    {
                        result.close();
                        statement.close();
                    }
                }
                else
                {
                    statement.close();
                }
            } 
            catch (SQLException e) {
                CTxtHelp.AppendLog("[Error] Query,Message=" + e.getMessage() + ",sql:" + sql);
            }
        } 
        finally {
            instanceLock.unlock();
        }

        return entity;
    }
    
    public void closeQuery(QueryEntity entity) {
        instanceLock.lock();
        try {
            if(entity.dataRs != null) entity.dataRs.close();
            if(entity.dataStmt != null) entity.dataStmt.close();
        } 
        catch (SQLException e) {
            CTxtHelp.AppendLog("[Error] closeQuery,Message=" + e.getMessage());
        }
        finally {
            instanceLock.unlock();
        }
    }
    
    public void close() {
        try {
            if(connection != null && !connection.isClosed()) {
            	connection.close();
            }
        } 
        catch (SQLException e) {
        }
    }
}

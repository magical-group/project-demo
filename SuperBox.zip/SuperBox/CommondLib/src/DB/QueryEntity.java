package DB;

import java.sql.ResultSet;
import java.sql.Statement;

public class QueryEntity {
    public boolean hasData = false;
    public int rowCount = 0;
    public Statement dataStmt = null;
    public ResultSet dataRs = null;
}

package encryption;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;  
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;  
import javax.crypto.spec.SecretKeySpec;  

public class SecurityHelper {
	
    // DES
    public static String key = "auaspp01";
    private static byte[] iv = { 0x61, 0x75, 0x61, 0x73, 0x70, 0x70, 0x30, 0x31 };  

    public static String EncryptDES(String key, String input) 
    {  
        String ret = ""; byte[] encryptedData = null;
        IvParameterSpec zeroIv = new IvParameterSpec(iv);  
        SecretKeySpec keySpec = new SecretKeySpec(key.getBytes(), "DES");  
        try
        {
            Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");  
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, zeroIv);  
            encryptedData = cipher.doFinal(input.getBytes()); 
            ret = Base64.Encrypt(encryptedData);
        } catch (NoSuchAlgorithmException e1) {
        } catch (NoSuchPaddingException e1) {
        } catch (InvalidKeyException e) {
        } catch (InvalidAlgorithmParameterException e) {
        } catch (IllegalBlockSizeException e) {
        } catch (BadPaddingException e) {
        }  
        return ret;  
    }  

    public static String DecryptDES(String decryptKey, String decryptString) 
    {  
        String ret = ""; byte decryptedData[] = null;
        byte[] byteMi = Base64.Decrypt(decryptString);  
        IvParameterSpec zeroIv = new IvParameterSpec(iv);  
        SecretKeySpec key = new SecretKeySpec(decryptKey.getBytes(), "DES");  
        try {
                Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");  
                cipher.init(Cipher.DECRYPT_MODE, key, zeroIv);  
                decryptedData = cipher.doFinal(byteMi); 
                ret = new String(decryptedData); 
        } catch (NoSuchAlgorithmException e) {
        } catch (NoSuchPaddingException e) {
        } catch (InvalidKeyException e) {
        } catch (InvalidAlgorithmParameterException e) {
        } catch (IllegalBlockSizeException e) {
        } catch (BadPaddingException e) {
        } 	
        return ret;  
    } 
}

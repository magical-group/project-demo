package func;

import DB.CDBHelper;

public class CCommondFunc {
    public static final int OffLine_Execute = 1;
    public static final int OffLine_Process = 52; 
        
    public static void AddRest_Execute(String strSql) {
        //CTxtHelp.AppendLog("[Info] [AddRest_Execute]:" + strSql);
        strSql = strSql.replace("'", "''");
        CDBHelper.getInstance().Execute("insert into tb_OffLineData (fi_Type,fs_Data) values (" + String.valueOf(OffLine_Execute) + ",'" + strSql + "')");
    }
 
    public static void AddRest_Process(String data) {
        CDBHelper.getInstance().Execute("insert into tb_OffLineData (fi_Type,fs_Data) values (" + String.valueOf(OffLine_Process) + ",'" + data + "')");
    }
    
    public static void SyncExecuteSql(String strSql) {
        CDBHelper.getInstance().Execute(strSql); 
        AddRest_Execute(strSql);// 同步更新到rest表
    }
}

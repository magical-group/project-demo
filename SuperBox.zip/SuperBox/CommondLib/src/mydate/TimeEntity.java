package mydate;

public class TimeEntity {
    public long TimeStamp = 0;
    public String TimeValue = "";
}

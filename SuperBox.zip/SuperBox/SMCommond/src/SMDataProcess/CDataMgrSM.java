package SMDataProcess;

public class CDataMgrSM {
    public static volatile boolean DoubleInput = true;// 单双输入

    public static volatile String Version = "";
    public static volatile int[] LockItemsLeft = null;
    public static volatile int[] LockItemsRight = null;
    public static volatile int[] SensorItemsLeft = null;
    public static volatile int[] SensorItemsRight = null;

    public static volatile int[] LockItemsLeft_Temp = null;
    public static volatile int[] LockItemsRight_Temp = null;
    public static volatile int[] SensorItemsLeft_Temp = null;
    public static volatile int[] SensorItemsRight_Temp = null;
    
    public static volatile boolean POWER = false;
    public static volatile boolean OpenBarCodeResult = false;
    public static volatile boolean CloseBarCodeResult = false;
    public static volatile String BarCodeValue = "";
    public static volatile String ICValue = "";
    public static volatile boolean ActivateKey = false;
    public static volatile boolean CloseKey = false;
    public static volatile byte KeyValue = 0;
    public static volatile boolean IsDebug = false;
    
    public static volatile boolean SetBoardTypeResult = false;// 设置层数结果
    public static volatile int HardBoardType = 8;
    
    public static void InitRelay(boolean isdouble, int count) {
        LockItemsLeft = new int[count];// 继电器序号,从1开始
        LockItemsRight = new int[count];

        for (int i = 0; i < LockItemsLeft.length; i++) {
            LockItemsLeft[i] = -1;
        }
        
        for (int i = 0; i < LockItemsRight.length; i++) {
            LockItemsRight[i] = -1;
        }
        
        if (isdouble) {
            // 双输入
            SensorItemsLeft = new int[count];
            SensorItemsRight = new int[count];

            for (int i = 0; i < SensorItemsLeft.length; i++) {
                SensorItemsLeft[i] = -1;
            }

            for (int i = 0; i < SensorItemsRight.length; i++) {
                SensorItemsRight[i] = -1;
            }
        }
    }
}

package SMDataProcess;

public class CErrorCode {
    public static int RunError = 1000;
    
    public static int ConnectionFails_Key = 1001; public static String ConnectionFails_Val = "the connection fails";   
    public static int RecvTimeOut_Key = 1002; public static String RecvTimeOut_Val = "receive a timeout";  
    public static int SideError_Key = 1003; public static String SideError_Val = "relay position error";  
    public static int RelayError1_Key = 1004; public static String RelayError1_Val = "more than the minimum number of relays"; 
    public static int RelayError2_Key = 1005; public static String RelayError2_Val = "more than the largest number of relays";
}

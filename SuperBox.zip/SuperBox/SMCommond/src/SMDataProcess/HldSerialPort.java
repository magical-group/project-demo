package SMDataProcess;

import java.util.List;
import SMProtocol.CSPDAO;
import txt.CTxtHelp;

public class HldSerialPort {
    static CSPDAO m_spDao;
    static CDeviceDAO m_deviceDao;
    public static volatile boolean m_bExit = false;
    public static volatile boolean m_bConnection = false;
    Thread thdAskRelay = null;
    
    public List<String> GetPortNames() {
        return CSPDAO.GetPortNames();
    }

    // 查询箱柜信息(轮询)
    class AskRelayThread implements Runnable {
        @Override
        public void run() {
            StringBuffer strMsg = new StringBuffer();
            while (!m_bExit) {
                try { 
                    if (!CDeviceDAO.WhenOpenStopQuery) m_deviceDao.ReadBoxLeft(strMsg); try { Thread.sleep(1000); }  catch (InterruptedException e)  {}
                    if (!CDeviceDAO.WhenOpenStopQuery) m_deviceDao.ReadBoxRight(strMsg); try { Thread.sleep(1000); }  catch (InterruptedException e)  {}
                    if (!CDeviceDAO.WhenOpenStopQuery) m_deviceDao.ReadPower(strMsg); try { Thread.sleep(1000); }  catch (InterruptedException e)  {}
                } 
                catch (Exception ex) {
                    if (null != m_spDao) m_spDao.SetErrorCode(strMsg, SMDataProcess.CErrorCode.RunError, "<AskRelayThread> msg:" + ex.getMessage());
                }

                try { Thread.sleep(300); }  catch (InterruptedException e)  {}
            }
        }
    }

    // 打开串口
    public boolean OpenSerialPort(String strPortName, int iBaudRate, StringBuffer strMsg) {
        m_bExit = false; m_bConnection = false;
        m_spDao = new CSPDAO(new CProtocolHandle1());
        m_deviceDao = new CDeviceDAO(m_spDao);
        boolean ret = m_spDao.BeginWork(strPortName, iBaudRate, 0, 8, 1, strMsg);
        if (ret) {
            m_bConnection = true;
        }
        
        return ret;
    }
    
    public boolean ReadBoxLeft(StringBuffer strMsg) {
        return m_deviceDao.ReadBoxLeft(strMsg);
    }
    
    public boolean ReadBoxRight(StringBuffer strMsg) {
        return m_deviceDao.ReadBoxRight(strMsg);
    }
    
    public void ReadPower(StringBuffer strMsg) {
        m_deviceDao.ReadPower(strMsg);
    }
    
    public void StartAskRelayThread() {
        if (null == thdAskRelay) {
            thdAskRelay = new Thread(new AskRelayThread());
            thdAskRelay.start();
        }
    }
    
    // 关闭串口
    public boolean CloseSerialPort(StringBuffer strMsg) {
        if (!CheckConnection(strMsg)) return false;
        
        m_bExit = true;
        m_bConnection = false;
        return m_spDao.EndWork();
    }
    
    // 获取设备版本
    public String GetVersion(StringBuffer strMsg) {
        if (!CheckConnection(strMsg)) return null;
        
        return m_deviceDao.GetVersion(strMsg);
    }
    
   
    // 获取所有箱柜的锁状态(返回内存值)
    public int[] GetLockAllStatus(int side, StringBuffer strMsg) {
        if (!CheckSide(side, strMsg))  return null; 
        if (!CheckConnection(strMsg)) return null;
        
        int len = 0;
        if (0 == side) {
            if (null != CDataMgrSM.LockItemsLeft) {
                len = CDataMgrSM.LockItemsLeft.length;
                if (null == CDataMgrSM.LockItemsLeft_Temp) CDataMgrSM.LockItemsLeft_Temp = new int[len];
                System.arraycopy(CDataMgrSM.LockItemsLeft, 0, CDataMgrSM.LockItemsLeft_Temp, 0, len);
                return CDataMgrSM.LockItemsLeft_Temp;// 只数据拷贝
            }
        }
        else if (1 == side) {
            if (null != CDataMgrSM.LockItemsRight) {
                len = CDataMgrSM.LockItemsRight.length;
                if (null == CDataMgrSM.LockItemsRight_Temp) CDataMgrSM.LockItemsRight_Temp = new int[len];
                System.arraycopy(CDataMgrSM.LockItemsRight, 0, CDataMgrSM.LockItemsRight_Temp, 0, len);
                return CDataMgrSM.LockItemsRight_Temp;// 只数据拷贝
            }
        }
        
        return null;
    }

    // 获取所有箱柜的传感器状态
    public int[] GetSensorAllStatus(int side, StringBuffer strMsg) {
        if (!CheckSide(side, strMsg)) return null;
        if (!CheckConnection(strMsg)) return null;

        int len = 0;
        if (0 == side) {
            if (null != CDataMgrSM.SensorItemsLeft) {
                len = CDataMgrSM.SensorItemsLeft.length;
                if (null == CDataMgrSM.SensorItemsLeft_Temp) CDataMgrSM.SensorItemsLeft_Temp = new int[len];
                System.arraycopy(CDataMgrSM.SensorItemsLeft, 0, CDataMgrSM.SensorItemsLeft_Temp, 0, len);
                return CDataMgrSM.SensorItemsLeft_Temp;// 只数据拷贝
            }
        }
        else if (1 == side) {
            if (null != CDataMgrSM.SensorItemsRight) {
                len = CDataMgrSM.SensorItemsRight.length;
                if (null == CDataMgrSM.SensorItemsRight_Temp) CDataMgrSM.SensorItemsRight_Temp = new int[len];
                System.arraycopy(CDataMgrSM.SensorItemsRight, 0, CDataMgrSM.SensorItemsRight_Temp, 0, len);
                return CDataMgrSM.SensorItemsRight_Temp;// 只数据拷贝
            }
        }
        
        return null;
    }
    
    // 获取指定箱柜的锁状态
    public int GetLockStatus(int side, int relay, StringBuffer strMsg) {
        if (!CheckSide(side, strMsg)) return -1;
        if (!CheckRelayId(relay, strMsg)) return -1;
        if (!CheckConnection(strMsg)) return -1;
        
        int ret = -1;
        
        switch (side) {
            case 0: if (null != CDataMgrSM.LockItemsLeft && relay <= CDataMgrSM.LockItemsLeft.length) ret = CDataMgrSM.LockItemsLeft[relay]; break;
            case 1: if (null != CDataMgrSM.LockItemsRight && relay <= CDataMgrSM.LockItemsRight.length) ret = CDataMgrSM.LockItemsRight[relay]; break;
        }
        
        return ret;
    }

    // 获取所有箱柜的传感器状态
    public int GetSensorStatus(int side, int relay, StringBuffer strMsg) {
        if (!CheckSide(side, strMsg)) return -1;
        if (!CheckRelayId(relay, strMsg)) return -1;
        if (!CheckConnection(strMsg)) return -1;
        
        int ret = -1;
        
        switch (side) {
            case 0: if (null != CDataMgrSM.SensorItemsLeft && relay <= CDataMgrSM.SensorItemsLeft.length) ret = CDataMgrSM.SensorItemsLeft[relay]; break;
            case 1: if (null != CDataMgrSM.SensorItemsRight && relay <= CDataMgrSM.SensorItemsLeft.length) ret = CDataMgrSM.SensorItemsRight[relay]; break;
        }
        
        return ret;
    }
    
    // 打开指定箱柜
    public boolean OpenLock(int side, int relay, StringBuffer strMsg) {
        if (!CheckSide(side, strMsg)) return false;
        if (!CheckRelayId(relay, strMsg)) return false;
        if (!CheckConnection(strMsg)) return false;
        
        boolean ret = m_deviceDao.OpenTerminalBox(side, relay, strMsg);
        CTxtHelp.AppendLog("[Result] OpenBox -> side:" + side + ",relay:" + relay + ",lock:" + ret + ",sensor:" + GetSensorStatus(side, relay, strMsg));
        return ret;
    }

    public boolean GetPowerStatus(StringBuffer strMsg) {
        return CDataMgrSM.POWER;
    }

    public boolean SetCoderWakeup(StringBuffer strMsg) {
        if (!CheckConnection(strMsg)) return false;
        
        return m_deviceDao.OpenBarCode(strMsg);
    }
    
    public boolean SetCoderSleep(StringBuffer strMsg) {
        if (!CheckConnection(strMsg)) return false;
        
        return m_deviceDao.CloseBarCode(strMsg);
    }
    
    public boolean SetBoardType(int boardtype, StringBuffer strMsg) {
        if (!CheckConnection(strMsg)) return false;
 
        return m_deviceDao.SetBoardType(boardtype, strMsg);
    }
    
    public int ReadBoardType(StringBuffer strMsg) {
        if (!CheckConnection(strMsg)) return 0;
        
        return m_deviceDao.ReadBoardType(strMsg);
    }
    
    public String GetCoderTextData() {
        String ret = "";
        if (!"".equals(CDataMgrSM.BarCodeValue)) {
            ret = CDataMgrSM.BarCodeValue;
            CDataMgrSM.BarCodeValue = "";
        }
        
        return ret;
    }
    
    public String GetICCardData() {
        String ret = CDataMgrSM.ICValue;
        
        if (!"".equals(ret))  CDataMgrSM.ICValue = "";
        
        return ret;
    }
    
    public void SetDebug(boolean flg) {
        CDataMgrSM.IsDebug = flg;
    }

    public String GetAPIInfo() {
        String input = "SingleInput";
        if (CDataMgrSM.DoubleInput) input = "DoubleInput";
        
        return "HLD_" + String.valueOf(input);
    }
    
    boolean CheckSide(int side, StringBuffer strMsg) {
        boolean ret = false;
        
        if (0 != side && 1 != side) {
            m_spDao.SetErrorCode(strMsg, SMDataProcess.CErrorCode.SideError_Key, SMDataProcess.CErrorCode.SideError_Val);
        }
        else {
            ret = true;
        }

        return ret;
    }
    
    boolean CheckRelayId(int relay, StringBuffer strMsg) {
        boolean ret = false;
        
        if (relay <= 0)
            m_spDao.SetErrorCode(strMsg, SMDataProcess.CErrorCode.RelayError1_Key, SMDataProcess.CErrorCode.RelayError1_Val);
        else {
            int max = CDataMgrSM.DoubleInput ? 152 : 304;
            if (relay > max) {
                m_spDao.SetErrorCode(strMsg, SMDataProcess.CErrorCode.RelayError2_Key, SMDataProcess.CErrorCode.RelayError2_Val);
            }
            else {
                ret = true;
            }
        }
        
        return ret;
    }
    
    boolean CheckConnection(StringBuffer strMsg) {
        if (!m_bConnection) {
            strMsg.append(String.valueOf(SMDataProcess.CErrorCode.ConnectionFails_Key)).append(" (").append(SMDataProcess.CErrorCode.ConnectionFails_Val).append(")");
            return false;
        }
        
        return true;
    }
}
package SMProtocol;

import gnu.io.CommPortIdentifier;
import gnu.io.PortInUseException;
import gnu.io.SerialPort;
import gnu.io.UnsupportedCommOperationException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import txt.CTxtHelp;

public class CSPDAO {
    SerialPort m_serialPort;
    CByteBuffer m_bbRecv;
    IProtocolHandle m_oHandle;
    String m_sn;
    volatile byte m_cmd;
    volatile int m_waitIndex;
    volatile boolean m_processEnd;
    String m_errorCode;// -1:串口异常;0:正常;1:超时;2:连接断开;3:找不到继电器号
    boolean m_bExit;
    StringBuffer m_strMsg = new StringBuffer();
    
    public CSPDAO(IProtocolHandle oHandle)
    {
        m_oHandle = oHandle;
    }

    // 获取可用端口
    public static List<String> GetPortNames() 
    {
        List<String> lstRet = new ArrayList<String>();
        CommPortIdentifier portId;
        Enumeration<?> en = CommPortIdentifier.getPortIdentifiers();
        while (en.hasMoreElements()) 
        {
            portId = (CommPortIdentifier) en.nextElement();
            if (portId.getPortType() == CommPortIdentifier.PORT_SERIAL) 
            {
                lstRet.add(portId.getName());
            }
        }

        return lstRet;
    }

    public boolean BeginWork(String strPortName, int iBaudRate, int iParity, int iDataBits, int iStopBits, StringBuffer strMsg)
    {
        m_sn = strPortName;
        m_strMsg.delete(0, m_strMsg.length());
        
        boolean bRet = false;

        try 
        {
            CommPortIdentifier portId = CommPortIdentifier.getPortIdentifier(strPortName);
            bRet = ConfitSerial(portId, iBaudRate, iParity, iDataBits, iStopBits, strMsg);
        }
        catch (Exception ex)
        {
            SetErrorCode(strMsg, SMDataProcess.CErrorCode.RunError, "<InitPort> msg:" + ex.getMessage());
            return false;
        }

        if (bRet)
        {
            m_waitIndex = 0;
            m_errorCode = "";
            m_bExit = false;
            m_processEnd = false;

            m_bbRecv = new CByteBuffer();
            m_oHandle.ProtState(m_sn, bRet);

            // 接收线程开启	 
           (new Thread(new ReadThread(m_serialPort))).start();
        }

        return bRet;
    }

    public boolean EndWork()
    {
        if (m_bExit) return false;
        m_bExit = true;

        m_bbRecv = null;
        m_serialPort.close();
        m_serialPort = null;

        m_oHandle.ProtState(m_sn, false);

        return true;
    }
    
    /*设置串口通讯参数：波特率、数据位、停止位、奇偶校验*/
    boolean ConfitSerial(CommPortIdentifier portId, int iBaudRate, int iParity, int iDataBits, int iStopBits, StringBuffer strMsg)
    {
        try 
        {
            m_serialPort = (SerialPort) portId.open("ReadComm", 2000);//设置串口监听器
            m_serialPort.enableReceiveTimeout(1000);// 设置读取超时时间
            m_serialPort.notifyOnDataAvailable(true);
            m_serialPort.setSerialPortParams(iBaudRate, iDataBits, iStopBits, iParity);
        } 
        catch (PortInUseException | UnsupportedCommOperationException ex) 
        {
            SetErrorCode(strMsg, SMDataProcess.CErrorCode.RunError, "<ConfitSerial> msg:" + ex.getMessage());
            return false;
        }

        return true;
    }

    // 读取串口数据线程
    class ReadThread implements Runnable
    {
        public SerialPort m_serialPort;

        public ReadThread(SerialPort serialPort)
        {
            m_serialPort = serialPort;
        }

        @Override
        public void run()
        {
            InputStream inputStream = null;
            byte[] readBuffer = new byte[4049];
            
            while (!m_bExit)
            {
                try 
                { 
                    inputStream = m_serialPort.getInputStream();

                    int iSize = inputStream.read(readBuffer); 
                    //System.out.println("Recv:" + CCommondFunc.ToHexString(readBuffer, iSize));	
                    //CTxtHelp.AppendLog("[Info] [CSPDAO]<recv>:" + CCommondFunc.ToHexString(readBuffer, iSize));
                    if (iSize > 0) {
                        m_bbRecv.Put(readBuffer, 0, iSize);
                        m_processEnd = m_oHandle.Process(m_sn, m_cmd, m_bbRecv);  
                    }
                } 
                catch (IOException ex)
                {
                    SetErrorCode(m_strMsg, SMDataProcess.CErrorCode.RunError, "<Recv> cmd:" + m_cmd + ",msg:" + ex.getMessage());
                }
                
                try { Thread.sleep(10); }  catch (InterruptedException e)  {}
            }
        }
    }

    public int Send(byte cmd, byte[] writeBuffer, int waittime, StringBuffer strMsg)
    {
        int ret = -1;
        
        synchronized(this) {
            ClearData();
            m_cmd = cmd;

            if (m_bExit)  {
                SetErrorCode(strMsg, SMDataProcess.CErrorCode.ConnectionFails_Key, SMDataProcess.CErrorCode.ConnectionFails_Val);
            }
            else {
                try {
                    m_serialPort.notifyOnOutputEmpty(true);
                    m_bbRecv.Clear();
                    
                    OutputStream outputStream = m_serialPort.getOutputStream();
                    outputStream.write(writeBuffer, 0, writeBuffer.length);
                    outputStream.flush();

                    while ((m_waitIndex++) <= (waittime * 10)) {
                        try { Thread.sleep(100); }  catch (InterruptedException e)  {}
                        
                        if (m_processEnd) break;
                    }
                    
                    if (!m_processEnd) {
                        SetErrorCode(strMsg, SMDataProcess.CErrorCode.RecvTimeOut_Key, SMDataProcess.CErrorCode.RecvTimeOut_Val);
                    }
                    else {
                        ret = 0;
                    }
                } 
                catch (IOException ex) 
                {
                    SetErrorCode(strMsg, SMDataProcess.CErrorCode.RunError, "<Send> cmd:" + cmd + ",msg:" + ex.getMessage());
                }
                
                ClearData();
            }
        }
        
        return ret;
    }
    
    void ClearData() 
    {
        m_waitIndex = 1;
        m_cmd = -1;
        m_processEnd = false;
        m_oHandle.ClearData();
    }
    
    public void SetErrorCode(StringBuffer strMsg, int code, String content)
    {
        m_errorCode = String.valueOf(code) + " (" + content + ",cmd:" + m_cmd + ")";
        if (null == strMsg) 
            strMsg = new StringBuffer();
        else
            strMsg.delete(0, strMsg.length());
        strMsg.append(m_errorCode);
        CTxtHelp.AppendLog("[Error] " + m_errorCode);
        ClearData();
    }
    
    public String GetLastError()
    {
        return m_errorCode;
    }
}

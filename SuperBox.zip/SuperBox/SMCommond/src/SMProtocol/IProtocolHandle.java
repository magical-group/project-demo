package SMProtocol;

public interface IProtocolHandle {
    void ProtState(String sn, boolean blRun);
    void ClearData();
    boolean Process(String sn, int cmd, CByteBuffer bBuffer);
}

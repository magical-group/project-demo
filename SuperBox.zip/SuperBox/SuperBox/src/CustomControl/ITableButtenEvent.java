package CustomControl;

import java.awt.event.ActionEvent;

public interface ITableButtenEvent {
    void invoke(ActionEvent e);
}
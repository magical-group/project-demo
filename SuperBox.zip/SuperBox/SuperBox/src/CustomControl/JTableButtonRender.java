package CustomControl;
 
import java.awt.Component;
 
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;
 
public class JTableButtonRender implements TableCellRenderer
{
    private JButton button;
 
    public JTableButtonRender()
    {
        button = new JButton();
        button.setBounds(0, 0, 100, 50);
    }
 
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
    {
        button.setText(value == null ? "" : String.valueOf(value));
        return button;
    }
}
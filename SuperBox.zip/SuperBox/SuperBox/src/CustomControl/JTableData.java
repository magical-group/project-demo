package CustomControl;

import DB.CDBHelper;
import DB.QueryEntity;
import java.awt.Dimension;
import java.awt.Font;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
//import sun.swing.table.DefaultTableCellHeaderRenderer;
import txt.CTxtHelp;

public class JTableData {
    
    public static void initTable(JTable tableData, int headHeight) {
        // 设置表头行高及字体
        JTableHeader head = tableData.getTableHeader();  
        head.setPreferredSize(new Dimension(head.getWidth(), 35));
        head.setFont(new Font("微软雅黑", Font.PLAIN, 18));// 设置表格字体
        tableData.setRowHeight(headHeight);//设置行高
         // 设置表头居中
//        DefaultTableCellHeaderRenderer thr = new DefaultTableCellHeaderRenderer();
//        thr.setHorizontalAlignment(JLabel.CENTER);
//        tableData.getTableHeader().setDefaultRenderer(thr);
        // 设置内容居中
        DefaultTableCellRenderer tcr = new DefaultTableCellRenderer();
        tcr.setHorizontalAlignment(JLabel.CENTER);
        tableData.setDefaultRenderer(Object.class, tcr);
        //
        tableData.setRowSelectionAllowed(false);
    }
       
    /** 把结果集转成Object[][]
     * @param result */
    public static Object[][] resultSetToObjectArray(QueryEntity result, String addcolunm) {
        Object[][] data = null;
        int rows = result.rowCount;
        ResultSet rs = result.dataRs;;
        try {	
            data = new Object[rows][];  
            ResultSetMetaData md = rs.getMetaData();//获取记录集的元数据
            int columnCount = md.getColumnCount();//列数
            int row = 0;
            while(rs.next()) {
                int tempCount = "".equals(addcolunm) ? columnCount : columnCount + 1;
                Object[] col = new Object[tempCount];
                for(int i = 0; i < columnCount; i++) {
                    Object obj = rs.getObject(i + 1);
                    col[i] = obj == null ? "" : obj.toString();
                }
                if (!"".equals(addcolunm))
                {
                    col[tempCount - 1] = addcolunm;
                }
                data[row] = col;
                row++;
            }
        } catch (Exception e) {
            CTxtHelp.AppendLog("[Error] resultSetToObjectArray,errmsg:" + e.getMessage());
        }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        return data;
    }
    
    public static void setData(JTable tableData, Object[][] rowData, String[] columnNames, final int columnIndex, ITableButtenEvent event)
    { 
        tableData.setModel(new DefaultTableModel(rowData, columnNames){
            @Override
            public boolean isCellEditable(int row, int column)
            {
                return column == columnIndex;
            }
        });
        tableData.getColumnModel().getColumn(columnIndex).setCellEditor(new JTableButtonEditor(event));
        tableData.getColumnModel().getColumn(columnIndex).setCellRenderer(new JTableButtonRender());
    }
}

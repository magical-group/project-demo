package CustomControl;

import FuncClass.CDataMgr;
import javax.swing.JTextField;
import static UI.CBaseEnum.KeyType.Key_TEXTBOX_FORCECHANGE;

public class TextBoxInput extends javax.swing.JPanel {

    int tabIndex = 1;
    int maxLength = 0;
    String m_strInputText = "";
    private int m_nCurSection = 0;
    
    public TextBoxInput() {
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtInput = new javax.swing.JTextField();

        txtInput.setFont(new java.awt.Font("微软雅黑", 0, 36)); // NOI18N
        txtInput.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtInputMouseClicked(evt);
            }
        });
        txtInput.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtInputFocusGained(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(txtInput, javax.swing.GroupLayout.DEFAULT_SIZE, 330, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(txtInput, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void txtInputFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtInputFocusGained
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_TEXTBOX_FORCECHANGE, String.valueOf(tabIndex));
    }//GEN-LAST:event_txtInputFocusGained

    private void txtInputMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtInputMouseClicked
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_TEXTBOX_FORCECHANGE, String.valueOf(tabIndex));
    }//GEN-LAST:event_txtInputMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField txtInput;
    // End of variables declaration//GEN-END:variables

    public void Clear() {
        m_strInputText = "";
        txtInput.setText("");
    }
    
    public void SetDefaultValue(String val) {
        m_strInputText = val;
        txtInput.setText(m_strInputText);
    }
    
    public void SetTextBox(int index, int len) {
        tabIndex = index;
        maxLength = len;
        //txtInput.setEditable(false);
        SetCenter();
    }

    public String GetText() {
        return txtInput.getText();
    }
    
    public void SetCenter() {
        txtInput.setHorizontalAlignment(JTextField.CENTER);
    }
    
    public int GetMaxLen() {
        return maxLength;
    }
    
    public void SetCursor() {
        txtInput.requestFocus();
    }
    
    public void InputText(String strChar){
        m_strInputText = txtInput.getText();// 当期数据重新赋值// 键盘输入123，再将关标切到3之前，使用软键盘上的删除，报错,解决方法：判断长度是否一致，不一致时重新赋值
        
        m_nCurSection = txtInput.getCaretPosition();
        
        if ("SPACE".equals(strChar)) {
            if (m_nCurSection != txtInput.getText().length()) {
                // 中间位置删除
                if (0 != m_nCurSection) {
                    String strLeft = m_strInputText.substring(0, m_nCurSection - 1);
                    String strRight = m_strInputText.substring(m_nCurSection);
                    m_strInputText = strLeft + strRight;
                    if (m_nCurSection > 0) m_nCurSection -= 1;
                }
            }
            else {
                if (m_strInputText.length() > 0) {
                    m_strInputText = m_strInputText.substring(0, m_strInputText.length() - 1);
                    m_nCurSection = m_strInputText.length();
                }
            }
        }
        else {
            // 插入
            if (maxLength == m_strInputText.length()) {
                return;
            }
            
            if (m_nCurSection != txtInput.getText().length()) {
                // 中间位置插入
                String strLeft = m_strInputText.substring(0, m_nCurSection) + strChar;
                String strRight = m_strInputText.substring(m_nCurSection);
                m_strInputText = strLeft + strRight;
                m_nCurSection += 1;
            }
            else {
                m_strInputText += strChar;
                m_nCurSection = m_strInputText.length();
            }
        }
        txtInput.setText(m_strInputText);
        txtInput.setCaretPosition(m_nCurSection);// 重新赋值光标位置
    }
}

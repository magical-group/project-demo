package CustomControl;

import FuncClass.CDataMgr;
import UI.CBaseEnum;
import static UI.CBaseEnum.KeyType.Key_ENTER;
import static UI.CBaseEnum.KeyType.Key_NUMBER;
import static UI.CBaseEnum.KeyType.Key_SPACE;

public class ZFKeyPad extends javax.swing.JPanel {

    public ZFKeyPad() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnChrItem2 = new javax.swing.JButton();
        btnChrItem1 = new javax.swing.JButton();
        btnChrItem3 = new javax.swing.JButton();
        btnChrItem4 = new javax.swing.JButton();
        btnChrItem5 = new javax.swing.JButton();
        btnChrItem6 = new javax.swing.JButton();
        btnChrItem7 = new javax.swing.JButton();
        btnChrItem8 = new javax.swing.JButton();
        btnChrItem9 = new javax.swing.JButton();
        btnSpace = new javax.swing.JButton();
        btnChrItem10 = new javax.swing.JButton();
        btnChrItem11 = new javax.swing.JButton();
        btnChrItem12 = new javax.swing.JButton();
        btnChrItem13 = new javax.swing.JButton();
        btnChrItem14 = new javax.swing.JButton();
        btnChrItem15 = new javax.swing.JButton();
        btnChrItem16 = new javax.swing.JButton();
        btnChrItem17 = new javax.swing.JButton();
        btnChrItem18 = new javax.swing.JButton();
        btnChrItem19 = new javax.swing.JButton();
        btnChrItem20 = new javax.swing.JButton();
        btnChrItem21 = new javax.swing.JButton();
        btnChrItem22 = new javax.swing.JButton();
        btnChrItem23 = new javax.swing.JButton();
        btnChrItem24 = new javax.swing.JButton();
        btnChrItem25 = new javax.swing.JButton();
        btnChrItem26 = new javax.swing.JButton();
        btnChrItem27 = new javax.swing.JButton();
        btnChrItem28 = new javax.swing.JButton();
        btnChrItem29 = new javax.swing.JButton();
        btnChrItem30 = new javax.swing.JButton();
        btnChrItem31 = new javax.swing.JButton();
        btnChrItem32 = new javax.swing.JButton();
        btnChrItem33 = new javax.swing.JButton();
        btnABC = new javax.swing.JButton();
        btnChrEnter = new javax.swing.JButton();

        setBackground(new java.awt.Color(18, 89, 145));

        btnChrItem2.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItem2.setText("\"");
        btnChrItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrItem2ActionPerformed(evt);
            }
        });

        btnChrItem1.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItem1.setText("!");
        btnChrItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrItem1ActionPerformed(evt);
            }
        });

        btnChrItem3.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItem3.setText("#");
        btnChrItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrItem3ActionPerformed(evt);
            }
        });

        btnChrItem4.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItem4.setText("$");
        btnChrItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrItem4ActionPerformed(evt);
            }
        });

        btnChrItem5.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItem5.setText("%");
        btnChrItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrItem5ActionPerformed(evt);
            }
        });

        btnChrItem6.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItem6.setText("&");
        btnChrItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrItem6ActionPerformed(evt);
            }
        });

        btnChrItem7.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItem7.setText("'");
        btnChrItem7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrItem7ActionPerformed(evt);
            }
        });

        btnChrItem8.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItem8.setText("(");
        btnChrItem8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrItem8ActionPerformed(evt);
            }
        });

        btnChrItem9.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItem9.setText(")");
        btnChrItem9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrItem9ActionPerformed(evt);
            }
        });

        btnSpace.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnSpace.setText("删除");
        btnSpace.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSpaceActionPerformed(evt);
            }
        });

        btnChrItem10.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItem10.setText("*");
        btnChrItem10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrItem10ActionPerformed(evt);
            }
        });

        btnChrItem11.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItem11.setText("+");
        btnChrItem11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrItem11ActionPerformed(evt);
            }
        });

        btnChrItem12.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItem12.setText(".");
        btnChrItem12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrItem12ActionPerformed(evt);
            }
        });

        btnChrItem13.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItem13.setText(",");
        btnChrItem13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrItem13ActionPerformed(evt);
            }
        });

        btnChrItem14.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItem14.setText("-");
        btnChrItem14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrItem14ActionPerformed(evt);
            }
        });

        btnChrItem15.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItem15.setText("/");
        btnChrItem15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrItem15ActionPerformed(evt);
            }
        });

        btnChrItem16.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItem16.setText(":");
        btnChrItem16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrItem16ActionPerformed(evt);
            }
        });

        btnChrItem17.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItem17.setText(";");
        btnChrItem17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrItem17ActionPerformed(evt);
            }
        });

        btnChrItem18.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItem18.setText("<");
        btnChrItem18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrItem18ActionPerformed(evt);
            }
        });

        btnChrItem19.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItem19.setText("=");
        btnChrItem19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrItem19ActionPerformed(evt);
            }
        });

        btnChrItem20.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItem20.setText(">");
        btnChrItem20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrItem20ActionPerformed(evt);
            }
        });

        btnChrItem21.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItem21.setText("?");
        btnChrItem21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrItem21ActionPerformed(evt);
            }
        });

        btnChrItem22.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItem22.setText("@");
        btnChrItem22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrItem22ActionPerformed(evt);
            }
        });

        btnChrItem23.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItem23.setText("[");
        btnChrItem23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrItem23ActionPerformed(evt);
            }
        });

        btnChrItem24.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItem24.setText("\\");
            btnChrItem24.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    btnChrItem24ActionPerformed(evt);
                }
            });

            btnChrItem25.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
            btnChrItem25.setText("]");
            btnChrItem25.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    btnChrItem25ActionPerformed(evt);
                }
            });

            btnChrItem26.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
            btnChrItem26.setText("^");
            btnChrItem26.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    btnChrItem26ActionPerformed(evt);
                }
            });

            btnChrItem27.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
            btnChrItem27.setText("_");
            btnChrItem27.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    btnChrItem27ActionPerformed(evt);
                }
            });

            btnChrItem28.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
            btnChrItem28.setText("`");
            btnChrItem28.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    btnChrItem28ActionPerformed(evt);
                }
            });

            btnChrItem29.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
            btnChrItem29.setText("{");
            btnChrItem29.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    btnChrItem29ActionPerformed(evt);
                }
            });

            btnChrItem30.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
            btnChrItem30.setText("|");
            btnChrItem30.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    btnChrItem30ActionPerformed(evt);
                }
            });

            btnChrItem31.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
            btnChrItem31.setText("}");
            btnChrItem31.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    btnChrItem31ActionPerformed(evt);
                }
            });

            btnChrItem32.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
            btnChrItem32.setText("~");
            btnChrItem32.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    btnChrItem32ActionPerformed(evt);
                }
            });

            btnChrItem33.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
            btnChrItem33.setText(" ");
            btnChrItem33.setEnabled(false);
            btnChrItem33.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    btnChrItem33ActionPerformed(evt);
                }
            });

            btnABC.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
            btnABC.setText("ABC");
            btnABC.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    btnABCActionPerformed(evt);
                }
            });

            btnChrEnter.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
            btnChrEnter.setText("确定");
            btnChrEnter.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    btnChrEnterActionPerformed(evt);
                }
            });

            javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
            this.setLayout(layout);
            layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(57, 57, 57)
                            .addComponent(btnChrItem11, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnChrItem12, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnChrItem13, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnChrItem14, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnChrItem15, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnChrItem16, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnChrItem17, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnChrItem18, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnChrItem19, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnChrItem20, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(101, 101, 101)
                            .addComponent(btnChrItem21, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnChrItem22, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnChrItem23, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnChrItem24, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnChrItem25, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnChrItem26, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnChrItem27, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnChrItem28, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnChrItem29, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(144, 144, 144)
                                .addComponent(btnChrItem30, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnChrItem31, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnChrItem32, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnChrItem33, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnABC, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnChrEnter, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addComponent(btnChrItem1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnChrItem2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnChrItem3, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnChrItem4, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnChrItem5, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnChrItem6, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnChrItem7, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnChrItem8, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnChrItem9, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnChrItem10, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnSpace, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addContainerGap(21, Short.MAX_VALUE))
            );
            layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(29, 29, 29)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnChrItem2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem5, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem8, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem7, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnSpace, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem9, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem10, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnChrItem11, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem12, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem13, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem14, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem15, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem16, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem17, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem18, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem19, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem20, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnChrItem21, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem22, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem23, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem24, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem25, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem26, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem27, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem28, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItem29, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnABC, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnChrEnter, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnChrItem32, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnChrItem33, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnChrItem30, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnChrItem31, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addContainerGap(21, Short.MAX_VALUE))
            );
        }// </editor-fold>//GEN-END:initComponents

    private void btnChrItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem1ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem1.getText());
    }//GEN-LAST:event_btnChrItem1ActionPerformed

    private void btnChrItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem2ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem2.getText());
    }//GEN-LAST:event_btnChrItem2ActionPerformed

    private void btnChrItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem3ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem3.getText());
    }//GEN-LAST:event_btnChrItem3ActionPerformed

    private void btnChrItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem4ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem4.getText());
    }//GEN-LAST:event_btnChrItem4ActionPerformed

    private void btnChrItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem5ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem5.getText());
    }//GEN-LAST:event_btnChrItem5ActionPerformed

    private void btnChrItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem6ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem6.getText());
    }//GEN-LAST:event_btnChrItem6ActionPerformed

    private void btnChrItem7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem7ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem7.getText());
    }//GEN-LAST:event_btnChrItem7ActionPerformed

    private void btnChrItem8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem8ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem8.getText());
    }//GEN-LAST:event_btnChrItem8ActionPerformed

    private void btnChrItem9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem9ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem9.getText());
    }//GEN-LAST:event_btnChrItem9ActionPerformed

    private void btnChrItem10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem10ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem10.getText());
    }//GEN-LAST:event_btnChrItem10ActionPerformed

    private void btnChrItem11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem11ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem11.getText());
    }//GEN-LAST:event_btnChrItem11ActionPerformed

    private void btnChrItem12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem12ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem12.getText());
    }//GEN-LAST:event_btnChrItem12ActionPerformed

    private void btnChrItem13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem13ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem13.getText());
    }//GEN-LAST:event_btnChrItem13ActionPerformed

    private void btnChrItem14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem14ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem14.getText());
    }//GEN-LAST:event_btnChrItem14ActionPerformed

    private void btnChrItem15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem15ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem15.getText());
    }//GEN-LAST:event_btnChrItem15ActionPerformed

    private void btnChrItem16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem16ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem16.getText());
    }//GEN-LAST:event_btnChrItem16ActionPerformed

    private void btnChrItem17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem17ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem17.getText());
    }//GEN-LAST:event_btnChrItem17ActionPerformed

    private void btnChrItem18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem18ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem18.getText());
    }//GEN-LAST:event_btnChrItem18ActionPerformed

    private void btnChrItem19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem19ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem19.getText());
    }//GEN-LAST:event_btnChrItem19ActionPerformed

    private void btnChrItem20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem20ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem20.getText());
    }//GEN-LAST:event_btnChrItem20ActionPerformed

    private void btnChrItem21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem21ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem21.getText());
    }//GEN-LAST:event_btnChrItem21ActionPerformed

    private void btnChrItem22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem22ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem22.getText());
    }//GEN-LAST:event_btnChrItem22ActionPerformed

    private void btnChrItem23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem23ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem23.getText());
    }//GEN-LAST:event_btnChrItem23ActionPerformed

    private void btnChrItem24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem24ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem24.getText());
    }//GEN-LAST:event_btnChrItem24ActionPerformed

    private void btnChrItem25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem25ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem25.getText());
    }//GEN-LAST:event_btnChrItem25ActionPerformed

    private void btnChrItem26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem26ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem26.getText());
    }//GEN-LAST:event_btnChrItem26ActionPerformed

    private void btnChrItem27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem27ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem27.getText());
    }//GEN-LAST:event_btnChrItem27ActionPerformed

    private void btnChrItem28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem28ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem28.getText());
    }//GEN-LAST:event_btnChrItem28ActionPerformed

    private void btnChrItem29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem29ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem29.getText());
    }//GEN-LAST:event_btnChrItem29ActionPerformed

    private void btnChrItem30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem30ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem30.getText());
    }//GEN-LAST:event_btnChrItem30ActionPerformed

    private void btnChrItem31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem31ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem31.getText());
    }//GEN-LAST:event_btnChrItem31ActionPerformed

    private void btnChrItem32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem32ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, btnChrItem32.getText());
    }//GEN-LAST:event_btnChrItem32ActionPerformed

    private void btnChrItem33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItem33ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, " ");
    }//GEN-LAST:event_btnChrItem33ActionPerformed

    private void btnSpaceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSpaceActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_SPACE, "SPACE");
    }//GEN-LAST:event_btnSpaceActionPerformed

    private void btnChrEnterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrEnterActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_ENTER, "ENTER");
    }//GEN-LAST:event_btnChrEnterActionPerformed

    private void btnABCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnABCActionPerformed
        // 符号
        CDataMgr.AllKeyPadHandle.OnEventShowForm(CBaseEnum.FormCase.Form_ZMKeyPad);
    }//GEN-LAST:event_btnABCActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnABC;
    private javax.swing.JButton btnChrEnter;
    private javax.swing.JButton btnChrItem1;
    private javax.swing.JButton btnChrItem10;
    private javax.swing.JButton btnChrItem11;
    private javax.swing.JButton btnChrItem12;
    private javax.swing.JButton btnChrItem13;
    private javax.swing.JButton btnChrItem14;
    private javax.swing.JButton btnChrItem15;
    private javax.swing.JButton btnChrItem16;
    private javax.swing.JButton btnChrItem17;
    private javax.swing.JButton btnChrItem18;
    private javax.swing.JButton btnChrItem19;
    private javax.swing.JButton btnChrItem2;
    private javax.swing.JButton btnChrItem20;
    private javax.swing.JButton btnChrItem21;
    private javax.swing.JButton btnChrItem22;
    private javax.swing.JButton btnChrItem23;
    private javax.swing.JButton btnChrItem24;
    private javax.swing.JButton btnChrItem25;
    private javax.swing.JButton btnChrItem26;
    private javax.swing.JButton btnChrItem27;
    private javax.swing.JButton btnChrItem28;
    private javax.swing.JButton btnChrItem29;
    private javax.swing.JButton btnChrItem3;
    private javax.swing.JButton btnChrItem30;
    private javax.swing.JButton btnChrItem31;
    private javax.swing.JButton btnChrItem32;
    private javax.swing.JButton btnChrItem33;
    private javax.swing.JButton btnChrItem4;
    private javax.swing.JButton btnChrItem5;
    private javax.swing.JButton btnChrItem6;
    private javax.swing.JButton btnChrItem7;
    private javax.swing.JButton btnChrItem8;
    private javax.swing.JButton btnChrItem9;
    private javax.swing.JButton btnSpace;
    // End of variables declaration//GEN-END:variables
}

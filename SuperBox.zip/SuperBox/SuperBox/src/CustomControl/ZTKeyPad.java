package CustomControl;

import java.awt.CardLayout;
import javax.swing.JList;
import UI.CBaseEnum;
import javax.swing.JTable;

public final class ZTKeyPad extends javax.swing.JPanel {
    
    CardLayout contentLayout = new CardLayout();
    final CustomControl.ZFKeyPad ofrmZFKeyPad = new CustomControl.ZFKeyPad();
    final CustomControl.ZMKeyPad ofrmZMKeyPad = new CustomControl.ZMKeyPad();
    final CustomControl.JTablePad ofrmTablePad = new CustomControl.JTablePad();// 数据查询时显示数据
    
    public ZTKeyPad() {
        initComponents();
        
        this.setLayout(contentLayout);
        
        this.add(ofrmZFKeyPad,  String.valueOf(CBaseEnum.FormCase.Form_ZFKeyPad)); 
        this.add(ofrmZMKeyPad,  String.valueOf(CBaseEnum.FormCase.Form_ZMKeyPad)); 
        this.add(ofrmTablePad,  String.valueOf(CBaseEnum.FormCase.Form_ListViewPad)); 
        
        OnEventShowForm(CBaseEnum.FormCase.Form_ZMKeyPad);
    }
    
    public void OnEventShowForm(CBaseEnum.FormCase formNext) {
        contentLayout.show(this, String.valueOf(formNext));
    }
    
    public JTable GetTable() {
        return ofrmTablePad.GetTable();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setLayout(new java.awt.CardLayout());
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}

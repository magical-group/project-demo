package FuncClass;

import DB.CDBHelper;
import DB.QueryEntity;
import HLDBoard.CHardwareMonitor;
import HLDClient.CWebApiHandleBase;
import UI.CBaseEnum;
import UI.CBaseEnum.BoxSize;
import UI.CBaseEnum.BoxStatus;
import UI.CBoxProperty;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JLabel;
import mydate.CDateHelper;
import mydate.TimeEntity;
import net.sf.json.JSONArray;
import rest.CRestHelper;
import txt.CTxtHelp;

public class CCommondFunc {

    public static void VoiceTip(final String msg) {
        switch (CDataMgr.ESystemType) {
            case WINDOW:
                FuncClass.TtsHelper.getInstance().Stop();
                FuncClass.TtsHelper.getInstance().speak(msg);
                break;
            case LINUX:
                // -a:valume;-s:speed;-p:pitch
                try { 
                    StopEKHO();
                    Runtime.getRuntime().exec("ekho -a100 -s20 -p-5 " + msg);
                } catch (IOException ex) {  }
                        
                break;
        }
    }
    
    public static void StopEKHO() {
        try {
            Process p = Runtime.getRuntime().exec("ps -A");// 查看所有进程
            String line = null;
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));// getErrorStream()
            try {
                while ((line = br.readLine()) != null) { 
                   if (line.toLowerCase().contains("ekho")) {
                        line = line.trim();
                        int end = line.indexOf(" ");
                        Runtime.getRuntime().exec("kill " + line.substring(0, end));// 结束进程
                        break;
                    }
                }
            } catch (IOException ex) { }
            try { br.close(); } catch (Exception e) { }  
            
        } catch (IOException ex) { } 
    } 
    
    // 0补齐
    public static String lpad(int number, int length) {
        String f = "%0" + length + "d";
        return String.format(f, number);
    }
    
    // 空格补齐
    public static String lpad_space(Object val, int length) {
        String f = "%" + length + "s";
        return String.format(f, val);
    }
    
    // 计算字符串长度(中文占两个字节)
    public static int GetStringLength(String str){
        try {
            return (new String(str.getBytes("gb2312"),"iso-8859-1")).length();
        } catch (UnsupportedEncodingException ex) { }
        
        return 0;
    }

    //验证手机号码
    public static boolean CheckPhone(String strPhone){
        strPhone = strPhone.trim();
        if (strPhone.length() > 0) {
            if ("1".equals(strPhone.substring(0, 1)) && strPhone.length() == 11)
                return true;
        }

        return false;
    }
  
    public static void GetSystemType() {
        String osName = System.getProperty("os.name");  
        if (osName.matches("^(?i)Windows.*$")) 
           CDataMgr.ESystemType = CBaseEnum.SystemType.WINDOW;
        else 
           CDataMgr.ESystemType = CBaseEnum.SystemType.LINUX;
    }
    
    // 产生6位流水号
    public static String MakeCode(String value) {
        String strRet = "";

        String ch1 = value.substring(0, 1);
        String ch2 = value.substring(1, 2);
        String ch3 = value.substring(2, 3);
        String ch4 = value.substring(3, 4);
        String ch5 = value.substring(4, 5);
        String ch6 = value.substring(5, 6);

        ch6 = GetNextCode(ch6);
        if ("0".equals(ch6))
        {
            ch5 = GetNextCode(ch5);
            if ("0".equals(ch5))
            {
                ch4 = GetNextCode(ch4);
                if ("0".equals(ch4))
                {
                    ch3 = GetNextCode(ch3);
                    if ("0".equals(ch3))
                    {
                        ch2 = GetNextCode(ch2);
                        if ("0".equals(ch2))
                        {
                            ch1 = GetNextCode(ch1);
                        }
                    }
                }
            }
        }

        strRet = ch1 + ch2 + ch3 + ch4 + ch5 + ch6;

        return strRet;
    }
    
    static String GetNextCode(String ch) {
        String ret = "0";
        switch (ch) {
            case "0": ret = "1"; break;
            case "1": ret = "2"; break;
            case "2": ret = "3"; break;
            case "3": ret = "4"; break;
            case "4": ret = "5"; break;
            case "5": ret = "6"; break;
            case "6": ret = "7"; break;
            case "7": ret = "8"; break;
            case "8": ret = "9"; break;
            case "9": ret = "A"; break;
            case "A": ret = "B"; break;
            case "B": ret = "C"; break;
            case "C": ret = "D"; break;
            case "D": ret = "E"; break;
            case "E": ret = "F"; break;
            case "F": ret = "G"; break;
            case "G": ret = "H"; break;
            case "H": ret = "I"; break;
            case "I": ret = "J"; break;
            case "J": ret = "K"; break;
            case "K": ret = "L"; break;
            case "L": ret = "M"; break;
            case "M": ret = "N"; break;
            case "N": ret = "O"; break;
            case "O": ret = "P"; break;
            case "P": ret = "Q"; break;
            case "Q": ret = "R"; break;
            case "R": ret = "S"; break;
            case "S": ret = "T"; break;
            case "T": ret = "U"; break;
            case "U": ret = "V"; break;
            case "V": ret = "W"; break;
            case "W": ret = "X"; break;
            case "X": ret = "Y"; break;
            case "Y": ret = "Z"; break;
            case "Z": ret = "0"; break;
        }

        return ret;
    }
    
    public static String GetFormatBoxID(String nBoxID) {
        String boxid = "0";
        if (Integer.parseInt(nBoxID) > 100000) {
            boxid = CCommondFunc.lpad((Integer.parseInt(nBoxID) - 100000), 3);
        }
        else {
            boxid = CCommondFunc.lpad(Integer.parseInt(nBoxID), 3); 
        }
        
        return boxid;
    }
    
    public static int GetIntDB(String val) {
        if (val == null || "".equals(val)) return 0;
        
        int ret = 0;
        
        try { ret = Integer.parseInt(val); } catch (Exception e) { CTxtHelp.AppendLog("[Error] <GetIntDB> val=" + val); }
        
        return ret;
    }

    
    // 获取终端数据库设备表名
    public static String GetDeviceMsg() {
        String strSql = "select fi_DeviceID,fs_Name from tb_Device where fi_DeviceID=" + CDataMgr.DeviceID;
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <GetDeviceMsg> sql=" + strSql); return "无该设备信息"; }
        
        String ret = "";
        ResultSet rs = result.dataRs;;
        try {
            if (rs.next()) { 
                ret = "设备号:" + rs.getString("fi_DeviceID") + ",设备名称:" + rs.getString("fs_Name"); 
            }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        
        return ret;
    }
    
    // 获取终端数据库箱柜信息
    public static String GetBoxMsg(String strWhere) {
        String strSql = "select fi_BoxID,fi_RelayID,fi_BoxSize,fi_BoxStatus,fi_Infrared,fi_LockStatus,fs_GKWZ from tb_Box where fi_DeviceID=" + CDataMgr.DeviceID;
        if (null != strWhere && !"".equals(strWhere)) strSql += " " + strWhere;
        QueryEntity result = CDBHelper.getInstance().QueryWithCount(strSql); // 查询数据
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <GetBoxMsg> sql=" + strSql); return "无该箱柜信息"; }
        
        String ret = "共" + result.rowCount + "条记录\r\n";
        ResultSet rs = result.dataRs;
        try {
            String boxsize = ""; String boxstatus = ""; String infrared = ""; String lockstatus = "";
            while (rs.next()) { 
                switch (rs.getString("fi_BoxSize")) {
                    case "1": boxsize = "大箱子"; break;
                    case "2": boxsize = "中箱子"; break;
                    case "3": boxsize = "小箱子"; break;
                    case "4": boxsize = "超大箱子"; break;
                    case "5": boxsize = "超小箱子"; break;
                }
                switch (rs.getString("fi_BoxStatus")) {
                    case "1": boxstatus = "空闲"; break;
                    case "2": boxstatus = "使用"; break;
                    case "3": boxstatus = "故障"; break;
                }
                switch (rs.getString("fi_Infrared")) {
                    case "0" : infrared = "有物"; break;
                    case "1" : infrared = "无物"; break;
                }
                switch (rs.getString("fi_LockStatus")) {
                    case "1" : lockstatus = "门开"; break;
                    case "2" : lockstatus = "门关"; break;
                }
                //" [格口编号] " + rs.getString("fs_GKWZ") + 
                ret += 
                        " [格口号] " + GetFormatBoxID(rs.getString("fi_BoxID")) + 
                        " [继电器] " + rs.getString("fi_RelayID") + 
                        "  " + boxsize + 
                        "  " + boxstatus + 
                        "  " + infrared + 
                        "  " + lockstatus + "\r\n";
            }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        ret += "共" + result.rowCount + "条记录";
        
        return ret;
    }
    
    // 获取终端数据库订单信息
    public static String GetOrderMsg(String strWhere) {
        String strSql = "select fs_OrderID,fs_DeliverTime,fi_BoxID,fs_DeliverUid,fs_Phone from tb_Order where fi_DeviceID=" + CDataMgr.DeviceID;
        if (null != strWhere && !"".equals(strWhere)) strSql += " " + strWhere;
        QueryEntity result = CDBHelper.getInstance().QueryWithCount(strSql); // 查询数据
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <GetOrderMsg> sql=" + strSql); return "无该箱柜信息"; }
        
        String ret = "共" + result.rowCount + "条记录\r\n";
        ResultSet rs = result.dataRs;
        try {
            while (rs.next()) { 
                ret +=  " [投递时间] " + rs.getString("fs_DeliverTime") + 
                        " [格口号] " + GetFormatBoxID(rs.getString("fi_BoxID")) + 
                        " [快递员] " + rs.getString("fs_DeliverUid") + 
                        " [用户] " + rs.getString("fs_Phone") + 
                        " [订单编号] " + rs.getString("fs_OrderID") + 
                        "\r\n";
            }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        ret += "共" + result.rowCount + "条记录";
        
        return ret;
    }
    
    // 获取正在使用中的格口数
    public static int FilterBoxCount(String strWhere) {
        int ret = 0;
        
        String strSql = "select count(fi_ID) AS nCount from tb_Box where fi_DeviceID=" + CDataMgr.DeviceID;
        if (null != strWhere && !"".equals(strWhere)) strSql+= " " + strWhere;
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <GetBoxCount> sql=" + strSql); return 0; }
        
        ResultSet rs = result.dataRs;;
        try {
            if (rs.next()) { ret = GetIntDB(rs.getString("nCount")); }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        
        return ret;
    }
    
    // 获取可用剩余投递格口数
    public static int GetBoxCount_Put() {
        int ret = 0;
        
        String strSql = "select count(fi_ID) AS nCount from tb_Box where fi_DeviceID=" + CDataMgr.DeviceID + " and fi_BoxStatus=" + BoxStatus.Box_Ideal.ordinal() + " AND fi_Infrared=" + CBaseEnum.Infrared.NoThing.ordinal();
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <GetBoxCount_Put> sql=" + strSql); return 0; }
        
        ResultSet rs = result.dataRs;;
        try {
            if (rs.next()) { ret = GetIntDB(rs.getString("nCount")); }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        
        return ret;
    }

    // 获取可用取件投递格口数
    public static int GetBoxCount_Get(String time) {
        int ret = 0;
        
        String strSql = "select count(fi_ID) AS nCount from tb_Order where fi_DeviceID=" + CDataMgr.DeviceID + 
           " and fi_UnitID ='" + CDataMgr.KDGS + "'" +
           " and fi_Status=" + CBaseEnum.Package_DeliverComplete + " and fs_DeliverTime <='" + time + "'";
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <GetBoxCount_Get> sql=" + strSql); return 0; }
        
        ResultSet rs = result.dataRs;;
        try {
            if (rs.next()) { ret = GetIntDB(rs.getString("nCount")); }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        
        return ret;
    }
    
    // 获取正在使用中的格口数
    public static int GetBoxCount_Use() {
        int ret = 0;
        
        String strSql = "select count(fi_ID) AS nCount from tb_Box where fi_DeviceID=" + CDataMgr.DeviceID + " and fi_BoxStatus=" + BoxStatus.Box_Busy.ordinal();
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <GetBoxCount_Use> sql=" + strSql); return 0; }
        
        ResultSet rs = result.dataRs;;
        try {
            if (rs.next()) { ret = GetIntDB(rs.getString("nCount")); }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        
        return ret;
    }
    
    // 获取正在使用中的订单数
    public static int GetOrderCount_Use() {
        int ret = 0;
        
        String strSql = "select count(fi_ID) AS nCount from tb_Order where fi_DeviceID=" + CDataMgr.DeviceID + " and fi_Status=" + CBaseEnum.Package_DeliverComplete ;
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <GetOrderCount_Get> sql=" + strSql); return 0; }
        
        ResultSet rs = result.dataRs;;
        try {
            if (rs.next()) { ret = GetIntDB(rs.getString("nCount")); }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        
        return ret;
    }
    
    // 获取剩余格口
    static int[] arrayRemain = new int[5];
    
    public static int[] GetBoxRemain() {
        arrayRemain[0] = arrayRemain[1] = arrayRemain[2] = arrayRemain[3] = arrayRemain[4] = 0;

        String strSql = "select sum(case fi_BoxSize when " + String.valueOf(BoxSize.Box_Big.ordinal()) + " then 1 else 0 end  ) AS nBigCount," +
                        "sum(case fi_BoxSize when " + String.valueOf(BoxSize.Box_Normal.ordinal()) + " then 1 else 0 end  ) AS nNormalCount," +
                        "sum(case fi_BoxSize when " + String.valueOf(BoxSize.Box_Small.ordinal()) + " then 1 else 0 end  ) AS nSmallCount," +
                        "sum(case fi_BoxSize when " + String.valueOf(BoxSize.Box_SBig.ordinal()) + " then 1 else 0 end  ) AS nSBigCount," +
                        "sum(case fi_BoxSize when " + String.valueOf(BoxSize.Box_SSmall.ordinal()) + " then 1 else 0 end  ) AS nSSmallCount " +
                        " from tb_Box" +
                        " where fi_DeviceID=" + CDataMgr.DeviceID + " and fi_BoxStatus=" + String.valueOf(BoxStatus.Box_Ideal.ordinal()) + " and fi_Infrared=" + CBaseEnum.Infrared.NoThing.ordinal() +
                        " and fi_BoxID not in (select fi_BoxID from tb_Order where fi_status=" + CBaseEnum.Package_DeliverComplete + ")";
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <GetBoxRemain> sql=" + strSql); return arrayRemain; }
        
        ResultSet rs = result.dataRs;;
        try {
            if (rs.next()) {
                arrayRemain[0] = GetIntDB(rs.getString("nBigCount"));
                arrayRemain[1] = GetIntDB(rs.getString("nNormalCount"));
                arrayRemain[2] = GetIntDB(rs.getString("nSmallCount"));
                arrayRemain[3] = GetIntDB(rs.getString("nSBigCount"));
                arrayRemain[4] = GetIntDB(rs.getString("nSSmallCount"));
            }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        
        return arrayRemain;
    }
    
    // 获取可用格口
    public static CBoxProperty GetUsedableBox(BoxSize eBoxSize, String boxwhere) {
        CBoxProperty property = null;
        
        String strSql = "select fi_BoxID,fi_RelayID,fi_LockStatus,fi_Infrared from tb_Box" + 
                        " where fi_DeviceID=" + CDataMgr.DeviceID +  
                        " and fi_BoxSize=" + String.valueOf(eBoxSize.ordinal()) + " and fi_BoxStatus=" + String.valueOf(BoxStatus.Box_Ideal.ordinal()) + " and fi_Infrared=" + CBaseEnum.Infrared.NoThing.ordinal() + 
                        " and fi_BoxID not in (select fi_BoxID from tb_Order where fi_status=" + CBaseEnum.Package_DeliverComplete + ") " + boxwhere + 
                        " order by fi_UsedCount";
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <GetUsedableBox> sql=" + strSql); return null; }
        
        ResultSet rs = result.dataRs;;
        try {
            if (rs.next()) {
                property = new CBoxProperty();
                property.BoxID = rs.getString("fi_BoxID");// 100017
                property.Side = property.BoxID.length() < 6 ? 0 : 1;
                property.Relay = GetIntDB(rs.getString("fi_RelayID"));
                property.LockStatus = GetIntDB(rs.getString("fi_LockStatus"));
                property.Infrared = GetIntDB(rs.getString("fi_Infrared"));
            }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }

        return property;
    }
    
    // 获取格口属性(通过boxid)
    public static CBoxProperty GetBox1(String boxid) {
        int boxid1 = Integer.parseInt(boxid);
        int boxid2 = 100000 + Integer.parseInt(boxid);
        
        CBoxProperty property = null;
        
        String strSql = "select fs_GKWZ,fi_BoxID,fi_RelayID,fi_BoxStatus,fi_LockStatus,fi_Infrared,fi_FaultCount from tb_Box" + 
                        " where fi_DeviceID=" + CDataMgr.DeviceID + 
                        " and (fi_BoxID=" + boxid1 + " or fi_BoxID=" + boxid2 + ")";
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <GetBox1> sql=" + strSql); return null; }
        
        ResultSet rs = result.dataRs;;
        try {
            if (rs.next()) {
                property = new CBoxProperty();
                property.BoxID = rs.getString("fi_BoxID");// 100017
                property.GKWZ = rs.getString("fs_GKWZ");
                property.Side = property.BoxID.length() < 6 ? 0 : 1;
                property.Relay = GetIntDB(rs.getString("fi_RelayID"));
                property.BoxStatus = GetIntDB(rs.getString("fi_BoxStatus"));
                property.LockStatus = GetIntDB(rs.getString("fi_LockStatus"));
                property.Infrared = GetIntDB(rs.getString("fi_Infrared"));
                property.FaultCount = GetIntDB(rs.getString("fi_FaultCount"));
            }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }

        return property;
    }
    
    // 获取格口属性(通过GKWZ)
    public static CBoxProperty GetBox2(String strGKWZ, String strWhere) {
        CBoxProperty property = null;
        
        String strSql = "select fi_BoxID,fs_GKWZ,fi_RelayID,fi_BoxStatus,fi_LockStatus,fi_Infrared,fi_FaultCount " +
                        "from tb_Box WHERE fi_DeviceID=" + CDataMgr.DeviceID + " and fs_GKWZ='" + strGKWZ + "' ";
        if (null != strWhere && !"".equals(strWhere)) {
            strSql += strWhere;
        }
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <GetBox2> sql=" + strSql); return null; }
        
        ResultSet rs = result.dataRs;;
        try {
            if (rs.next()) {
                property = new CBoxProperty();
                property.BoxID = rs.getString("fi_BoxID");// 100017
                property.GKWZ = rs.getString("fs_GKWZ");
                property.Side = property.BoxID.length() < 6 ? 0 : 1;
                property.Relay = GetIntDB(rs.getString("fi_RelayID"));
                property.BoxStatus = GetIntDB(rs.getString("fi_BoxStatus"));
                property.LockStatus = GetIntDB(rs.getString("fi_LockStatus"));
                property.Infrared = GetIntDB(rs.getString("fi_Infrared"));
                property.FaultCount = GetIntDB(rs.getString("fi_FaultCount"));
            }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }

        return property;
    }
    
    // 继电器号通过数据库查询获取格口号
    public static CBoxProperty GetBoxProperty(int relayid, String boxwhere) {
        CBoxProperty property = null;
        
        String strSql = "select fi_BoxID,fi_BoxStatus from tb_box where fi_DeviceID=" + CDataMgr.DeviceID + " and fi_RelayID="+ relayid + boxwhere;
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (!result.hasData) { 
            //CTxtHelp.AppendLog("[Error] <GetBoxID> sql=" + strSql); 
            return null; 
        }
        
        ResultSet rs = result.dataRs;;
        try {
            if (rs.next()) {
                property = new CBoxProperty();
                property.BoxID = rs.getString("fi_BoxID");// 100017
                property.BoxStatus = GetIntDB(rs.getString("fi_BoxStatus"));
            }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        
        return property;
    }
    
    // 重开箱门/重新格口更新格口属性(触发者类型内存值不变)
    public static void GetLoadBoxProperty(String boxid, CBoxProperty property) {
        String strSql = "select fi_BoxID,fi_RelayID,fi_TriggerType,fs_TriggerID,fi_LockStatus,fi_Infrared,fi_FaultCount from tb_box where fi_DeviceID=" + CDataMgr.DeviceID + " and fi_BoxID=" + boxid;
        QueryEntity result = CDBHelper.getInstance().Query(strSql); 
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <GetLoadBoxProperty> sql=" + strSql); return ; }
        
        ResultSet rs = result.dataRs;;
        try {
            if (rs.next()) {
                property.BoxID = rs.getString("fi_BoxID");// 100017
                property.Side = property.BoxID.length() < 6 ? 0 : 1;
                property.Relay = GetIntDB(rs.getString("fi_RelayID"));
                property.TriggerType = GetIntDB(rs.getString("fi_TriggerType"));
                property.TriggerID = rs.getString("fs_TriggerID");
                property.LockStatus = GetIntDB(rs.getString("fi_LockStatus"));
                property.Infrared = GetIntDB(rs.getString("fi_Infrared"));
                property.FaultCount = GetIntDB(rs.getString("fi_FaultCount"));
            }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
    }
    
    // 快递员取件/用户取件,通过orderid查询box属性
    public static CBoxProperty GetOrderBox(String orderid, String userPhone) {
        CBoxProperty property = null;
        
        String strSql = "select tb_Box.fi_BoxID,fi_RelayID,fi_LockStatus,fi_Infrared" +
                        " from tb_Box,tb_Order" + 
                        " where tb_Box.fi_DeviceID=" + CDataMgr.DeviceID + 
                        " and tb_Box.fi_BoxID=tb_Order.fi_BoxID and fs_OrderID='" + orderid + "' and tb_Order.fi_Status=" + CBaseEnum.Package_DeliverComplete ;
       if (null != userPhone && !"".equals(userPhone)) {
            strSql += " and tb_Order.fs_Phone='" + userPhone + "'";
        }
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <GetOrderBox> sql=" + strSql); return null; }
        
        ResultSet rs = result.dataRs;;
        try {
            if (rs.next()) {
                property = new CBoxProperty();
                property.BoxID = rs.getString("fi_BoxID");// 100017
                property.Side = property.BoxID.length() < 6 ? 0 : 1;
                property.Relay = GetIntDB(rs.getString("fi_RelayID"));
                property.LockStatus = GetIntDB(rs.getString("fi_LockStatus"));
                property.Infrared = GetIntDB(rs.getString("fi_Infrared"));
            }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        
        return property;
    }
    
    public static int GetBoxID_YCXZ(String strOrderID, int status) {
        int ret = 0;
        String strSql = "select fi_BoxID from tb_Order where fs_OrderID='" + strOrderID + "' and fi_Status=" + String.valueOf(status);
       
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <GetBoxID_YCXZ> sql=" + strSql); return 0; }
        
        ResultSet rs = result.dataRs;;
        try {
            if (rs.next()){
                ret = rs.getInt("fi_BoxID");
            }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        
        return ret;
    }
        
    // 是否有物
    public static int IsInfrared(String where) {
        int infrared = -1; 
        
        String strSql = "select fi_Infrared from tb_box" +
                        " where fi_DeviceID=" + CDataMgr.DeviceID + " " + where; 
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <IsInfrared> sql=" + strSql); return -1; }
        
        ResultSet rs = result.dataRs;;
        try {
            if (rs.next()) {
                infrared = GetIntDB(rs.getString("fi_Infrared"));
            }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        
        return infrared;
    }
    
    // 是否故障
    public static boolean IsFault(String where) {
        int boxstatus = -1; boolean ret = false;
        
        String strSql = "select fi_BoxStatus from tb_box" +
                        " where fi_DeviceID=" + CDataMgr.DeviceID + " " + where; 
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <IsFault> sql=" + strSql); return false; }
        
        ResultSet rs = result.dataRs;;
        try {
            if (rs.next()) {
                boxstatus = GetIntDB(rs.getString("fi_BoxStatus"));
            }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        
        if (CBaseEnum.BoxStatus.Box_Fault.ordinal() == boxstatus) ret = true;
        
        return ret;
    }
    
    // 是否空闲有物
    public static boolean IsIdealAndInfrared(String boxid) {
        int boxStatus = -1; int infrared = -1; boolean ret = false;
        
        String strSql = "select fi_BoxStatus, fi_Infrared from tb_box" +
                        " where fi_DeviceID=" + CDataMgr.DeviceID + " and fi_BoxID=" + boxid; 
        QueryEntity result = CDBHelper.getInstance().Query(strSql); 
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <IsIdealAndInfrared> sql=" + strSql); return false; }
        
        ResultSet rs = result.dataRs;;
        try {
            if (rs.next()) {
                boxStatus = GetIntDB(rs.getString("fi_BoxStatus"));
                infrared = GetIntDB(rs.getString("fi_Infrared"));
            }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        
        if (boxStatus == CBaseEnum.BoxStatus.Box_Ideal.ordinal() && infrared == CBaseEnum.Infrared.HasThing.ordinal()) ret = true;// 空闲有物
        
        return ret;
    }
    
    public static boolean HasBoxError(String pid, String pwd) {
        boolean ret = false;
        
        String strSql = "select fi_ID from tb_BoxError" +
                        " where fi_DeviceID=" + CDataMgr.DeviceID + " and fs_PID='" + pid + "' and fs_Pwd='" + pwd + "' and fi_State=0";
        QueryEntity result = CDBHelper.getInstance().Query(strSql);
        if (!result.hasData) { return false; }
        
        ResultSet rs = result.dataRs;;
        try {
            if (rs.next()) { ret = true; }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        
        return ret;
    }
    
    public static String GetAgree(boolean isKDY) {
        String ret = "";
        
        String strSql = "";
        if (isKDY) {
            strSql = "select fi_XYNR from tb_Agree where fi_XYLX='01'";
        }
        else {
            strSql = "select fi_XYNR from tb_Agree where fi_XYLX='02'";
        }

        QueryEntity result = CDBHelper.getInstance().Query(strSql);
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <GetAgree> sql=" + strSql); return ""; }
        
        ResultSet rs = result.dataRs;;
        try {
            if (rs.next())  ret = rs.getString("fi_XYNR");
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        
        return ret;
    }
    
    public static CBoxProperty UserCheckOrder(String UserPID, String UserPwd, JLabel lblTipMsg){
        CBoxProperty property = null;
        
        String strSql = "select fs_OrderID,tb_Box.fi_BoxID,fi_RelayID,fi_LockStatus,fi_Infrared" +
                        " from tb_Order,tb_Box" +
                        " where tb_Order.fi_BoxID=tb_Box.fi_BoxID and substr(tb_Order.fs_Phone, 8, 4)='" + UserPID + "' and tb_Order.fi_DeviceID=" + CDataMgr.DeviceID + " and tb_Order.fi_Status=" + CBaseEnum.Package_DeliverComplete;
        if (null != UserPwd && !"".equals(UserPwd)) {
            strSql += " and tb_Order.fs_QJMM='" + GetMD5(UserPwd) + "'";
        }
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (!result.hasData) { 
            CTxtHelp.AppendLog("[Error] <CheckOrder> sql=" + strSql); 
            if (null != lblTipMsg) lblTipMsg.setText("查无订单信息!");
            return null;
        }
        
        ResultSet rs = result.dataRs;;
        try {
            if (rs.next()) {
                property = new CBoxProperty();
                property.OrderID = rs.getString("fs_OrderID");
                property.BoxID = rs.getString("fi_BoxID");// 100017
                property.Side = property.BoxID.length() < 6 ? 0 : 1;
                property.Relay = CCommondFunc.GetIntDB(rs.getString("fi_RelayID"));
                property.LockStatus = CCommondFunc.GetIntDB(rs.getString("fi_LockStatus"));
                property.Infrared = CCommondFunc.GetIntDB(rs.getString("fi_Infrared"));
            }
            else {
                if (null != lblTipMsg) lblTipMsg.setText("查无该用户未领取包裹！");
                
                if (CCommondFunc.HasBoxError(UserPID, UserPwd)) {
                    if (null != lblTipMsg) lblTipMsg.setText("您有异常订单，请点击异常格口");
                }
            }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        
        return property;
    }
        
    // 添加记录(关闭错误格口)
    public static void AddBoxError(String orderid, String boxid1, String boxid2, String pid, String pwd, String note) {
        TimeEntity entity = CDateHelper.GetNowTimeWithEntity();
        String strSql = "insert into tb_BoxError (fi_DeviceID,fs_OrderID,fi_BoxID1,fi_BoxID2,fs_PID,fs_Pwd,fi_Time1,fs_Time1,fs_Note,fi_State) "+ 
                        "values ('" + 
                        CDataMgr.DeviceID + "','" + 
                        orderid + "','" + 
                        boxid1 + "','" + 
                        boxid2 + "','" + 
                        pid + "','" + 
                        pwd + "'," + 
                        entity.TimeStamp + ",'" + 
                        entity.TimeValue + "','" + 
                        note + "', 0)";
        func.CCommondFunc.SyncExecuteSql(strSql); 
    }
    
    // 修改记录(打开错误格口)
    public static void UpdateBoxError(String boxid) {
        String strWhere = " where fi_DeviceID=" + CDataMgr.DeviceID + " and fi_BoxID2=" + boxid;
        
        String strSql = "select fi_ID from tb_BoxError" + strWhere;
        QueryEntity result = CDBHelper.getInstance().Query(strSql);
        if (!result.hasData) { return ; }
        
        boolean update = false;
        ResultSet rs = result.dataRs; 
        try {
            if (rs.next()) { 
                update = true;
            }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        
        if (update) {
            TimeEntity entity = CDateHelper.GetNowTimeWithEntity();
            strSql = "update tb_BoxError set fi_State=1,fi_Time2=" + entity.TimeStamp + ",fs_Time2='" + entity.TimeValue + "'" + strWhere;      
            func.CCommondFunc.SyncExecuteSql(strSql);
        }
    }

    public static void UpdateBox(String boxid, int status, int TriggerType, String fs_TriggerID, boolean boxstatusupdate) {
        String strSql = "update tb_Box set fi_TriggerType=" + TriggerType + ",fs_TriggerID='" + fs_TriggerID + "'";
        if (boxstatusupdate) strSql += ",fi_BoxStatus=" + status;
        strSql += " where fi_DeviceID=" + CDataMgr.DeviceID + " and fi_BoxID=" + boxid + " and fi_BoxStatus<>" + CBaseEnum.BoxStatus.Box_Fault.ordinal();// 故障格口不更新
        func.CCommondFunc.SyncExecuteSql(strSql);
    }
    
    // 开箱时记录开箱者信息
    public static void UpdateBoxTrigger(String boxid, int triggerType, String triggerID) {
        // 更新格口信息
        String strSql = "update tb_box set fi_TriggerType=" + triggerType + ",fs_TriggerID='" + triggerID + "',fi_UsedCount=fi_UsedCount+1" +
                        " where fi_DeviceID=" + CDataMgr.DeviceID + " and fi_BoxID="+ boxid; 
        func.CCommondFunc.SyncExecuteSql(strSql);
    }
    
    // 更新格口数
    public static void UpdaBoxCount() {
        String strSql = "select count(fi_ID) as nBoxCount from tb_Box where fi_DeviceID=" + CDataMgr.DeviceID;
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <UpdaBoxCount> sql=" + strSql); return ; }
        
        int count = 0;
        ResultSet rs = result.dataRs; 
        try {
            if (rs.next()) { 
                count = GetIntDB(rs.getString("nBoxCount")); 
            }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        
        strSql = "update tb_Device set fi_BoxCount=" + count;
        DB.CDBHelper.getInstance().Execute(strSql);
    }
    
    // 更新格口开锁失败
    public static void UpdateBoxFaultStatus(int nType, String boxid) {
        if (nType != 0 && nType != 1) return;
        
        String strSql = ""; String strUpdate = ""; String strWhere = " where fi_DeviceID=" + CDataMgr.DeviceID + " and fi_BoxID=" + boxid;   
        int faultCount = 0; int boxStatus = 0;
        
        if (0 == nType) {
            // 开启失败
            strSql = "select fs_GKWZ,fi_FaultCount,fi_BoxStatus from tb_Box " + strWhere;
            QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
            if (!result.hasData) { CTxtHelp.AppendLog("[Error] <UpdateBoxFaultStatus> sql=" + strSql); return ; }
            
            boolean fault = false; String GKWZ = "";
            ResultSet rs = result.dataRs;;
            try {
                if (rs.next()) { 
                    faultCount = GetIntDB(rs.getString("fi_FaultCount")); 
                    boxStatus = GetIntDB(rs.getString("fi_BoxStatus"));
                    if (BoxStatus.Box_Fault.ordinal() != boxStatus) {
                        if (faultCount <= 3) {
                            strUpdate = "update tb_Box set fi_FaultCount=fi_FaultCount+1" + strWhere;// 开启失败(计数+1),3次开锁失败设置为故障
                        }
                        else {
                            strUpdate = "update tb_Box set fi_FaultCount=fi_FaultCount+1,fi_BoxStatus=" + BoxStatus.Box_Fault.ordinal() + ",fs_Content='开启失败5次后设为故障[" + CDateHelper.GetNowTime() + "]' " + strWhere;  // 开启失败(设为故障)
                            fault = true;
                            GKWZ = rs.getString("fs_GKWZ");
                        }
                    }
                }
            } 
            catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
            finally {
                CDBHelper.getInstance().closeQuery(result);
            }
            
            if (!"".equals(strUpdate)) {
                func.CCommondFunc.SyncExecuteSql(strUpdate);
            }
        }
        else if (1 == nType) {
            // 开启成功(空闲，故障计数归0)
            strUpdate = "update tb_Box set fi_FaultCount=0 " + strWhere;  
            func.CCommondFunc.SyncExecuteSql(strUpdate);
        }
    }
    
    // 更新开箱记录
    public static void UpdateBoxEventLog(String boxid, int triggerType, String triggerID, int lockStatus, int infrared, String content) {
        //  添加格口门操作记录
        TimeEntity entity = CDateHelper.GetNowTimeWithEntity();
        String strSql = "insert into tb_BoxEventLog(fi_DeviceID, fi_BoxID, fi_TriggerType, fs_TriggerID, fi_LockStatus, fi_Infrared, fi_DateTime, fs_DateTime, fs_Content) values('" + 
                            CDataMgr.DeviceID + "','" + 
                            boxid + "'," +
                            triggerType + ",'" +
                            triggerID + "'," +
                            lockStatus + "," +
                            infrared + "," +
                            entity.TimeStamp + ",'" +
                            entity.TimeValue + "','" +
                            content + "'" + ")";
        func.CCommondFunc.SyncExecuteSql(strSql);
    }
    
    // 订单添加
    public static void AddNewOrder(String boxid, int timeout, String content) {
        TimeEntity entity = CDateHelper.GetNowTimeWithEntity();
        String xlh = CDataMgr.DeviceID + String.valueOf(entity.TimeStamp);
        String strSql = "insert into tb_Order(fi_SerialID, fs_OrderID, fi_DeviceID, fs_DeviceName, fi_BoxID, fs_DeliverUid, fs_Phone, fi_Status, fi_TimeOut, fi_DeliverTime, fs_DeliverTime, fs_Content,fi_UnitID) VALUES('" +
                xlh + "','" +
                CDataMgr.TDYOrderID + "','" +
                CDataMgr.DeviceID + "','" +
                CDataMgr.DeviceName + "'," +
                boxid + ",'" +
                CDataMgr.TDYPhone + "','" +
                CDataMgr.YHPhone + "','" +
                CBaseEnum.Package_DeliverComplete + "'," +
                timeout + "," +
                entity.TimeStamp + ",'" +
                entity.TimeValue + "','" +
                content + "','" +
                CDataMgr.KDGS + "')";
        func.CCommondFunc.SyncExecuteSql(strSql);
        
        // 交易报文发送
        CWebApiHandleBase.Process6002(xlh, CDataMgr.TDYOrderID, 
                                        boxid,
                                        CBaseEnum.Package_DeliverComplete,
                                        CDataMgr.TDYPhone,
                                        CDataMgr.YHPhone,
                                        entity.TimeValue,
                                        "",
                                        content);
    }
    
    // 修改订单
    public static void UpdateOrder(String orderid, String boxid, int status, String tiggerid, String content) {
        TimeEntity entity = CDateHelper.GetNowTimeWithEntity();
        
        String xlh = ""; String ddbh = ""; String gkbh = ""; int ddzt = 0; String td = ""; String qj = ""; String tdsj = ""; String qjsj = ""; String beizhu = ""; 
        String strWhere = " where fi_DeviceID=" + CDataMgr.DeviceID + " and fi_BoxID=" + boxid + " and fi_Status=" + CBaseEnum.Package_DeliverComplete;
        String strSql = "select fi_SerialID,fs_OrderID,fi_BoxID,fs_DeliverUid,fs_Phone,fs_DeliverTime from tb_Order" + strWhere;
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (result.hasData) { 
            ResultSet rs = result.dataRs; 
            try {
                if (rs.next()){
                    xlh = rs.getString("fi_SerialID");
                    ddbh = rs.getString("fs_OrderID");
                    gkbh = rs.getString("fi_BoxID"); 
                    td = rs.getString("fs_DeliverUid"); 
                    qj = rs.getString("fs_Phone"); 
                    tdsj = rs.getString("fs_DeliverTime"); 
                }
            } 
            catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
            finally {
                CDBHelper.getInstance().closeQuery(result);
            }
        }
        ddzt = status;
        qjsj = entity.TimeValue;
        beizhu = content;
        
        //String orderWhere = "";
        //if (!"".equals(orderid)) orderWhere = " and fs_OrderID='" + orderid + "'";
        strSql = "update tb_Order set fi_Status=" + status + ",fi_PickUpTime=" + entity.TimeStamp + ",fs_PickUpTime='" + entity.TimeValue + "',fs_Content='" + content + "'" +
                 strWhere;// + orderWhere;
        func.CCommondFunc.SyncExecuteSql(strSql);
        
        // 交易报文发送
        CWebApiHandleBase.Process6002(xlh, ddbh, gkbh, ddzt, td, qj, tdsj, qjsj, beizhu);
    }
   
    // 后台进入
    public static String AdminIntoBackground(String cardid) {
        String strSql = "";  JSONArray jsonArr;
        
        String ret = ""; String strStatus = "";
        
        strSql = "select fi_Status from tb_Card C1, tb_CardEx C2 where C1.fs_CardID=C2.fs_CardID and C1.fs_CardID='" + cardid + "'"
            + " and C1.fi_GroupID=5 and C2.fi_DeviceID=" + CDataMgr.DeviceID;// fi_GroupID=5(设备维护员)
        jsonArr = CRestHelper.GetDataTable(CDataMgr.RestUrl_GetDataTable, strSql);
        if (jsonArr == null) return "认证失败!(与管理后台通信异常)";
        if (0 == jsonArr.size()) return "认证失败!(查无该卡号信息)";
       
        strStatus = jsonArr.getJSONObject(0).getString("fi_Status");
        // 本地查询
        //QueryEntity result = CDBHelper.getInstance().Query(strSql);
//        try {
//            if (rs.next()) { strStatus = rs.getString("fi_Status"); }
//        } 
//        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
//        finally {
//            CDBHelper.getInstance().closeQuery(result);
//        }
        
        if (strStatus != null && !"".equals(strStatus)) ret = ("1".equals(strStatus) ? "" : "认证失败!(该卡无效)"); 
        
        return ret;
    }
    
    // 同步更新设备
    public static String UpdateDeviceFromServer() {
        String strSql = ""; JSONArray jsonArr;
        
        // 同步格口
        strSql = "select fi_DeviceID,fi_BoxID,fi_RelayID,fi_TriggerType,fs_TriggerID,fi_BoxSize,fi_BoxStatus,fi_Infrared,fi_LockStatus,fi_UsedCount,fs_Content,fs_FGBH,fs_GKWZ,fi_FaultCount" + 
                " from tb_box where fi_DeviceID=" + CDataMgr.DeviceID; 
        jsonArr = CRestHelper.GetDataTable(CDataMgr.RestUrl_GetDataTable, strSql);
        if (jsonArr == null || 0 == jsonArr.size()) return "查无改设备格口信息";
        
        strSql = "delete from tb_box";
        DB.CDBHelper.getInstance().Execute(strSql);
        for (int i = 0; i < jsonArr.size(); i++) {
            strSql = "insert into tb_Box ([fi_DeviceID], [fi_BoxID], [fi_RelayID], [fi_TriggerType]," +
                    " [fs_TriggerID], [fi_BoxSize], [fi_BoxStatus], [fi_Infrared], [fi_LockStatus], [fi_UsedCount], [fs_Content], [fs_FGBH], [fs_GKWZ], [fi_FaultCount])" +
                    " values ('" +
                    jsonArr.getJSONObject(i).getString("fi_DeviceID") + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_BoxID") + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_RelayID") + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_TriggerType") + "', '" +
                    jsonArr.getJSONObject(i).getString("fs_TriggerID") + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_BoxSize") + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_BoxStatus")  + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_Infrared")  + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_LockStatus")  + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_UsedCount") + "', '" +
                    jsonArr.getJSONObject(i).getString("fs_Content") + "', '" +
                    jsonArr.getJSONObject(i).getString("fs_FGBH") + "', '" +
                    jsonArr.getJSONObject(i).getString("fs_GKWZ") + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_FaultCount") + "')";  
            DB.CDBHelper.getInstance().Execute(strSql);

            strSql = "update tb_Box set fi_SyncStatus=1 where fi_DeviceID=" + CDataMgr.DeviceID + " and fi_BoxID=" + jsonArr.getJSONObject(i).getString("fi_BoxID");
            func.CCommondFunc.AddRest_Execute(strSql); // 通知服务器更新成功
        }
        
        // 更新继电器信息
        //CHardwareMonitor.getInstance().UpdateAllStatus();
        
        UpdaBoxCount();
        
        // 同步订单(只筛选投递员投递完成状态的订单避免多订单下发耗掉流量)
        strSql = "select fs_OrderID,fi_DeviceID,fi_BoxID,fs_Phone,fi_Status,fi_TimeOut,fi_DeliverTime,fs_DeliverTime,fs_DeliverUid,fs_Content,fi_UnitID" + 
                " from tb_Order where fi_DeviceID=" + CDataMgr.DeviceID + " and fi_Status=" + CBaseEnum.Package_DeliverComplete;
        jsonArr = CRestHelper.GetDataTable(CDataMgr.RestUrl_GetDataTable, strSql);
        if (jsonArr == null || 0 == jsonArr.size()) return "查无改设备订单信息";
        
        strSql = "delete from tb_Order";
        DB.CDBHelper.getInstance().Execute(strSql);
        for (int i = 0; i < jsonArr.size(); i++) {
            // rest 日期特殊处理2014-09-15T13:50
            strSql = "insert into tb_Order ([fs_OrderID],[fi_DeviceID],[fi_BoxID],[fs_Phone],[fi_Status]," +
                    " [fi_TimeOut],[fi_DeliverTime],[fs_DeliverTime],[fs_DeliverUid],[fs_Content],[fi_UnitID])" +
                    " values ('" +
                    jsonArr.getJSONObject(i).getString("fs_OrderID") + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_DeviceID") + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_BoxID") + "', '" +
                    jsonArr.getJSONObject(i).getString("fs_Phone") + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_Status") + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_TimeOut") + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_DeliverTime") + "', '" +
                    jsonArr.getJSONObject(i).getString("fs_DeliverTime").replace("T", " ") + "', '" +
                    jsonArr.getJSONObject(i).getString("fs_DeliverUid")  + "','" +
                    jsonArr.getJSONObject(i).getString("fs_Content") + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_UnitID") + "')";  
            DB.CDBHelper.getInstance().Execute(strSql);
        }
        
        return "";
    }
    
    public static int GetCount_OffLineData() {
        int ret = -1;
        String strSql = "select count(fi_ID) as LXZS from tb_OffLineData";
        
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <GetCount_OffLineData> sql=" + strSql); return 0; }

        ResultSet rs = result.dataRs;;
        try {
            if (rs.next()) { 
                ret = GetIntDB(rs.getString("LXZS")); 
            }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        
        return ret;
    }
    
    public static String[] GetTableColumn(String strSql) {
        String[] ColumnNameItems = null;
        
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <GetTableColumn> sql=" + strSql); return null; }
        
        ResultSet rs = result.dataRs;;
        try {
            int count = rs.getMetaData().getColumnCount();
            if (0 != count) {
                ColumnNameItems = new String[count];
                for (int i = 1; i <= count; i++) {
                    ColumnNameItems[i - 1] = rs.getMetaData().getColumnName(i);// 索引从1开始
                }
            }
        } catch (SQLException ex) { }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        
        return ColumnNameItems;
    }
    
    public static boolean IsTableHasColumn(String[] ColumnNameItems, String ColumnName) {
        for ( int i = 0; i < ColumnNameItems.length; i++) {
            if (ColumnName.trim().toLowerCase().equals(ColumnNameItems[i].trim().toLowerCase())) {
                return true;
            }
        }
        
        return false;
    }
    
    static int[] BoxCountItem = new int[6];// 0:格口总数
    
    public static int[] GetBoxCount(String data) {
        for (int i = 0; i < BoxCountItem.length; i++) {
            BoxCountItem[i] = 0;
        }
        if (null == data || "".equals(data)) return BoxCountItem;
        
        data = "111";//data.replace("#@#", DataAnalysis.SPLITE_IN);
        String[] yjkygkItems = new String[6];//data.split(DataAnalysis.SPLITE_OUT);
        
        for (int i = 0; i < yjkygkItems.length; i = i + 2) {
            int sl = 0;
            try { sl = Integer.parseInt(yjkygkItems[i + 1]); } catch (Exception ex){ }
            
            switch (yjkygkItems[i]) {
                // 超小
                case "0": BoxCountItem[0] = sl; break;
                // 小型
                case "1": BoxCountItem[1] = sl; break;
                // 中型
                case "2": BoxCountItem[2] = sl; break;
                // 大型
                case "3": BoxCountItem[3] = sl; break;
                // 超大型
                case "4": BoxCountItem[4] = sl; break;
            }
            
            BoxCountItem[5] += sl;
        }
        
        return BoxCountItem;
    }
    
    public static void SetBoxCount(int[] item,
                                    JLabel lblSSmallBox, 
                                    JLabel lblSmallBox, 
                                    JLabel lblNormalBox, 
                                    JLabel lblBigBox, 
                                    JLabel lblSBigBox, 
                                    JLabel lblUseBoxTotal) {
        for (int i = 0; i < item.length; i++) {
            switch (i) {
                // 超小
                case 0: lblSSmallBox.setText("超小箱子:" + CCommondFunc.lpad(BoxCountItem[0], 2) + "个"); break;
                // 小型
                case 1: lblSmallBox.setText("小箱子:" + CCommondFunc.lpad(BoxCountItem[1], 2) + "个"); break;
                // 中型
                case 2: lblNormalBox.setText("中箱子:" + CCommondFunc.lpad(BoxCountItem[2], 2) + "个"); break;
                // 大型
                case 3: lblBigBox.setText("大箱子:" + CCommondFunc.lpad(BoxCountItem[3], 2) + "个"); break;
                // 超大型
                case 4: lblSBigBox.setText("超大箱子:" + CCommondFunc.lpad(BoxCountItem[4], 2) + "个"); break;
                case 5: lblUseBoxTotal.setText("共:" + CCommondFunc.lpad(BoxCountItem[5], 2) + "个可用"); break;
            }
        }
    }
    
    public static String OrderID_Validated(String strOrderID) {
        if ("".equals(strOrderID)) return "包裹号不能为空，请重新输入！";
        if (strOrderID.length() < 6) return "包裹号格式不正确，请重新输入！";
        if (strOrderID.contains("#|") || 
            strOrderID.contains("'") || 
            strOrderID.contains("?") || 
            strOrderID.contains("%") ||
            strOrderID.contains("%") ||
            strOrderID.contains("(") ||
            strOrderID.contains(")") ||
            strOrderID.contains(">") ||
            strOrderID.contains("=") ||
            strOrderID.contains("<") ||
            strOrderID.contains("*") ||
            strOrderID.contains(":") ||
            strOrderID.contains("/") ||
            strOrderID.contains("-") ||
            strOrderID.contains("+") ||
            strOrderID.contains(".") ||
            strOrderID.contains(",") ||
            strOrderID.contains("'") ||
            strOrderID.contains("@") ||
            strOrderID.contains("#")   ) 
            return "包裹号含有特殊字符,请重新输入!";

        return "";
    }
    
    public static boolean txtOrderID_Validated(String ddh, String strWhere, JLabel lblTipMsg, int hope) {
        ddh = OrderID_Deal(ddh);
        
        if (ddh.length() < 6) {
            if (null != lblTipMsg) lblTipMsg.setText("包裹号格式不对!");
            
            return 1 == hope ? false : true;
        }
        
        if (FuncClass.CCommondFunc.isMessyCode(ddh) || !"".equals(OrderID_Validated(ddh))) {
            if (null != lblTipMsg) lblTipMsg.setText("包裹号含有特殊字符!");
            
            return 1 == hope ? false : true;
        }
        
        if (!OrderID_Check(ddh, strWhere)) {
            if (null != lblTipMsg && 1 == hope) lblTipMsg.setText("无包裹信息!");
            return false;
        }
        else {
            if (null != lblTipMsg && 0 == hope) lblTipMsg.setText("已存在该包裹!");
        }

        return true;
    }
    
    public static boolean Phone_Validated(String phone, JLabel lblTipMsg, String note) {
        if ("".equals(phone)) {
            if (null != lblTipMsg) lblTipMsg.setText(note + "不能为空，请重新输入！");
            return false;
        }
        else {
            if (!CCommondFunc.CheckPhone(phone)) {
                if (null != lblTipMsg) lblTipMsg.setText(note + "不正确，请重新输入！");
                return false;
            }
        }
       
        lblTipMsg.setText("...");
        return true;
    }
    
    public static boolean Data_Validated(CustomControl.TextBoxInput text, JLabel lblTipMsg, String note) {
        String data = text.GetText().trim();
        
        if ("".equals(data)) {
            if (null != lblTipMsg) lblTipMsg.setText(note + "不能为空，请重新输入!");
            return false;
        }
        if (data.length() != text.GetMaxLen()) {
            if (null != lblTipMsg) lblTipMsg.setText(note + "格式不正确");
            return false;
        }
        
        return true;
    }
    
    public static boolean OrderID_Check(String strOrderID, String strWhere) {
        boolean ret = false;
        String strSql = "select fi_Status from tb_Order where fs_OrderID='" + strOrderID + "' ";
        if (null != strWhere && !"".equals(strWhere)) {
            strSql += strWhere;
        }
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <OrderID_Check> sql=" + strSql); return false; }
        
        ResultSet rs = result.dataRs;;
        try {
            if (rs.next()){
                ret = true;
            }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        
        return ret;
    }
    
    public static String OrderID_Deal(String strOrderID) {
         // 小写转大写
        strOrderID = strOrderID.toUpperCase().trim();
        
        if (strOrderID.length() == 0) return "";

        // 去除两头*号
        if ("*".equals(strOrderID.substring(0, 1)))
            strOrderID = strOrderID.substring(1, strOrderID.length());
        if ("*".equals(strOrderID.substring(strOrderID.length() - 1, strOrderID.length())))
            strOrderID = strOrderID.substring(0, strOrderID.length() - 1);

        strOrderID = strOrderID.replace(System.getProperty("line.separator"), "");// 去回车
        strOrderID = strOrderID.trim();// 再去除空格再判断
        if (strOrderID.length() == 0) return "";
        
        // 超过20位处理
        if (strOrderID.length() >= 20) {
            strOrderID = strOrderID.substring(strOrderID.length() - 20, strOrderID.length());
        }
        
        return strOrderID;
    }
    
    // 手机校验码编码规则
    public static String GetCheckPhone(String strmphone) {
        String s_pwd = ""; int ln_TEMP = 0; String ls_jyw = "";

        if (strmphone.length() != 11) {
            return "A";
        }
        for (int i = 0; i < 4; i++) {
            String ls_yssc = strmphone.substring(i, 8 + i);

            int ln_total = 8 * Integer.parseInt(ls_yssc.substring(0, 1)) + 6 * Integer.parseInt(ls_yssc.substring(1, 2))
                + 4 * Integer.parseInt(ls_yssc.substring(2, 3)) + 2 * Integer.parseInt(ls_yssc.substring(3, 4))
                + 3 * Integer.parseInt(ls_yssc.substring(4, 5)) + 5 * Integer.parseInt(ls_yssc.substring(5, 6))
                + 9 * Integer.parseInt(ls_yssc.substring(6, 7)) + 7 * Integer.parseInt(ls_yssc.substring(7, 8));

            ln_TEMP = ln_total % 11;

            if (ln_TEMP == 0) {
                ls_jyw = "5";
            }
            else if (ln_TEMP == 1) {
                ls_jyw = "0";
            }
            else{
                ls_jyw = String.valueOf((11 - ln_TEMP));
            }

            s_pwd += String.valueOf(Integer.parseInt(ls_jyw));
        }
        
        return s_pwd;
    }
    
    public static String GetMD5(String plainText) {
        String md5Str = null;
        try {
            // 操作字符串
            StringBuilder buf = new StringBuilder();

            MessageDigest md = MessageDigest.getInstance("MD5");

            // 添加要进行计算摘要的信息,使用 plainText 的 byte 数组更新摘要。
            md.update(plainText.getBytes());
            // 计算出摘要,完成哈希计算。
            byte b[] = md.digest();
            int i;
            for (int offset = 0; offset < b.length; offset++) {
                i = b[offset];
                if (i < 0) {
                    i += 256;
                }
                if (i < 16) {
                    buf.append("0");
                }
                // 将整型 十进制 i 转换为16位，用十六进制参数表示的无符号整数值的字符串表示形式。
                buf.append(Integer.toHexString(i));
            }
            // 32位的加密
            md5Str = buf.toString();
            // 16位的加密
            // md5Str = buf.toString().md5Strstring(8,24);
        } catch (Exception e) {
        
        }
        
        return md5Str;
    }
    
    // 判断字符串是否为乱码
    public static boolean isMessyCode(String str) {  
        if  (str  ==  null)  return  false;  
        boolean ret = false;
        
        try  {  
            byte[] b =  str.getBytes("ISO8859_1"); 
            for  (int  i  =  0;  i  <  b.length;  i++)  {  
                byte  b1  =  b[i];  
                if  (b1  ==  63)  {
                    ret = true;
                    break;    //1  
                }
                else if  (b1  >  0)   {
                    ret = false;
                }
                else if  (b1  <  0)  {        //不可能为0，0为字符串结束符 
                    ret = true;
                    break;  
                }  
            }  
        }  
        catch  (UnsupportedEncodingException  e)  {  
            ret = true;
        }  

        return  ret;
    }  
    
    // 交易结束(数据清除)
    public static void EndOrder() {
        CDataMgr.CurrentBoxID = "0";
        CDataMgr.CurrentAction = 0;
        CDataMgr.CurrentBoxHasOpen = false;
        CDataMgr.CurrentBoxHasClose = false;
        CDataMgr.CurrentTriggerType = 0;
        CDataMgr.CurrentTriggerID = "";
        CDataMgr.BatchTake = false;
    }
    
    // 重启设备
    public static void ReRunComputer() {
        String cmd = "";
        switch (CDataMgr.ESystemType) {
            case WINDOW:
                cmd = "cmd /c Shutdown -r -f -t 10";
                break;
            case LINUX:
                cmd = " /sbin/shutdown -r now";
                break;
        }
        try { Runtime.getRuntime().exec(cmd); } catch (IOException ex) { }
    }
}

package FuncClass;

import CustomControl.ZTKeyPad;
import UI.CBaseEnum.SystemType;
import UI.MainForm;

public class CDataMgr {
    public static MainForm MainHandle;
    public static ZTKeyPad AllKeyPadHandle;
    
    public static String SoftVerSion = "1.0.0.2";// 软件版本号
    public static String SoftType = "WINDOW_V";
    
    public static SystemType ESystemType;
    
    public static boolean IsSoftFistRun = true;
    
    // 背景图片
    public static final String BackImg = "/res/BodyBg.jpg";

    // 设备信息
    public static String DeviceID;
    public static String DeviceName;
    public static boolean SupperManGet = false;
    
    public static int CurrentAction = 0;//1:投递员存件;2:投递员取件;3:用户取件;4:管理员取件;5:远程开锁(去除);6:远程协助;7:增值业务存件;8:增值业务取件
    public static String CurrentBoxID = "0"; // 投递员/用户当前操作格口号
    public static boolean CurrentBoxHasOpen = false;   // 当前格口是否正常开启
    public static boolean CurrentBoxHasClose = false;  // 当前格口是否正常关闭
    public static int CurrentTriggerType = 0;// 当前操作者类型
    public static String CurrentTriggerID = "";// 当前操作者身份
    public static boolean BatchTake = false;// 批量取件
    
    // 投递员信息
    public static String TDYPhone = "";
    public static String TDYPwd = "";
    public static String TDYMM = "";// 投递员短信登录密码
    public static String KDGS = "9999";
    public static String TDYOrderID = "";// 投递员当前操作单号
    public static String YHPhone = "";
    public static String YHName = "";
    public static String TDYDTM = "";// 快递员扫码登录动态码
    public static String TDYKYGK_ERR;
    public static String[] TDYKYGK_DATA;
    
    // 用户取件信息
    public static String UserPID = "";
    public static String UserPwd = "";
    public static String UserOrderID = "";

    // 取回信息
    public static String DueTime = "";
    
    // 投递员认证信息
    public static boolean IsTDY;
    
    // 0:重新开箱;
    // 1:重选格口;
    // 2:取消投递;
    // 3:运单号查询;
    // 4:用户重开箱门;
    // 5:批量取回逾期件;
    // 6:动态码认证;
    // 7:快递员异常格口取件;
    // 8:用户异常格口取件;
    // 9:扫一扫中取消投递
    // 10:扫一扫重开箱门
    // 11:用户取件重开箱门
    // 12:快递员取回重开箱门
    public static int LocalPwdType;
    
    
    // rest信息
    public static String RestUrl_GetDataTable = "";
    public static String RestUrl_ExecuteNonQuery = "";
    public static String RestUrl_Process = "";
    
    public enum AccessType {
        None,
        Device,
        KeyBoard
    }
}
package HLDBoard;

import FuncClass.CDataMgr;
import UI.CBaseEnum;
import UI.CSystemDAO;
import txt.CTxtHelp;

public class CHandlePower {
    static boolean bTemp = false;
    static long outTime = 0;
    
    public static void Execute(boolean flag) {
       if (!flag) {
            bTemp = flag;

            // 掉电时间记录
            if (0 == outTime) {
                CTxtHelp.AppendLog("[Info] 电力异常");
                CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Error_HardWare, "电力异常");
                outTime = 1000 * 60 * 10 + System.currentTimeMillis();// 10分钟
            }
            
            // 掉电处理
            if (0 != outTime && System.currentTimeMillis() > outTime) {
                if (CDataMgr.MainHandle.GetCurFormCase() == CBaseEnum.FormCase.Form_StandBy) {
                    CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Error_HardWare, "电力异常超时，终端停止使用");
                    CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_Msg, CBaseEnum.RedirectType.Redirect_Next, null);
                }
            }
        }
        else {
            if (bTemp == false && flag == true) {
                bTemp = flag;
                CTxtHelp.AppendLog("[Info] 电力正常");
                CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Error_HardWare, "电力正常");
                
                outTime = 0;
                
                // 供电处理(电力由异常恢复正常，自动跳转回待机界面)
                if (CBaseEnum.FormCase.Form_Msg == CDataMgr.MainHandle.GetCurFormCase()) {
                    CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_StandBy, CBaseEnum.RedirectType.Redirect_Next, null);
                }
            }
        }
    }
}
package HLDBoard;

import DB.CDBHelper;
import FuncClass.CCommondFunc;
import FuncClass.CDataMgr;
import UI.CBoxProperty;
import UI.CLogicHandle;
import txt.CTxtHelp;

public class CHandleRelay {
    
    static String ConversionLockValue(int val) {
        String ret = "";
        switch (val) {
            case 0: ret = "open"; break;
            case 1: ret = "close"; break;
        }
        
        return ret;
    }
    
    public static String ConversionSensorValue(int val) {
        String ret = "";
        switch (val) {
            case 0: ret = "有物"; break;
            case 1: ret = "无物"; break;
        }
        
        return ret;
    }
    
    static String GetFilter(int side) {
        String where = "";
        
        switch (side) {
            case CHardwareMonitor.side_L:
                where = " and fi_BoxID<100000";
                break;
            case CHardwareMonitor.side_R:
                where = " and fi_BoxID>100000";
                break;
        }
        
        return where;
    }
    
    
    static void Change(String msg, String type, int side, int relayId, int relayVal) {
//        CTxtHelp.AppendLog(msg);// 记录继电器变化
        
        CBoxProperty property = CCommondFunc.GetBoxProperty(relayId, GetFilter(side));
        if (null == property) return ;
        
        String boxid = property.BoxID;
        String strSql = ""; String note = ""; int open = 2; boolean boxerr = false;
         
        switch (type) {
            case "Lock":
                if (relayVal == 0) open = 1; 
                strSql = " update tb_Box set fi_LockStatus=" + open;
                note = (relayVal == 0 ? "门开" : "门关"); 
                break;
            case "Sensor":
                strSql = " update tb_Box set fi_Infrared=" + relayVal;
                note = (relayVal == 0 ? "有物" : "无物");
                boxerr = CCommondFunc.IsIdealAndInfrared(boxid);
                break;
        }
        strSql += ",fi_BoxStatus=" + property.BoxStatus + " where fi_DeviceID=" + CDataMgr.DeviceID + " and fi_BoxID=" + boxid;
        CDBHelper.getInstance().Execute(strSql);  // 更新本地数据
        CTxtHelp.AppendLog("[State] boxid=" + boxid + "," + note);// 记录格口变化
         
        if (!CHardwareMonitor.InitRelayEnd || !"0".equals(CDataMgr.CurrentBoxID)) {
            func.CCommondFunc.AddRest_Execute(strSql);// 程序启动时或有操作情况下发送格口变化信息
        }

        if (CHardwareMonitor.InitRelayEnd) {
            switch (type) {
                case "Lock":
                    switch (open) {
                        case 1:
                            CLogicHandle.onOpenBoxCallBack(boxid, "继电器变化");
                            break;
                        case 2:
                            CLogicHandle.onCloseBoxCallBack(boxid);
                            break;
                    }
                    break;
                case "Sensor":
                    if (boxerr && 1 == relayVal) {
                        // 清理开启错误格口记录(格口闪烁情况下,由空闲有物变为空闲无物,造成误操作的逻辑判断错误)
                        CCommondFunc.UpdateBoxError(boxid);
                    }
                    break;
            }
        }
    }
    
    public static void LockChange(int side, int relayId, int relayVal) {
        String msg = "[Info] Lock Change  -> side:" + side + ",relayid:"+ String.valueOf(relayId) + ",state:" + ConversionLockValue(relayVal);
        Change(msg, "Lock", side, relayId, relayVal);
    }
    
    public static void SensorChange(int side, int relayId, int relayVal) {
        String msg = "[Info] Sensor Change  -> side:" + side + ",relayid:"+ String.valueOf(relayId) + ",state:" + ConversionSensorValue(relayVal);
        Change(msg, "Sensor", side, relayId, relayVal);
    }
}

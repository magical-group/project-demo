package HLDBoard;

import FuncClass.CDataMgr;
import SMDataProcess.HldSerialPort;
import SMDataProcess.KeySerialPort;
import static UI.CBaseEnum.KeyType.Key_BarCode;
import txt.CTxtHelp;

public class CHardwareMonitor {
    private static class CHardwareMonitorStoreHolder {
        private static final CHardwareMonitor instance = new CHardwareMonitor();
    }
    
    public static CHardwareMonitor getInstance() {
        return CHardwareMonitorStoreHolder.instance;
    }
    
    Thread thdGetKeyData = null;
    
    public void StartCheck() {
        UpdateAllStatus();
        //
        HldSP.StartAskRelayThread();

        (new Thread(new GetHldDataThread1())).start();
        (new Thread(new GetHldDataThread2())).start();
        (new Thread(new GetHldDataThread3())).start();
        (new Thread(new GetHldDataThread4())).start();
        (new Thread(new GetKeyDataThread())).start();
    }
    
    public void UpdateAllStatus() {
        InitRelayEnd = false;
        OnInitAllStatus(side_L);
        OnInitAllStatus(side_R);
        InitRelayEnd = true;
    }
    
    void OnInitAllStatus(int side) {
        StringBuffer strMsg = new StringBuffer();
        int[] lockSource = HldSP.GetLockAllStatus(side, strMsg); 
        int[] sensorSource = HldSP.GetSensorAllStatus(side, strMsg); 
        if (!"".equals(strMsg.toString())) CTxtHelp.AppendLog("[Error] " + strMsg.toString());

        for (int i = 1; i < lockSource.length; i++) {
            CHandleRelay.LockChange(side, i, lockSource[i]);
        }
        for (int i = 1; i < sensorSource.length; i++) {
            CHandleRelay.SensorChange(side, i, sensorSource[i]);
        }
    }
    
    public HldSerialPort HldSP = new HldSerialPort();
    public KeySerialPort KeySP = new KeySerialPort();
    
    // Can set the vale 
    public static final int side_L = 0;
    public static final int side_R = 1;
    public static boolean InitRelayEnd = false;
    
    class GetHldDataThread1 implements Runnable {
        int[] lockTemp_L = null; int[] sensorTemp_L = null; 
        int[] lockTemp_R = null; int[] sensorTemp_R = null; 
        int[] lockTemp_M = null; int[] sensorTemp_M = null; 
        int[] lockTemp = null; int[] sensorTemp = null;
        
        @Override
        public void run() {
            while (true) {
                // Lock and Sensor(All)
                try { 
                    LockOrSensorChange(side_L);
                } 
                catch (Exception ex) {
                    CTxtHelp.AppendLog("[Error] [GetHldDataThread1]<run>LockOrSensorChange_L:" + ex.getMessage());
                } 
                
                try { 
                    LockOrSensorChange(side_R);
                } 
                catch (Exception ex) {
                    CTxtHelp.AppendLog("[Error] [GetHldDataThread1]<run>LockOrSensorChange_R:" + ex.getMessage());
                } 
                
                try { Thread.sleep(100); }  catch (InterruptedException e)  {}
            }
        }

        void LockOrSensorChange(int side) {
            try { 
                StringBuffer strMsg = new StringBuffer();
                int[] lockSource = HldSP.GetLockAllStatus(side, strMsg); 
                int[] sensorSource = HldSP.GetSensorAllStatus(side, strMsg); 
                if (!"".equals(strMsg.toString())) CTxtHelp.AppendLog("[Error] " + strMsg.toString());
                if (null == lockSource || null == sensorSource) return;

                boolean init = false;

                switch(side) {
                    case side_L: 
                        if (null == lockTemp_L) { init = true; lockTemp_L = new int[lockSource.length]; lockTemp = new int[lockSource.length]; }
                        if (null == sensorTemp_L) { sensorTemp_L = new int[sensorSource.length]; sensorTemp = new int[sensorSource.length]; }
                        System.arraycopy(lockTemp_L, 0, lockTemp, 0, lockTemp_L.length);
                        System.arraycopy(sensorTemp_L, 0, sensorTemp, 0, sensorTemp_L.length);
                        break;
                    case side_R: 
                        if (null == lockTemp_R) { init = true; lockTemp_R = new int[lockSource.length]; lockTemp = new int[lockSource.length]; }
                        if (null == sensorTemp_R) { sensorTemp_R = new int[sensorSource.length]; sensorTemp = new int[sensorSource.length]; }
                        System.arraycopy(lockTemp_R, 0, lockTemp, 0, lockTemp_R.length);
                        System.arraycopy(sensorTemp_R, 0, sensorTemp, 0, sensorTemp_R.length);
                        break;
                    case 2: 
                        if (null == lockTemp_M) { init = true; lockTemp_M = new int[lockSource.length]; lockTemp = new int[lockSource.length]; }
                        if (null == sensorTemp_M) { sensorTemp_M = new int[sensorSource.length]; sensorTemp = new int[sensorSource.length]; }
                        System.arraycopy(lockTemp_M, 0, lockTemp, 0, lockTemp_M.length);
                        System.arraycopy(sensorTemp_M, 0, sensorTemp, 0, sensorTemp_M.length);
                        break;
                }

                if (!init) {
                    if (!java.util.Arrays.equals(lockSource, lockTemp)) {
                        for (int i = 1; i < lockSource.length; i++) {
                            if (lockTemp[i] != lockSource[i]) {
                                CHandleRelay.LockChange(side, i, lockSource[i]);
                            }
                        }
                    } 

                    if (!java.util.Arrays.equals(sensorSource, sensorTemp)) {
                        for (int i = 1; i < sensorSource.length; i++) {
                            if (sensorTemp[i] != sensorSource[i]) {
                                CHandleRelay.SensorChange(side, i, sensorSource[i]);
                            }
                        }
                    }
                }

                switch(side) {
                    case side_L: 
                        if (0 != lockSource.length) System.arraycopy(lockSource, 0, lockTemp_L, 0, lockSource.length); 
                        if (0 != sensorSource.length) System.arraycopy(sensorSource, 0, sensorTemp_L, 0, sensorSource.length); 
                        break;
                    case side_R: 
                        if (0 != lockSource.length) System.arraycopy(lockSource, 0, lockTemp_R, 0, lockSource.length); 
                        if (0 != sensorSource.length) System.arraycopy(sensorSource, 0, sensorTemp_R, 0, sensorSource.length); 
                        break;
                    case 2: 
                        if (0 != lockSource.length) System.arraycopy(lockSource, 0, lockTemp_M, 0, lockSource.length); 
                        if (0 != sensorSource.length) System.arraycopy(sensorSource, 0, sensorTemp_M, 0, sensorSource.length); 
                        break;
                }
            } 
            catch (Exception ex) {
                CTxtHelp.AppendLog("[Error] [LockOrSensorChange]:" + ex.getMessage());
            } 
        }
    }
    
    class GetHldDataThread2 implements Runnable {
        @Override
        public void run() {
           StringBuffer strMsg = new StringBuffer();

           while (true) {
               try { 
                   // Power
                   boolean flag = HldSP.GetPowerStatus(strMsg);
                   if (!"".equals(strMsg.toString())) {
                       CTxtHelp.AppendLog("[Error] GetPowerStatus:" + strMsg.toString());
                   }
                   else {
                       CHandlePower.Execute(flag);// 通知UI
                   }
                   try { Thread.sleep(100); }  catch (InterruptedException e)  {}
               }
               catch (Exception ex) {
                   CTxtHelp.AppendLog("[Error] [GetHldDataThread2]<run>:" + ex.getMessage());
               } 
           }
       }
    }

    class GetHldDataThread3 implements Runnable {
        @Override
        public void run() {
            String barcode = "";

            while (true) {
                try { 
                    // BarCode
                    barcode = HldSP.GetCoderTextData();
                    if (!"".equals(barcode)) {
                        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_BarCode, barcode);
                    }
                    try { Thread.sleep(100); }  catch (InterruptedException e)  {}
                }
                catch (Exception ex) {
                    CTxtHelp.AppendLog("[Error] [GetHldDataThread3]<run>:" + ex.getMessage());
                } 
            }
        }
    }

    class GetHldDataThread4 implements Runnable {
         @Override
        public void run() {
            String ic = "";

            while (true) {
                try { 
                    // IC
                    ic = HldSP.GetICCardData().trim();
                    if (!"".equals(ic)) {
                        CDataMgr.MainHandle.OnICInput(ic);
                    } 
                    try { Thread.sleep(100); }  catch (InterruptedException e)  {}
                }
                catch (Exception ex) {
                    CTxtHelp.AppendLog("[Error] [GetHldDataThread4]<run>:" + ex.getMessage());
                } 
            }
        }
    }
        
    class GetKeyDataThread implements Runnable {
        @Override
        public void run() {
            byte val = 0;
            while (true) {
                val = KeySP.GetKeyValue();
                CHandleKey.Execute(val);
                try { Thread.sleep(10); }  catch (InterruptedException e)  {} 
            }
        }
    }
}

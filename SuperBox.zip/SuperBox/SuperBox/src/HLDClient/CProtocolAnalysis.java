package HLDClient;

public class CProtocolAnalysis {
    
    public enum EBagStatus
    {
        BagNone,    // 正常
        BagLost,    // 掉包
        BagStick    // 粘包
    }

    public EBagStatus BagStatus;
    public boolean WhetherAddContact;
    public boolean WhetherToSend;
    public int Cmd;
    public String Uid;
    public byte[] SendBuffer;
    public String TaskId;
    public String Msg;

    public boolean IsRemainData(int iPosition, HLDClient.CByteBuffer bBuffer, CProtocolAnalysis analysis)
    {
        if (bBuffer.GetWaitRecvRemain())
        {
            bBuffer.SetPosition(iPosition);
            analysis.BagStatus = EBagStatus.BagLost;
            return false;
        }
        return true;
    }
}


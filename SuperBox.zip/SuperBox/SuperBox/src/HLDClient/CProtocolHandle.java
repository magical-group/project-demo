package HLDClient;

import FuncClass.CCommondFunc;
import FuncClass.CDataMgr;
import HLDBoard.CHardwareMonitor;
import UI.CBaseEnum;
import UI.CBoxProperty;
import UI.CLogicHandle;
import java.io.IOException;
import mydata.CDataHelper;
import mydate.CDateHelper;
import net.sf.json.JSONArray;
import rest.CRestHelper;
import txt.CTxtHelp;

public class CProtocolHandle {
    
    public static final String SPLIT1 = "&";
    public static final String SPLIT2 = "#";
    final int HEAD1 = 0x49;// I
    final int HEAD2 = 0x4F;// O
    final int HEAD3 = 0x54;// T
    final int HEAD4 = 0x3D;// =
        
    void Process(CByteBuffer bBuffer, CProtocolAnalysis analysis, String sn)
    {
        analysis.BagStatus = CProtocolAnalysis.EBagStatus.BagNone;
        analysis.WhetherToSend = false;
            
        int iPosition = bBuffer.GetPosition();  if (!bBuffer.HasRemaining()) return;
        
        byte head1 = 0; byte head2 = 0; byte head3 = 0; byte head4 = 0; boolean headok = false;
        
        while (bBuffer.HasRemaining())
        {
            head1 = bBuffer.GetByte();
            
            if (HEAD1 == head1)
            {
                iPosition = bBuffer.GetPosition() - 1;
                head2 = bBuffer.GetByte(); if (!analysis.IsRemainData(iPosition, bBuffer, analysis)) return;
                head3 = bBuffer.GetByte(); if (!analysis.IsRemainData(iPosition, bBuffer, analysis)) return;
                head4 = bBuffer.GetByte(); if (!analysis.IsRemainData(iPosition, bBuffer, analysis)) return;
                if (HEAD2 == head2 && HEAD3 == head3 && HEAD4 == head4)
                {
                    headok = true;
                    break;
                }
                else
                {
                    CTxtHelp.AppendLog("Error,Unable to parse the data(2):Position=" + String.valueOf(iPosition) + ",Index=" + String.valueOf(bBuffer.GetPosition()) + ",Head2=" + String.valueOf(head2));
                }
            }
            else
            {
                CTxtHelp.AppendLog("Error,Unable to parse the data(1):Position=" + String.valueOf(iPosition) + ",Index=" + String.valueOf(bBuffer.GetPosition()) + ",Head1=" + String.valueOf(head1));
            }
        }

        if (!bBuffer.HasRemaining())
        {
            if (headok)
            {
                if (!analysis.IsRemainData(iPosition, bBuffer, analysis)) return;
            }
            return;
        }

        byte[] arrlen = bBuffer.GetByteArray(4); if (!analysis.IsRemainData(iPosition, bBuffer, analysis)) return;
        int len = CDataHelper.String2Int(CDataHelper.ArrayByteToString(arrlen)); if (-1 == len) return;
        byte[] source = bBuffer.GetByteArray(len); if (!analysis.IsRemainData(iPosition, bBuffer, analysis)) return;

        if (!bBuffer.HasRemaining())
        {
            bBuffer.Clear();
        }
        else
        {
            analysis.BagStatus = CProtocolAnalysis.EBagStatus.BagStick;
        }

        String data = CDataHelper.ArrayByteToString(source);
        if (null == data || 0 == data.length() || data.length() - 1 != data.lastIndexOf(SPLIT1))
        {
            return;
        }
        data = data.substring(1, data.length() - 1);
        String[] item = data.split(SPLIT1);
        if (null == item || 4 != item.length)
        {
            return;
        }
        String uid = item[0];
        String taskid = item[1];
        int cmd = CDataHelper.String2Int(item[2]);
        String content = item[3]; 

        analysis.Cmd = cmd;
        analysis.Uid = uid;
        analysis.TaskId = taskid;

        try
        {
            switch (cmd)
            {
                case 1:
                    break;
                case 2:
                    String time = content;
                    SetSystemTime(time);
                    break;
                case 3:
                    // 数据透传
                    CTxtHelp.AppendLog("[Info] Socket Recv: cmd=" + String.valueOf(cmd) + " data=" + data);
                    String[] items = content.split(SPLIT2, -1);
                    int ywbh = CDataHelper.String2Int(items[0]);
                    switch (ywbh) {
                        case 7001:
                            SyncData(items);
                            break;
                        case 7002:
                            ControlDevice(items);
                            break;
                        case 7003:
                        case 7004:
                            // 远程开锁(99992,1,admin)
                            String note = "其他开锁";
                            switch (ywbh) {
                                case 7003: note = "远程开锁";break;
                                case 7004: note = "APP开锁";break;
                                case 7005: note = "微信开锁";break;
                            }
                            RemoteOpen(items[1], items[2], items[3], note);
                            break;
                    }
                    analysis.WhetherToSend = true;
                    analysis.Msg = "ok";
                    break;
            }
        }
        catch (Exception ex)
        {
            CTxtHelp.AppendLog("error@" + ex.getMessage());
        }
    }
    
        static boolean updateTime = false;
    
    void SetSystemTime(String fwqsj) { 
        //if (updateTime) return ; // 一天只更新一次,否则造成系统时间更新混乱
        
        //updateTime = true;
        
        int[] arrTime = CDateHelper.getInstance().GetTime1(fwqsj, "yyyy-MM-dd HH:mm:ss");
        int year = arrTime[0];
        int month = arrTime[1];
        int day = arrTime[2];
        int hour = arrTime[3];
        int minute = arrTime[4];
        int second = arrTime[5];
        
        String cmd = "";  
        if (System.getProperty("os.name").matches("^(?i)Windows.*$")) {
            cmd = " cmd /c date " + year + "-" + CCommondFunc.lpad(month, 2) + "-" + CCommondFunc.lpad(day, 2) + "";  // 格式：yyyy-MM-dd 
            try { Runtime.getRuntime().exec(cmd); } catch (IOException ex) { CTxtHelp.AppendLog("[Error] [CProtocolHandle]<SetSystemTime>:" + ex.getMessage()); }
            cmd = " cmd /c time " + hour + ":" + minute + ":" + second;  // 格式 HH:mm:ss  
            try { Runtime.getRuntime().exec(cmd); } catch (IOException ex) {CTxtHelp.AppendLog("[Error] [CProtocolHandle]<SetSystemTime>:" + ex.getMessage()); }
        }
        else {
            cmd = " date -s " + year + CCommondFunc.lpad(month, 2) + CCommondFunc.lpad(day, 2);// 格式：yyyy-MM-dd HH:mm:ss
            try { Runtime.getRuntime().exec(cmd); } catch (IOException ex) { CTxtHelp.AppendLog("[Error] [CProtocolHandle]<SetSystemTime>:" + ex.getMessage()); }
            cmd = " date -s " + CCommondFunc.lpad(hour, 2) + ":" + CCommondFunc.lpad(minute, 2) + ":" + CCommondFunc.lpad(second, 2); // 格式 HH:mm:ss  
            try { Runtime.getRuntime().exec(cmd); } catch (IOException ex) { CTxtHelp.AppendLog("[Error] [CProtocolHandle]<SetSystemTime>:" + ex.getMessage()); }
         }
    }
    
    void SyncData(String[] items) {
        String ygbh = items[1];
        int lx = CDataHelper.String2Int(items[2]);
        String data1 = items[3];
        switch (lx) {
            case 1:
                // 设备同步
                // 同步设备(通知终端去服务端取数据) 99992
                if (CDataMgr.DeviceID.equals(ygbh)) {
                    UI.CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Normal, "远程同步设备");
                    CCommondFunc.UpdateDeviceFromServer();
                    func.CCommondFunc.AddRest_Execute("update tb_Device set fi_SyncStatus=1 where fi_DeviceID=" + CDataMgr.DeviceID); // 通知服务器更新成功
                }
                break;
            case 2:
                // 同步格口(1,1) 参数1:操作类型(0=全部更新;1=修改;2=删除;3=添加);参数2:格口号 
                SysncBoxInfo(data1);
                break;
            case 3:
                // 用户卡信息
                String cardid = ""; try { cardid = items[3]; } catch (Exception ex) {}
                SysncCardInfo(data1, cardid);
                break;
        }
    }
    
    void ControlDevice(String[] items) {
        int lx = CDataHelper.String2Int(items[2]); 
         switch (lx) {
            case 1:
                UI.CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Normal, "远程重启软件");
                ReRunSoft(); 
                break;
            case 2:
                UI.CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_NetCount, "远程重启电脑," + ",离线总数:" + CCommondFunc.GetCount_OffLineData());
                UI.CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Normal, "远程重启电脑");
                CCommondFunc.ReRunComputer(); 
                break;
         }
    }
    
    // 远程开锁
    void RemoteOpen(String deviceid, String boxid, String opener, String note) {
        if (!deviceid.equals(CDataMgr.DeviceID)) {
            CTxtHelp.AppendLog("[Error] " + note+ "设备号错误,deviceid=" + deviceid + ",Deviceid:" + CDataMgr.DeviceID);
            return;
        }
        
        UI.CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Normal, note + ",boxid:" + boxid + ",opener:" + opener);
        
        CBoxProperty property = CCommondFunc.GetBox1(boxid);
        CLogicHandle.OpenBox(property, CBaseEnum.Lock_RemoteOpen, opener, 0, note);
    }
    
    // 与服务器同步更新箱柜信息
    void SysncBoxInfo(String boxid) {
        UI.CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Normal, "同步格口:" + ",boxid:" + boxid);
       GetBoxInfoFromServer(boxid);   
    }

    void GetBoxInfoFromServer(String boxid) {
        // 判断是否为故障->空闲
        int boxstatus1 = -1;  int boxstatus2 = -1; CBoxProperty property = null;
        if (null != boxid && !"".equals(boxid)) {
            property = CCommondFunc.GetBox1(boxid);
            if (null != property) boxstatus1 = property.BoxStatus;
        }
                
        String strFields = "fi_DeviceID,fi_BoxID,fi_RelayID,fi_TriggerType,fs_TriggerID,fi_BoxSize,fi_BoxStatus,fi_Infrared,fi_LockStatus,fi_UsedCount,fs_FGBH,fs_GKWZ,fi_FaultCount";
        String strWhere = " where fi_DeviceID=" + CDataMgr.DeviceID +
                            (!"".equals(boxid) ? " and fi_BoxID='" + boxid + "'" : "");
        String strSql = "select " + strFields + " from tb_box " + strWhere;
        JSONArray jsonArr = CRestHelper.GetDataTable(CDataMgr.RestUrl_GetDataTable, strSql);
        if (jsonArr == null || 0 == jsonArr.size()) return;
 
        strSql = "delete from tb_box " + strWhere;
        DB.CDBHelper.getInstance().Execute(strSql);
        
        for (int i = 0; i < jsonArr.size(); i++) {
            strSql = "insert into tb_Box (" + strFields + ")" +
                    " values ('" +
                    jsonArr.getJSONObject(i).getString("fi_DeviceID") + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_BoxID") + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_RelayID") + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_TriggerType") + "', '" +
                    jsonArr.getJSONObject(i).getString("fs_TriggerID") + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_BoxSize") + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_BoxStatus")  + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_Infrared")  + "','" +
                    jsonArr.getJSONObject(i).getString("fi_LockStatus")  + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_UsedCount") + "', '" +
                    jsonArr.getJSONObject(i).getString("fs_FGBH") + "', '" +
                    jsonArr.getJSONObject(i).getString("fs_GKWZ") + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_FaultCount") + "')";  
            DB.CDBHelper.getInstance().Execute(strSql);
            
            String strUpdateWhere = " where fi_DeviceID=" + CDataMgr.DeviceID + " and fi_BoxID=" + jsonArr.getJSONObject(i).getString("fi_BoxID");
            // 通知服务器更新成功
//            strSql = "update tb_Box set fi_SyncStatus=1 " + strUpdateWhere;
//            func.CCommondFunc.AddRest_Execute(strSql);
            
            boxstatus2 = Integer.parseInt(jsonArr.getJSONObject(i).getString("fi_BoxStatus"));
            
            switch (boxstatus2) {
                case 1:
                    // 空闲
                    if (boxstatus1 == CBaseEnum.BoxStatus.Box_Fault.ordinal()) {
                        strSql = "update tb_Box set fi_FaultCount=0,fs_Content='由管理平台下发设置为空闲[" + CDateHelper.GetNowTime() + "]'" + strUpdateWhere;
                        func.CCommondFunc.AddRest_Execute(strSql);// 故障改空闲
                    }
                    break;
                case 3:
                    // 故障
                    if (2 != boxstatus1) {
                        strSql = "update tb_Box set fs_Content='由管理平台下发设置为故障[" + CDateHelper.GetNowTime() + "]'" + strUpdateWhere;
                        func.CCommondFunc.AddRest_Execute(strSql);// 故障改空闲
                    }
                    else {
                        UI.CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Error_Operation, "使用中的格口不允许设置为故障,BoxID=" + jsonArr.getJSONObject(i).getString("fi_BoxID"));
                    }
                    break;
            }
        }
        
        // 更新继电器信息
        //CHardwareMonitor.getInstance().UpdateAllStatus();
    }
    
     void SysncCardInfo(String dotype, String cardid) {
        UI.CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Normal, "同步用户卡信息,dotype:" + dotype + ",cardid:" + cardid);
        
        switch (dotype) {
            // 更新全部
            case "0": GetCardInfoFromServer(""); break;
            // 修改
            case "1": GetCardInfoFromServer(cardid); break;
            // 删除(可以多个 1|2)
            case "2":
                String[] arr = cardid.split("\\|");
                for (int i = 0; i < arr.length; i++) {
                    String strSql = "delete from tb_Card where fs_CardID='" + arr[i] + "'";
                    DB.CDBHelper.getInstance().Execute(strSql);
                }
                break;
            // 添加
            case "3": GetCardInfoFromServer(cardid); break;
        }
    }

    void GetCardInfoFromServer(String cardid) {
        String strFields = "fs_CardID,fs_Pwd,fi_GroupID,fs_Name,fs_Phone,fi_Status,fi_UnitID,fs_VerificationID,fs_Content";
        String strWhere = (!"".equals(cardid) ? " where fs_CardID='" + cardid + "'" : "");
        String strSql = "select " + strFields + " from tb_Card" + strWhere;
        JSONArray jsonArr = CRestHelper.GetDataTable(CDataMgr.RestUrl_GetDataTable, strSql);
        if (jsonArr == null || 0 == jsonArr.size()) return;
 
        strSql = "delete from tb_Card " + strWhere;
        DB.CDBHelper.getInstance().Execute(strSql);
        
        for (int i = 0; i < jsonArr.size(); i++) {
            strSql = "insert into tb_Card (" + strFields + ")" +
                    " values ('" +
                    jsonArr.getJSONObject(i).getString("fs_CardID") + "', '" +
                    jsonArr.getJSONObject(i).getString("fs_Pwd") + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_GroupID") + "', '" +
                    jsonArr.getJSONObject(i).getString("fs_Name") + "', '" +
                    jsonArr.getJSONObject(i).getString("fs_Phone") + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_Status") + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_UnitID") + "', '" +
                    jsonArr.getJSONObject(i).getString("fs_VerificationID") + "', '" +
                    jsonArr.getJSONObject(i).getString("fs_Content") + "')";  
            DB.CDBHelper.getInstance().Execute(strSql);
            
            // 通知服务器更新成功
            strSql = "update tb_Card set fi_SyncStatus=1 where fs_CardID=" + jsonArr.getJSONObject(i).getString("fs_CardID");
            func.CCommondFunc.AddRest_Execute(strSql);
        }
    }
    
    void SysncCardExInfo(String dotype, String id) {
        UI.CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Normal, "同步用户卡绑定,dotype:" + dotype + ",id:" + id);
        switch (dotype) {
            // 更新全部
            case "0": GetCardExInfoFromServer("", false); break;
            // 修改
            case "1": GetCardExInfoFromServer(id, false); break;
            // 删除(可以多个 1|2)
            case "2":
                String[] arr = id.split("\\|");
                for (int i = 0; i < arr.length; i++) {
                    GetCardExInfoFromServer(arr[i], true);
                }
                break;
            // 添加
            case "3": GetCardExInfoFromServer(id, false); break;
        }
    }
    
    void GetCardExInfoFromServer(String id, boolean delete) {
        String strFields = "fs_CardID,fi_DeviceID";
        String strWhere = (!"".equals(id) ? " where fi_ID='" + id + "'" : "");
        String strSql = "select fi_ID," + strFields + " from tb_CardEx" + strWhere;
        JSONArray jsonArr = CRestHelper.GetDataTable(CDataMgr.RestUrl_GetDataTable, strSql);
        if (jsonArr == null || 0 == jsonArr.size()) return;
 
        strSql = "delete from tb_CardEx fs_CardID='" + jsonArr.getJSONObject(0).getString("fs_CardID") + 
                "' and fi_DeviceID=" + jsonArr.getJSONObject(0).getString("fi_DeviceID");
        DB.CDBHelper.getInstance().Execute(strSql);
        
        if (delete) return;
        
        for (int i = 0; i < jsonArr.size(); i++) {
            strSql = "insert into tb_CardEx (" + strFields + ")" +
                    " values ('" +
                    jsonArr.getJSONObject(i).getString("fs_CardID") + "', '" +
                    jsonArr.getJSONObject(i).getString("fi_DeviceID") + "')";  
            DB.CDBHelper.getInstance().Execute(strSql);
            
            // 通知服务器更新成功
            strSql = "update tb_CardEx set fi_SyncStatus=1 where fi_ID=" + jsonArr.getJSONObject(i).getString("fi_ID");
            func.CCommondFunc.AddRest_Execute(strSql);
        }
    }
        
    // 重启软件
    void ReRunSoft() {
        System.exit(0);
    }
    
    void CloseComputer() {
        String cmd = "";
        switch (CDataMgr.ESystemType) {
            case WINDOW:
                cmd = "cmd /c Shutdown -s -t 10";
                break;
            case LINUX:
                cmd = " /sbin/shutdown -h now";
                break;
        }
        
        try { Process p = Runtime.getRuntime().exec(cmd); } catch (IOException ex) { }
    }
}

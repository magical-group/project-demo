package HLDClient;

import UI.CSystemDAO;

public class CSocketMgr {
    
    private static class ProtocolMgrStoreHolder {
        private static final CSocketMgr instance = new CSocketMgr();
    }
    
    public static CSocketMgr getInstance() {
        return ProtocolMgrStoreHolder.instance;
    }
    
    CSocketDAO oSocketDAO;
    boolean m_bExit = false;
    
    public void Start() {
       oSocketDAO = new CSocketDAO(CSystemDAO.getInstance().ServerIp, CSystemDAO.getInstance().SocketPort);  
    }
}

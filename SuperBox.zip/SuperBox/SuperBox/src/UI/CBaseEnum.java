package UI;

import javax.swing.JButton;

public class CBaseEnum {
    
    public CBaseEnum() {
    }
    
    public enum SystemType {
        WINDOW,
        LINUX
    }

    /// <summary>
    /// 页面跳转
    /// </summary>
    public enum RedirectType
    {
        Redirect_Null,
        Redirect_Pre,
        Redirect_Next,
    }
    
    /// <summary>
    /// 窗体类型
    /// </summary>
    public enum FormCase{
        Form_NULL,
        Form_Load,
        Form_StandBy,
        Form_DeliverLogin,
        Form_PwdInput,
        Form_DeliverSelect,
        Form_DeliverStep1,
        Form_DeliverStep2,
        Form_DeliverStep3,
        Form_DeliverTackStep1,
        Form_UserPackageStep1,
        Form_DeliverTackStep11,
        Form_PackagePutResult,
        Form_PackageGetResult,
        Form_ZFKeyPad,  // 全键盘字符
        Form_ZMKeyPad,  // 全键盘字母
        Form_ListViewPad,// 数据显示
        //
        Form_Device,    // 后台管理窗体
        Form_Msg,       // 掉电停用界面
        Form_OrderFiler,// 订单查询界面
        Form_BoxError,   // 异常格口取回
        //
        Form_Agree,      // 协议界面
        Form_CFDX, // 重发短信
        Form_YCXZ,   // 远程协助
        //
        Form_GKJK,
        Form_DDXX
    }
    
    public enum Auth {
        Step1,
        Step2
    }
    
    /// <summary>
    /// 按键类型
    /// </summary>
    public enum KeyType{
        Key_BarCode,// 红外扫描
        Key_NUMBER,
        Key_SPACE,
        Key_PERIOD,
        Key_ENTER,
        Key_ESC,
        Key_UP,
        Key_DOWN, 
        Key_TEXTBOX_FORCECHANGE
    }
    
    // 文本框焦点切换
    public static final String PIN_PRESSED_VK_0 = "0";
    public static final String PIN_PRESSED_VK_1 = "1";
    public static final String PIN_PRESSED_VK_2 = "2";
    public static final String PIN_PRESSED_VK_3 = "3";
    public static final String PIN_PRESSED_VK_4 = "4";
    public static final String PIN_PRESSED_VK_5 = "5";
    public static final String PIN_PRESSED_VK_6 = "6";
    public static final String PIN_PRESSED_VK_7 = "7";
    public static final String PIN_PRESSED_VK_8 = "8";
    public static final String PIN_PRESSED_VK_9 = "9";
    public static final String PIN_PRESSED_SPACE = "SPACE";
    public static final String PIN_PRESSED_PERIOD = ".";
    public static final String PIN_PRESSED_ESC = "ESC";
    public static final String PIN_PRESSED_UP = "UP";
    public static final String PIN_PRESSED_DOWN = "DOWN";
    public static final String PIN_PRESSED_ENTER = "ENTER";
    
    // 箱柜尺寸类型
    public enum BoxSize {
        Box_Null,   // 无效类型
        Box_Big,    // 大型箱柜
        Box_Normal, // 中型箱柜
        Box_Small,  // 小型箱柜
        Box_SBig,   // 超大型箱柜
        Box_SSmall  // 超小型箱柜
    }
   
    // 箱柜状态
    public enum BoxStatus
    {
        Box_Null,
        Box_Ideal,      //  箱柜空闲
        Box_Busy,       //  箱柜正在使用中
        Box_Fault       //  箱柜故障
    }
    
    // 箱柜状态
    public enum Infrared
    {
        HasThing,        // 无物
        NoThing          // 有物
    }
    
    // 格口动作
    public enum BoxAction {
        Open,       // 无操作
        ReOpen,     // 重选开箱
        ReChoose,   // 重选格口
        Cancle      // 取消投递
    }
    
    //锁操作类型
    public static final int Lock_Null = 0;
    public static final int Lock_UserOpen = 10;         // 用户取货开锁（订单号/手机号+验证码）
    public static final int Lock_UserClose = 15;
    public static final int Lock_DispStoreOpen = 20;    // 快递员存货开锁（订单号）
    public static final int Lock_DispStoreClose = 25;
    public static final int Lock_DispRevokeOpen = 30;   // 快递员取货开锁（订单号）
    public static final int Lock_DispRevokeClose = 35;
    public static final int Lock_ManualOpen = 40;       // 设备手动开锁（管理员账号）
    public static final int Lock_ManualClose = 45;      
    public static final int Lock_RemoteOpen = 50;       // 平台远程开锁（用户账号）
    public static final int Lock_RemoteClose = 55;
    public static final int Lock_ErrorOpen = 60;        // 异常格口开锁
    public static final int Lock_ErrorClose = 65; 
    public static final int Lock_YCXZOpen = 70;             // 远程协助
    public static final int Lock_YCXZClose = 75; 
    
    // 正在进行的操作类型(1:投递员存件;2:投递员取件;3:用户取件;4:管理员取件;5:远程开锁(去除);6:远程协助;7:增值业务存件;8:增值业务取件)
    public static final int Action_TDYCJ = 1;
    public static final int Action_TDYQJ = 2;
    public static final int Action_YHQJ = 3;
    public static final int Action_GLYQJ = 4;
    public static final int Action_YCXZQJ = 6;
    
    public static final int Package_DeliverComplete = 1;    // 快递员投递完成
    public static final int Package_UserTackComplete = 2;   // 用户取货完成
    public static final int Package_RevokeComplete = 3;     // 快递员取货完成
    public static final int Package_ManualComplete = 4;     // 管理员取件
    public static final int Package_RemoteComplete = 5;     // 远程开锁
    
    public static final int SystemLog_Normal  = 0;      //  日志正常
    public static final int SystemLog_Error_HardWare  = 1000;   // 硬件错误
    public static final int SystemLog_Error_Operation  = 1001;  // 操作错误
    public static final int SystemLog_Error_Net1  = 1002;  // 网络错误1(本地网络问题)
    public static final int SystemLog_Error_Net2  = 1003;  // 网络错误1(与服务器连接问题)
    public static final int SystemLog_NetCount = 1004;// 流量监测
    public static final int SystemLog_SoftException = 1005;// 软件异常

    // 1004:报文统计
    public static void SetButtonStatus (JButton btnExit, JButton btnPreStep, int status) {
        switch (status) {
            case 0:
                if (null != btnExit) btnExit.setEnabled(false);
                if (null != btnPreStep) btnPreStep.setEnabled(false);
                break;
            case 1:
                if (null != btnExit) btnExit.setEnabled(true);
                if (null != btnPreStep) btnPreStep.setEnabled(false);
                break;
            case 2:
                if (null != btnExit) btnExit.setEnabled(false);
                if (null != btnPreStep) btnPreStep.setEnabled(true);
                break;
            case 3:
                if (null != btnExit) btnExit.setEnabled(true);
                if (null != btnPreStep) btnPreStep.setEnabled(true);
                break;
        }
    }
}

package UI;

import UI.CBaseEnum.FormCase;

public class CFormPassParam {
    FormCase ofrmSource;
    Object param;
    String tigMsg;

    public CFormPassParam(FormCase ofrmSource, Object param, String tigMsg) {
        this.ofrmSource = ofrmSource;
        this.param = param;
        this.tigMsg = tigMsg;
    }
    
    public FormCase GetFormSource() {
        return ofrmSource;
    }
    
    public Object GetParam() {
        return param;
    }
    
    public String GetTigMsg() {
        return tigMsg;
    }
}

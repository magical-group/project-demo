package UI;

// 逻辑处理类
import DB.CDBHelper;
import DB.QueryEntity;
import FuncClass.CCommondFunc;
import FuncClass.CDataMgr;
import HLDBoard.CHandleRelay;
import HLDClient.CWebApiHandleBase;
import UI.CBaseEnum.BoxAction;
import UI.CBaseEnum.FormCase;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import txt.CTxtHelp;

public class CLogicHandle {
    
   public static void OpenBox(CBoxProperty property, int triggerType, String triggerID, int action, String note) {
        property.TriggerType = triggerType;         // 开箱类型
        property.TriggerID = triggerID;             // 开箱人
        CCommondFunc.UpdateBoxTrigger(property.BoxID, property.TriggerType, property.TriggerID);// 更新数据库中触发者类型
        
        if (action > 0) {
            CDataMgr.CurrentAction = action;
            CDataMgr.CurrentBoxHasOpen = false;
            CDataMgr.CurrentBoxHasClose = false;
            CDataMgr.CurrentBoxID = property.BoxID;
            CDataMgr.CurrentTriggerType = property.TriggerType;
            CDataMgr.CurrentTriggerID = property.TriggerID;
        }
        
        AddOpenBoxItems(property.BoxID, property, note);
    }
        
    public static Map<String, CBoxProperty> openBoxItems = new HashMap<>();
    static Lock instanceLock = new ReentrantLock();// 加锁
      
    public static CBoxProperty GetOpenBoxItems(String boxid) {
        CBoxProperty ret = null;
        
        instanceLock.lock();
        
        try {
            if (openBoxItems.containsKey(boxid)) {  
                ret = openBoxItems.get(boxid);
            }
        } finally {
            instanceLock.unlock();
        }
        
        return ret;
    }
    
    // 移除特定格口:重选格口/取消投递/投递成功(有物/点击投递成功/超时)
    static void RemoveOpenBoxItems(String boxid) {
        instanceLock.lock();
        
        try {
            if (openBoxItems.containsKey(boxid)) {  
                openBoxItems.remove(boxid);
            }
        } finally {
            instanceLock.unlock();
        }
    }
    
    // 移除所有格口:DeliverStep1/DeliverTackStep1/UserPackageStep1/StandBy
    public static void RemoveOpenBoxAll() {
        instanceLock.lock();
        
        try {
            openBoxItems.clear();
        } finally {
            instanceLock.unlock();
        }
    }
    
    // 开启箱门(投递员投件/投递员取件/用户取件)
    public static void AddOpenBoxItems(String boxid, CBoxProperty property, String title) {
        instanceLock.lock();
        
        try {
            if (openBoxItems.containsKey(boxid)) {  
                CDataMgr.CurrentBoxHasClose = false;// 箱门抖动
                openBoxItems.remove(boxid);
            }
            openBoxItems.put(boxid, property); 
        } finally {
            instanceLock.unlock();
        }
        
        CTxtHelp.AppendLog("[Info] " + title + "::AddOpenBoxItems,OpenCount=" + openBoxItems.size() + ",BoxID=" + boxid  + ",LockStatus:" + property.LockStatus + 
                            ",TriggerType=" + property.TriggerType + ",TriggerID=" + property.TriggerID + ",Infrared=" + property.Infrared + ",BoxAction=" + property.EBoxAction);
        onOpenBox(boxid, property);
    }
    
    // 重开箱门/重选格口/取消投递
    public static void onBoxAction(String nBoxID, BoxAction boxaction) {
        CBoxProperty property = GetOpenBoxItems(nBoxID);
        if (property == null) {
            property = new CBoxProperty();// 该格口可能不在列表中
        }
        property.Result = 0;
        property.EBoxAction = boxaction;
        CCommondFunc.GetLoadBoxProperty(nBoxID, property);// 重新从数据库中获取格口属性
        if (CBaseEnum.BoxAction.ReOpen != boxaction) CDataMgr.CurrentBoxHasOpen = false;
        AddOpenBoxItems(property.BoxID, property, boxaction.toString());
    }
    
    static void onOpenBox(String boxid, CBoxProperty property) { 
        StringBuffer strMsg = new StringBuffer();
        boolean ret = true;//HLDBoard.CHardwareMonitor.getInstance().HldSP.OpenLock(property.Side, property.Relay, strMsg);
        property.LockStatus = 1;
        if (ret) {
            if (property.LockStatus == 1) {
                // 箱门原本就是开启状态
                onOpenBoxCallBack(property.BoxID, "箱门已为开启状态");
                return;
            }
        }
        
       int iIndex = 1;
        
        // 抖动开锁，硬件状态变化，2秒等待稳定
        while (iIndex <= 50) {
            // 判断是否已经处理过
            property = GetOpenBoxItems(boxid);
            if (property == null || property.Result == 1) return;
            iIndex++;
            
            try { Thread.sleep(100); } catch (InterruptedException ex) { }
        }
 
        CTxtHelp.AppendLog("[Error] 开锁失败,boxid=" + boxid + ",err=" + strMsg.toString());
        ++property.FaultCount;

        CCommondFunc.UpdateBoxEventLog(boxid, property.TriggerType, property.TriggerID, property.LockStatus, property.Infrared, "格口[" + CCommondFunc.GetFormatBoxID(boxid) + "]开启失败");
        
        // 开锁失败跳转
        switch (property.TriggerType) {
            case CBaseEnum.Lock_DispStoreOpen:
                switch (property.EBoxAction) {
                    case Cancle:
                        // 取消投递的开锁失败不进行超时等待
                        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_DeliverStep1, CBaseEnum.RedirectType.Redirect_Next, null);
                        break;
                    default:
                        onFailJump(property, ret, CBaseEnum.FormCase.Form_DeliverStep3, CBaseEnum.FormCase.Form_PackagePutResult, "开锁失败(快递员存件)");
                        break;
                }
                break;
             case CBaseEnum.Lock_DispRevokeOpen:
                if (CDataMgr.BatchTake)
                    onFailJump(property, ret, CBaseEnum.FormCase.Form_DeliverTackStep11, CBaseEnum.FormCase.Form_PackageGetResult, "开锁失败(快递员批量取件)");
                else
                    onFailJump(property, ret, CBaseEnum.FormCase.Form_DeliverTackStep1, CBaseEnum.FormCase.Form_PackageGetResult, "开锁失败(快递员单个取件)");
                break;
            case CBaseEnum.Lock_UserOpen:
                switch (CDataMgr.MainHandle.GetCurFormCase()) {
                    case Form_PwdInput:
                        if (11 == CDataMgr.LocalPwdType) {
                            onFailJump(property, ret, CBaseEnum.FormCase.Form_UserPackageStep1, CBaseEnum.FormCase.Form_PackageGetResult, "开锁失败(用户取件)");
                        }
                        break;
                    case Form_UserPackageStep1:
                        onFailJump(property, ret, CBaseEnum.FormCase.Form_UserPackageStep1, CBaseEnum.FormCase.Form_PackageGetResult, "开锁失败(用户取件)");
                        break;
                }
                break;
            case CBaseEnum.Lock_ManualOpen:
                if (FormCase.Form_Device == CDataMgr.MainHandle.GetCurFormCase())
                    CDataMgr.MainHandle.ofrmDevice.ShowTipMsg("格口[" +  CCommondFunc.GetFormatBoxID(boxid) + "]开启失败 -- " + CHandleRelay.ConversionSensorValue(property.Infrared));
                break;
            case CBaseEnum.Lock_RemoteOpen:
                CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Normal, "远程开锁失败:" + boxid);
                break;
            case CBaseEnum.Lock_YCXZOpen:
                if (FormCase.Form_YCXZ == CDataMgr.MainHandle.GetCurFormCase())
                    CDataMgr.MainHandle.ofrmYCXZ.ShowTipMsg("格口[" +  CCommondFunc.GetFormatBoxID(boxid) + "]开启失败");
                break;
            case CBaseEnum.Lock_ErrorOpen:
                // 异常格口开锁
                if (FormCase.Form_BoxError == CDataMgr.MainHandle.GetCurFormCase())
                    CDataMgr.MainHandle.ofrmBoxError.ShowTipMsg("格口[" +  CCommondFunc.GetFormatBoxID(boxid) + "]开启失败");
                break;
        }
    }
    
    static void onFailJump(CBoxProperty property, boolean ret, CBaseEnum.FormCase source, CBaseEnum.FormCase dest, String note) {
        // 锁状态无反馈等待超时
        CFormPassParam param = new CFormPassParam(source, property, note);
        CDataMgr.MainHandle.OnEventShowForm(dest, CBaseEnum.RedirectType.Redirect_Next, param);
    }
    
    public static synchronized void onOpenBoxCallBack(String boxid, String note) {
        CBoxProperty property = GetOpenBoxItems(boxid);
        if (property == null) {
           property = CCommondFunc.GetBox1(boxid);
           property.TriggerType = CBaseEnum.Lock_Null;// 不在当前开锁列表中
           property.TriggerID = "JXKS";
        }

        if (property.TriggerType != CBaseEnum.Lock_DispStoreOpen) RemoveOpenBoxItems(boxid);// 快递员投件抖动开锁不移除

        // 本地记录
        String msg = "";
        switch (property.TriggerType) {
            case CBaseEnum.Lock_DispStoreOpen: msg = "开门:快递员存件," + property.TriggerID; break;
            case CBaseEnum.Lock_DispRevokeOpen: msg = "开门:快递员取件," + property.TriggerID; break;
            case CBaseEnum.Lock_UserOpen: msg = "开门:用户取件," + property.TriggerID; break;
            case CBaseEnum.Lock_ManualOpen: msg = "开门:管理员," + property.TriggerID; break;
            case CBaseEnum.Lock_RemoteOpen: msg = "开门:远程," + property.TriggerID; break;
            case CBaseEnum.Lock_YCXZOpen: msg = "开门:远程协助," + property.TriggerID; break;
            case CBaseEnum.Lock_ErrorOpen: msg = "开门:异常格口," + property.TriggerID; break;
            default: msg = "机械开锁"; break;
        }
        msg = msg + ",格口:" + boxid + "," + (property.Infrared == 0 ? "有物" : "无物" + ",当前正确格口:" + CDataMgr.CurrentBoxID + ",动作:" + property.EBoxAction + ",备注:" + note);
        CTxtHelp.AppendLog("[Info] onOpenBoxCallBack," + msg);// 日志记录
        //UI.CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Normal, msg);
        CCommondFunc.UpdateBoxEventLog(boxid, property.TriggerType, property.TriggerID, 1, property.Infrared, "格口[" + CCommondFunc.GetFormatBoxID(boxid) + "]开启成功");

        // 清理开启错误格口记录
        CCommondFunc.UpdateBoxError(boxid);

        // 异常开启跳出
        if (property.TriggerType == CBaseEnum.Lock_Null) {
            CCommondFunc.UpdateBoxTrigger(boxid, property.TriggerType, property.TriggerID);
            return;
        }

        // 开锁成功处理
        property.Result = 1;
        CFormPassParam param = null;       
        if (property.TriggerType == CBaseEnum.Lock_DispStoreOpen ||
            property.TriggerType == CBaseEnum.Lock_DispRevokeOpen ||
            property.TriggerType == CBaseEnum.Lock_UserOpen ||
            property.TriggerType == CBaseEnum.Lock_ManualOpen ||
            property.TriggerType == CBaseEnum.Lock_YCXZOpen) {

            if ("0".equals(CDataMgr.CurrentBoxID) || !CDataMgr.CurrentBoxID.equals(boxid)) {
                if (CBaseEnum.Lock_Null != property.TriggerType) CDataMgr.MainHandle.OnErrorBox(boxid);// 正常逻辑下,打开的格口与当前操作的格口不符
                return;
            }
            CDataMgr.CurrentBoxHasOpen = true; 
            CDataMgr.CurrentBoxHasClose = false;
        }

        switch (property.TriggerType) {
            case CBaseEnum.Lock_DispStoreOpen:
                // 快递员存货开锁(更新格口)
                switch (property.EBoxAction) {
                    case Cancle:
                        // 取消投递的开锁成功->跳转到包裹扫描界面
                        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_DeliverStep1, CBaseEnum.RedirectType.Redirect_Next, null);
                        break;
                    case Open:
                    case ReOpen:
                        CCommondFunc.UpdateBox(boxid, CBaseEnum.BoxStatus.Box_Ideal.ordinal(), CBaseEnum.Lock_DispStoreOpen, property.TriggerID, true);
                        param = new CFormPassParam(CBaseEnum.FormCase.Form_DeliverStep3, property, "开锁成功(快递员存件)");
                        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_PackagePutResult, CBaseEnum.RedirectType.Redirect_Next, param);
                        break;
                    case ReChoose:
                        // 重选格口的的开锁成功->界面显示
                        CCommondFunc.UpdateBox(boxid, CBaseEnum.BoxStatus.Box_Ideal.ordinal(), CBaseEnum.Lock_DispStoreOpen, property.TriggerID, true);
                        CDataMgr.MainHandle.ofrmDeliverStep3.ShowTipMsg("格口[" +  CCommondFunc.GetFormatBoxID(boxid) + "]开启成功");
                        break;
                }
                break;
            case CBaseEnum.Lock_DispRevokeOpen:
                // 快递员取货开锁（订单更改+更新格口）
                onPackageGetSuccess(CDataMgr.TDYOrderID, CDataMgr.CurrentBoxID, CBaseEnum.Package_RevokeComplete, CBaseEnum.Lock_DispRevokeOpen, property.TriggerID, "快递员取件");
                if (CDataMgr.BatchTake) {
                    param = new CFormPassParam(CBaseEnum.FormCase.Form_DeliverTackStep11, property, "开锁成功(快递员批量取件)");
                }
                else {
                     param = new CFormPassParam(CBaseEnum.FormCase.Form_DeliverTackStep1, property, "开锁成功(快递员单个取件)");
                }
                CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_PackageGetResult, CBaseEnum.RedirectType.Redirect_Next, param);
                break;
            case CBaseEnum.Lock_UserOpen:
                // 用户取货开锁（订单更改+更新格口）
                onPackageGetSuccess(CDataMgr.UserOrderID, boxid, CBaseEnum.Package_UserTackComplete, CBaseEnum.Lock_UserOpen, property.TriggerID, "用户取件");
                switch (CDataMgr.MainHandle.GetCurFormCase()) {
                    case Form_PwdInput:
                        if (11 == CDataMgr.LocalPwdType) {
                            param = new CFormPassParam(CBaseEnum.FormCase.Form_UserPackageStep1, property, "开锁成功(用户取件)");
                            CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_PackageGetResult, CBaseEnum.RedirectType.Redirect_Next, param);
                        }
                        break;
                    case Form_UserPackageStep1:
                        param = new CFormPassParam(CBaseEnum.FormCase.Form_UserPackageStep1, property, "开锁成功(用户取件)");
                        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_PackageGetResult, CBaseEnum.RedirectType.Redirect_Next, param);
                        break;
                }
                break;
            case CBaseEnum.Lock_ManualOpen:
                // 管理员开锁
                if (FormCase.Form_Device == CDataMgr.MainHandle.GetCurFormCase())
                    CDataMgr.MainHandle.ofrmDevice.ShowTipMsg("格口[" +  CCommondFunc.GetFormatBoxID(boxid) + "]开启成功 -- " + CHandleRelay.ConversionSensorValue(property.Infrared));

                if (CDataMgr.SupperManGet) {
                    onPackageGetSuccess("", property.BoxID, CBaseEnum.Package_ManualComplete, CBaseEnum.Lock_ManualOpen, property.TriggerID, "管理员取件");
                }
                break;
            case CBaseEnum.Lock_RemoteOpen:
                // 远程开锁
                func.CCommondFunc.AddRest_Execute("update tb_Box set fi_SyncStatus=1 where fi_DeviceID=" + CDataMgr.DeviceID + " and fi_BoxID=" + property.BoxID);
                onPackageGetSuccess("", property.BoxID, CBaseEnum.Package_RemoteComplete, CBaseEnum.Lock_RemoteOpen, property.TriggerID, "远程开锁取件");
                BoxFaultToIdeal(property);
                break;
            case CBaseEnum.Lock_YCXZOpen:
                // 远程协助
                if (FormCase.Form_YCXZ == CDataMgr.MainHandle.GetCurFormCase())
                    CDataMgr.MainHandle.ofrmYCXZ.ShowTipMsg("格口[" +  CCommondFunc.GetFormatBoxID(boxid) + "]开启成功");
                break;
            case CBaseEnum.Lock_ErrorOpen:
                // 异常格口开锁
                if (FormCase.Form_BoxError == CDataMgr.MainHandle.GetCurFormCase())
                    CDataMgr.MainHandle.ofrmBoxError.ShowTipMsg("格口[" +  CCommondFunc.GetFormatBoxID(boxid) + "]开启成功");
                break;
        }
    }
    
    public static synchronized void onCloseBoxCallBack(String boxid) {
        // 开箱信息获取
        String triggerID = ""; int triggerType = 0; int triggerTypeUpdate = 0; int lockStatus = 0; int infrared = 0; 
        String strSql = "select fs_TriggerID,fi_TriggerType,fi_LockStatus,fi_Infrared,fi_BoxStatus from tb_box where fi_DeviceID=" + CDataMgr.DeviceID + " and fi_BoxID="+ boxid;
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <onCloseBoxCallBack> sql=" + strSql); return ; }

        ResultSet rs = result.dataRs;;
        try {
            if (rs.next()) {
                triggerID = rs.getString("fs_TriggerID");
                triggerType = CCommondFunc.GetIntDB(rs.getString("fi_TriggerType"));
                lockStatus = CCommondFunc.GetIntDB(rs.getString("fi_LockStatus"));
                infrared = CCommondFunc.GetIntDB(rs.getString("fi_Infrared"));
            }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }

        // 判读当前操作错误格口跳转页面及返回页面
        boolean boxerr = false;
        if ("0".equals(CDataMgr.CurrentBoxID) || !CDataMgr.CurrentBoxID.equals(boxid)) {
            boxerr = true;
        }

        boolean IsPeopleOnsceneDone = true;// 用户现场操作

        String msg = "";
        FormCase showfrm = CBaseEnum.FormCase.Form_NULL;
        FormCase backfrm = CBaseEnum.FormCase.Form_NULL;
        switch (CDataMgr.CurrentAction){
            case CBaseEnum.Action_TDYCJ: 
                msg = "关门:当前快递员(" + CDataMgr.CurrentTriggerID + ")存件,格口:" + boxid + "关门,"; 
                showfrm = CBaseEnum.FormCase.Form_PackagePutResult; 
                break;
            case CBaseEnum.Action_TDYQJ: 
                msg = "关门:当前快递员(" + CDataMgr.CurrentTriggerID + ")取件,格口:" + boxid + "关门,"; 
                showfrm = CBaseEnum.FormCase.Form_PackageGetResult; 
                if (CDataMgr.BatchTake) backfrm = CBaseEnum.FormCase.Form_DeliverTackStep11; else backfrm = CBaseEnum.FormCase.Form_DeliverTackStep1; 
                break;
            case CBaseEnum.Action_YHQJ: 
                msg = "关门:当前用户(" + CDataMgr.CurrentTriggerID + ")取件,格口:" + boxid + "关门,"; 
                showfrm = CBaseEnum.FormCase.Form_PackageGetResult; backfrm = CBaseEnum.FormCase.Form_UserPackageStep1; 
                break;
            case CBaseEnum.Action_GLYQJ:  
                msg = "关门:管理员(" + CDataMgr.CurrentTriggerID + ")开锁,格口:" + boxid + "关门,"; 
                break;
//            case 5: 
//                msg = "关门:远程(" + CDataMgr.CurrentTriggerID + ")开锁,格口:" + boxid + "关门,"; 
//                break;
            case CBaseEnum.Action_YCXZQJ: 
                msg = "关门:远程协助(" + CDataMgr.CurrentTriggerID + ")开锁,格口:" + boxid + "关门,"; 
                break;
            default:
                msg = "关门:其他(" + CDataMgr.CurrentTriggerID + ")开锁,格口:" + boxid + "关门,"; 
                //UI.CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Normal, "关门:当前未操作,格口:" + boxid + "关门," + (infrared == 0 ? "有物" : "无物"));
                //return;// 未操作关闭格口跳过
                IsPeopleOnsceneDone = false;
                break;
        }
        //UI.CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Normal, msg + (infrared == 0 ? "有物" : "无物"));

        // 格口关闭处理
        CBoxProperty property = new CBoxProperty();
        property.BoxID = boxid;
        property.TriggerID = triggerID;
        property.TriggerType = triggerType;
        property.LockStatus = lockStatus;
        property.Infrared = infrared;
        CFormPassParam param = null;

        if (showfrm == CBaseEnum.FormCase.Form_PackagePutResult) {
            // 投递员投件完关门
            property.TriggerType = triggerTypeUpdate = CBaseEnum.Lock_DispStoreClose;
            param = new CFormPassParam(CBaseEnum.FormCase.Form_DeliverStep3, property, "");
            CCommondFunc.UpdateBox(boxid, CBaseEnum.BoxStatus.Box_Ideal.ordinal(), triggerTypeUpdate, triggerID, false);// 更新格口
            if (!CDataMgr.CurrentBoxHasClose) {
                // 还未正常关闭
                CBoxProperty temp = GetOpenBoxItems(boxid);
                if (boxerr) {
                    boolean cwts = false;// 错误提示
                    if (temp != null && temp.EBoxAction == BoxAction.ReChoose) {
                        if (0 == infrared) {
                            cwts = true;// 重选格口关闭原先格口无物不进行错误格口提示处理
                        }
                    }
                    else {
                        if (CDataMgr.CurrentBoxHasOpen && FormCase.Form_DeliverStep3 != CDataMgr.MainHandle.GetCurFormCase()) cwts = true;
                    }

                    if (cwts && 0 == infrared) {
                        // 格口操作错误(除重选格口外)
                        property.Error = true;
                        property.Result = -1;
                        CDataMgr.MainHandle.OnEventShowForm(showfrm, CBaseEnum.RedirectType.Redirect_Next, param);
                    }
                }
                else {
                    if (temp != null && temp.EBoxAction != BoxAction.ReChoose) {
                        property.Error = false;
                        CDataMgr.CurrentBoxHasClose = true;
                        CTxtHelp.AppendLog("[Info] CurrentBoxHasClose=true,格口操作正确且忽略后面的错误关好格口信息");
                        // 开锁反馈格口号与投递员投件选择格口号相同（订单添加）
                        if (infrared == 0) {
                            // 快递员关门有物品直接跳转(订单添加+更新格口)
                            onPackagePutSuccess(boxid, 0, "有物存件成功");
                            CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_DeliverStep1, CBaseEnum.RedirectType.Redirect_Next, null);
                        }
                        else {
                            // 没有检测到包裹，请选择是否重新投递
                            property.Result = 2;
                            CDataMgr.MainHandle.OnEventShowForm(showfrm, CBaseEnum.RedirectType.Redirect_Next, param);
                        }
                    }
                }
            }
        }
        else  {
            // 投递员取件关门 / 用户取件关门 / 管理员取件关门 / 远程开锁关门
            switch (triggerType) {
                case CBaseEnum.Lock_DispRevokeOpen: triggerTypeUpdate = CBaseEnum.Lock_DispRevokeClose; break;
                case CBaseEnum.Lock_UserOpen: 
                    triggerTypeUpdate = CBaseEnum.Lock_UserClose; 
                    break;
                case CBaseEnum.Lock_ManualOpen: 
                    triggerTypeUpdate = CBaseEnum.Lock_ManualClose; 
                    if (!boxerr && FormCase.Form_Device == CDataMgr.MainHandle.GetCurFormCase())
                        CDataMgr.MainHandle.ofrmDevice.ShowTipMsg("格口[" +  CCommondFunc.GetFormatBoxID(boxid) + "]已经关闭 -- " + CHandleRelay.ConversionSensorValue(property.Infrared));
                    break;
                case CBaseEnum.Lock_RemoteOpen: triggerTypeUpdate = CBaseEnum.Lock_RemoteClose; break;
                case CBaseEnum.Lock_YCXZOpen: 
                    triggerTypeUpdate = CBaseEnum.Lock_YCXZClose; 
                    if (!boxerr && FormCase.Form_YCXZ == CDataMgr.MainHandle.GetCurFormCase())
                        CDataMgr.MainHandle.ofrmYCXZ.ShowTipMsg("格口[" +  CCommondFunc.GetFormatBoxID(boxid) + "]已经关闭");
                    break;
                case CBaseEnum.Lock_ErrorOpen: 
                    triggerTypeUpdate = CBaseEnum.Lock_ErrorClose; 
                    if (!boxerr && FormCase.Form_BoxError == CDataMgr.MainHandle.GetCurFormCase())
                        CDataMgr.MainHandle.ofrmBoxError.ShowTipMsg("格口[" +  CCommondFunc.GetFormatBoxID(boxid) + "]已经关闭");
                    break;
                default:
                    CTxtHelp.AppendLog("[Error] onCloseBoxCallBack,异常格口关闭,BoxID=" + boxid + ",TriggerType=" + triggerType);
                    break;
            }

            property.TriggerType = triggerTypeUpdate;
            CCommondFunc.UpdateBox(boxid, CBaseEnum.BoxStatus.Box_Ideal.ordinal(), triggerTypeUpdate, triggerID, false);// 更新格口

            if (!CDataMgr.CurrentBoxHasClose) {
                if (boxerr) {
                    property.Error = true;
                }
                else {
                    property.Error = false;
                    CDataMgr.CurrentBoxHasClose = true;

                    if (infrared == 0)
                        property.Result = 4;// 有物提示
                    else
                        property.Result = 3;
                }

                if (IsPeopleOnsceneDone && CBaseEnum.FormCase.Form_NULL != showfrm) {
                    // 需要刷新的进行跳转
                    if (CBaseEnum.Lock_Null != triggerType) {
                        param = new CFormPassParam(backfrm, property, "");
                        CDataMgr.MainHandle.OnEventShowForm(showfrm, CBaseEnum.RedirectType.Redirect_Next, param);
                    }
                }
            }
        }

        if (boxerr) {
            UI.CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Error_Operation, "提示:格口错误关闭," + (infrared == 0 ? "有" : "无") + "包裹;格口:" + boxid);
        }

        CheckBox(boxid, triggerType);

        CTxtHelp.AppendLog("[Info] onCloseBoxCallBack,OpenCount=" + openBoxItems.size() + ",BoxID=" + boxid  + ",LockStatus=" + 2 + 
                            ",TriggerType=" + triggerTypeUpdate + ",TriggerID=" + triggerID + ",Infrared=" + infrared);
        CCommondFunc.UpdateBoxEventLog(boxid, triggerTypeUpdate, triggerID, 2, infrared, "格口[" + CCommondFunc.GetFormatBoxID(boxid) + "]关闭成功");
    }
    
    static void CheckBox(String boxid, int triggerType) {
        if (CCommondFunc.IsIdealAndInfrared(boxid)) {
            // 空闲有物
            String boxid1 = CDataMgr.CurrentBoxID; // 正确格口
            String boxid2 = boxid; // 错误格口
            String orderid = "";  String pid = ""; String pwd = ""; String note = "";
            boolean add = true;
            
            switch (CDataMgr.CurrentAction){
                // 在当前操作范围内
                case CBaseEnum.Action_TDYCJ: note = "存件时存错格口1"; break;
                case CBaseEnum.Action_TDYQJ: note = "取回后还有包裹1"; break;
                case CBaseEnum.Action_YHQJ: note = "取件后还有包裹1"; break;
                // 不在当前操作范围内
                default: 
                    orderid = "unknown";
                    switch (triggerType) {
                        case CBaseEnum.Lock_DispStoreOpen:
                            note = "存件时存错格口2";
                            break;
                        case CBaseEnum.Lock_DispRevokeOpen: 
                            note = "取回后还有包裹2";
                            break;
                        case CBaseEnum.Lock_UserOpen: 
                            note = "取件后还有包裹2";
                            break; 
                        default:
                            note = "其他异常操作";
                            add = false;
                            break;
                    }
                    break;
            }

            if (CDataMgr.IsTDY) {
                // 投递员操作范围内判断关门者及订单号
                pid = CDataMgr.TDYPhone; pwd = CDataMgr.TDYPwd; 
                if (!"unknown".equals(orderid)) orderid = CDataMgr.TDYOrderID; 
            }
            else if (CBaseEnum.Action_YHQJ == CDataMgr.CurrentAction) {
                // 用户操作范围内判断关门者及订单号
               pid = CDataMgr.UserPID; pwd = CDataMgr.UserPwd; 
               if (!"unknown".equals(orderid)) orderid = CDataMgr.UserOrderID; 
            }
            if (add) CCommondFunc.AddBoxError(orderid, boxid1, boxid2, pid, pwd, note);
        }
    }
    
    public static synchronized void onPackagePutSuccess(String boxid, int outtime, String tag) {
        if (CCommondFunc.txtOrderID_Validated(CDataMgr.TDYOrderID, " and fi_Status=" + CBaseEnum.Package_DeliverComplete, null, 0)) {
            CTxtHelp.AppendLog("[Error] 存在相同的未取订单(普通业务),不允许[再次存件],订单:" + CDataMgr.TDYOrderID);
            return;
        }
        String tipmsg = "存件成功,orderid=" + CDataMgr.TDYOrderID + ",phone=" + CDataMgr.YHPhone + ",boxid=" + boxid + ",msg=" + tag;
        CTxtHelp.AppendLog("[Info] " + tipmsg);
        //CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Normal, tipmsg);
        //RemoveOpenBoxItems(boxid);
        
        CCommondFunc.AddNewOrder(boxid, outtime, tag);
        CCommondFunc.UpdateBox(boxid, CBaseEnum.BoxStatus.Box_Busy.ordinal(), CBaseEnum.Lock_DispStoreClose, CDataMgr.TDYPhone, true);
        
        // 交易报文发送(获取短信动态码)
        CWebApiHandleBase.Process6003(CDataMgr.TDYOrderID, boxid, 0);
    }
    
    public static void onPackageGetSuccess(String orderid, String boxid, int status, int lockopener, String tiggerid, String content) {
        String tipmsg = "取件成功,orderid=" + orderid + ",boxid=" + boxid + ",tiggerid=" + tiggerid;
        CTxtHelp.AppendLog("[Info] " + tipmsg);
        //CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Normal, tipmsg);
        //RemoveOpenBoxItems(boxid);
        
        CCommondFunc.UpdateOrder(orderid, boxid, status, tiggerid, content);
        CCommondFunc.UpdateBox(boxid, CBaseEnum.BoxStatus.Box_Ideal.ordinal(), lockopener, tiggerid, true);
    }

    static void BoxFaultToIdeal(CBoxProperty property) {
        if (3 == property.BoxStatus) {
            String strUpdateWhere = " where fi_DeviceID=" + CDataMgr.DeviceID + " and fi_BoxID=" + property.BoxID;
            String strSql = "update tb_Box set fi_FaultCount=0,fi_BoxStatus=" + CBaseEnum.BoxStatus.Box_Ideal.ordinal() + ",fs_Content='远程开锁成功,格口自动修复[" + mydate.CDateHelper.GetNowTime() + "]'" + strUpdateWhere;
            func.CCommondFunc.SyncExecuteSql(strSql);// 故障改空闲
        }
    }
}
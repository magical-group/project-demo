package UI;

import DB.CDBHelper;
import DB.QueryEntity;
import FuncClass.CCommondFunc;
import FuncClass.CDataMgr;
import HLDBoard.CHardwareMonitor;
import HLDClient.CWebApiHandleBase;
import ch.ubique.inieditor.IniEditor;
import com.ice.jni.registry.RegStringValue;
import com.ice.jni.registry.Registry;
import com.ice.jni.registry.RegistryException;
import com.ice.jni.registry.RegistryKey;
import func.CPipeHelp;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import mydata.CDataHelper;
import mydate.CDateHelper;
import mydate.TimeEntity;
import rest.CRestHelper;
import rest.PostResult;
import txt.CTxtHelp;

public class CSystemDAO {
    private static class SystemStoreHolder {
        private static final CSystemDAO instance = new CSystemDAO();
    }
    
    public static CSystemDAO getInstance() {
        return SystemStoreHolder.instance;
    }
    
    private static class INIStoreHolder {
        private static final IniEditor instance = new IniEditor();
    }

    public static IniEditor getInstance_ini() {
        return INIStoreHolder.instance;
    }

    String iniFileName = "AppConfig.txt";
    String iniPath = System.getProperty("user.dir") + File.separator + "soft" + File.separator + iniFileName;

    public String ServerIp = "";
    public int SocketPort = 8850;
    public int RestPort = 8851;
    
    public String Serial_HldBoard = "";
    public String Serial_Keyboard= "";
    public String DeviceName = "csj";
    public String DeviceAddress = "hld";
    public int Company = 0;   
        
    long towmonth = 1000 * 60 * 60 * 24 * 60;
    boolean isOpenBarCode = false;
    
    // 加载ini
    public String LoadINI() {
        try {
            File inifile = new File(iniPath);
            if (!inifile.exists()) {
                return " 配置文件不存在:" + iniFileName;
            }
            CSystemDAO.getInstance_ini().load(new InputStreamReader(new FileInputStream(inifile), "UTF-8"));// 以gbk方式读取txt文件信息CSystemDAO.getInstance_ini().load(inifile);
        } catch (IOException ex) {
            CTxtHelp.AppendLog("[Error] [CSystemDAO]<LoadINI>:" + ex.getMessage());
            return " 配置文件加载出错1:" + iniFileName;
        }
        
        try {
            // SystemParam
            ServerIp = CSystemDAO.getInstance_ini().get("SystemParam", "ServerIp");
            SocketPort = Integer.parseInt(CSystemDAO.getInstance_ini().get("SystemParam", "SocketPort"));
            RestPort  = Integer.parseInt(CSystemDAO.getInstance_ini().get("SystemParam", "RestPort"));
            SetIni("SystemParam", "Version", CDataMgr.SoftVerSion);// 版本信息写入配置
    
            // DeviceParam
            CDataMgr.DeviceID = CSystemDAO.getInstance_ini().get("DeviceParam", "DeviceID");
            CDataMgr.DeviceName = CSystemDAO.getInstance_ini().get("DeviceParam", "DeviceName");
            Serial_HldBoard = CSystemDAO.getInstance_ini().get("DeviceParam", "Serial_HldBoard");
            Serial_Keyboard = CSystemDAO.getInstance_ini().get("DeviceParam", "Serial_Keyboard");
            int index = 0;
            if (CDataMgr.ESystemType == CBaseEnum.SystemType.LINUX) {
                index = Integer.parseInt(Serial_HldBoard.substring(Serial_HldBoard.length() - 1, Serial_HldBoard.length()));
                Serial_HldBoard = "/dev/ttyS" + String.valueOf(index - 1);
            }
            Company = Integer.parseInt(CSystemDAO.getInstance_ini().get("DeviceParam", "Company"));
            DeviceName = CSystemDAO.getInstance_ini().get("DeviceParam", "DeviceName");
            DeviceAddress = CSystemDAO.getInstance_ini().get("DeviceParam", "DeviceAddress");
            
            String urlBase = "http://" + ServerIp + ":" + RestPort + "/ApiService/";
            CDataMgr.RestUrl_GetDataTable = urlBase + "Download";
            CDataMgr.RestUrl_ExecuteNonQuery = urlBase + "Upload";
            CDataMgr.RestUrl_Process = urlBase + "Process";
        }
        catch (NumberFormatException ex) {
            return " 配置文件加载出错2:" + iniFileName + ",err:" + ex.getMessage();
        }

        return "";
    }
    
    public void SetIni(String Param, String key, String value) {
        CSystemDAO.getInstance_ini().set(Param, key, value);
        try {
            CSystemDAO.getInstance_ini().save(new File(iniPath));
        } 
        catch (IOException ex) {  
            CTxtHelp.AppendLog("[Error] [CSystemDAO]<SetIni>:" + ex.getMessage());
        }
    }
    
    public void startProcess_Linux_Teamview() {
        switch (CDataMgr.ESystemType) {
             case WINDOW:
                 break;
             case LINUX:
                // 启动teamviewer
                try { Runtime.getRuntime().exec("/opt/teamviewer9/tv_bin/script/teamviewer"); } catch (IOException ex) { }
                break;
        }
    }
    
    void SoftInsteadDesktop_Window () {
        String folder = "SOFTWARE"; String subKeyNode = "Microsoft\\Windows NT\\CurrentVersion\\Winlogon";
        String subKeyName = "Shell"; String subKeyValue = "explorer.exe";
        
        try {
            RegistryKey software = Registry.HKEY_LOCAL_MACHINE.openSubKey(folder);
            RegistryKey subKey = software.createSubKey(subKeyNode, "");
            subKey.setValue(new RegStringValue(subKey, subKeyName, subKeyValue));
            subKey.closeKey();
        } catch (RegistryException ex) {  CTxtHelp.AppendLog("[Error] [CSystemDAO]<SoftInsteadDesktop_Window>:" + ex.getMessage()); }
    }
    
    public String GetSystemStartTime() {
        String ret = "";
        switch (CDataMgr.ESystemType) {
             case WINDOW:
                ret = GetSystemStartTime_Window();
                break;
             case LINUX:
                ret = GetSystemStartTime_Linux();
                break;
        }
        
        return ret;
    }
    
    public static String GetSystemStartTime_Window() {
        String ret = "";
        // 
        try {
            Process p = null;
            String cmd =  "cmd /c net statistics workstation";
            p = Runtime.getRuntime().exec(cmd);             
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream(), "gbk"));// getErrorStream()
            int i = 0;   
            String line = "";   
            while ((line = br.readLine()) != null) {   
                if (i == 3) {   
                    ret = line; 
                    break;
                }  
                i++;
            }
            br.close();
        }
        catch (Exception ex) {  CTxtHelp.AppendLog("[Error] [CSystemDAO]<GetSystemStartTime>:" + ex.getMessage()); }  

        return "Window,ComputerStartTime=" + ret;
    }
    
    public String GetSystemStartTime_Linux() {
        String ret = "";
        // 
        try {
            Process p = null;
            String cmd =  "uptime";
            p = Runtime.getRuntime().exec(cmd);             
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));// getErrorStream()
            String line = br.readLine();
            String flg1 = "up"; String flg2 = ",";
            if (null != line && !"".equals(line) && line.toLowerCase().contains(flg1) && line.toLowerCase().contains(flg2)) {
                int start = line.indexOf(flg1);
                int end = line.indexOf(flg2);
                ret = line.substring(start, end);
                ret = ret.replace(flg1, "").trim();
            }
            br.close();
        }
        catch (Exception ex) {  CTxtHelp.AppendLog("[Error] [CSystemDAO]<GetSystemStartTime>:" + ex.getMessage()); }  

        return "ComputerRunTime=" + ret;
    }

    public String LoadCOM_Device() {
        boolean ret = false; StringBuffer strMsg = new StringBuffer();
        ret = CHardwareMonitor.getInstance().HldSP.OpenSerialPort(Serial_HldBoard, 115200, strMsg);
        if (!"".equals(strMsg.toString())) {
            return "加载串口失败_主板:" + Serial_HldBoard + "," + strMsg.toString();
        }
        
        return "";
    }
    
    public String LoadCOM_Key() {
        // 启用金属键盘
        StringBuffer strMsg = new StringBuffer();
        CHardwareMonitor.getInstance().KeySP.OpenSerialPort(Serial_Keyboard, 9600, strMsg);
        if (!"".equals(strMsg.toString())) {
            return "加载串口失败_金属键盘:" + Serial_Keyboard;
        }
        
        return "";
    }
    
    public String UpdateBoxFromRelay() {
        StringBuffer strMsg = new StringBuffer();
        
        // 读锁状态不更新
        boolean boxleft = CHardwareMonitor.getInstance().HldSP.ReadBoxLeft(strMsg);
        if (!boxleft) {
            return "读取左侧格口失败：" + strMsg;
        }
        boolean boxright = CHardwareMonitor.getInstance().HldSP.ReadBoxRight(strMsg);
        if (!boxright) {
            return "读取右侧格口失败：" + strMsg;
        }
        
        return "";
    }
    
    public void ReadPower() {
        StringBuffer strMsg = new StringBuffer();
        CHardwareMonitor.getInstance().HldSP.ReadPower(strMsg);
    }
    
    public void OpenFaileReadBox(String boxid) {
        try { Thread.sleep(20); }  catch (InterruptedException e)  {}
        
        StringBuffer strMsg = new StringBuffer();
        
        if (Integer.parseInt(boxid) < 100000) {
            CHardwareMonitor.getInstance().HldSP.ReadBoxLeft(strMsg);
        }
        else if (Integer.parseInt(boxid) > 100000) {
            CHardwareMonitor.getInstance().HldSP.ReadBoxRight(strMsg);
        }
    }
    
    public void OpenBarCode() {
        if (isOpenBarCode) return;
        isOpenBarCode = true;
        CHardwareMonitor.getInstance().HldSP.SetCoderWakeup(new StringBuffer());
    }
    
    public void CloseBarCode() {
        if (isOpenBarCode) {
            isOpenBarCode = false;
            CHardwareMonitor.getInstance().HldSP.SetCoderSleep(new StringBuffer());
        }
    }
        
    public void ClearLog() {
        ClearLogDB();
        ClearFile(CTxtHelp.GetLogPath());// log_run
    }
    
    void ClearLogDB() {
        int[] arrTime = CDateHelper.getInstance().GetTime2(new Date());
        int year = arrTime[0];
        int month = arrTime[1];
        int day = arrTime[2];

        month = month - 2;
        switch (month) {
            case -1: year--; month = 11; break;
            case 0: year--; month = 12; break;
        }
        String strSql = ""; String formtime = year + "-" + CCommondFunc.lpad(month, 2) + "-" + CCommondFunc.lpad(day, 2) + " 23:59:59";  // 格式：yyyy-MM-dd 
        
        strSql = "delete from tb_BoxError where fi_State=1 and fs_Time2 <='" + formtime + "' and fi_DeviceID=" + CDataMgr.DeviceID;
        func.CCommondFunc.SyncExecuteSql(strSql);

        strSql = "delete from tb_BoxEventLog where fs_DateTime <='" + formtime + "' and fi_DeviceID=" + CDataMgr.DeviceID;
        CDBHelper.getInstance().Execute(strSql);
        
         // 清除多次添加的更新格口状态信息,防止多余数据冗余造成流量超标(多加空格以区别命令)
        strSql ="delete from tb_OffLineData where (fs_Data like ' update tb_Box set fi_LockStatus%') or (fs_Data like ' update tb_Box set fi_Infrared%')";
        CDBHelper.getInstance().Execute(strSql);
        
        strSql = "delete from tb_Order where fi_Status<>1 and fs_PickUpTime <='" + formtime + "' and fi_DeviceID=" + CDataMgr.DeviceID;
        CDBHelper.getInstance().Execute(strSql); // 订单部清除
    }
    
    void ClearFile(String dataDir) {
        int[] arrNow = CDateHelper.getInstance().GetTime2(new Date());
        int year = arrNow[0];
        int month = arrNow[1];
        int day = arrNow[2];

        month = month - 2;
        switch (month) {
            case -1: year--; month = 11; break;
            case 0: year--; month = 12; break;
        }
                
        File dir = new File(dataDir);
         if (dir.exists()) {
            File[] fs = dir.listFiles();
            
            for (File f : fs) {
                int[] arrFile = CDateHelper.getInstance().GetTime2(new Date(f.lastModified()));
                
                if (f.isFile() && (arrFile[0] <= year && arrFile[1] <= month && arrFile[2] <= day)) {
                    f.delete();
                }
            }
        }
    }

    boolean m_bExit = false;
    int interval = 100;// 1分钟 * 60
    public volatile long nexttime = 0;
    
    public void StartThread_Run() {
        (new Thread(new AppRun1())).start();// 喂狗
        (new Thread(new AppRun2())).start();// 自动重启
        (new Thread(new AppRun3())).start();// 离线数据
    }

    class AppRun1 implements Runnable {
        @Override
        public void run() {        
            int time = 1000 * 5;  
            
            while (!m_bExit) { 
                try { 
                    CPipeHelp.Write();
                }
                catch (Exception ex)  {
                    CTxtHelp.AppendLog("[Error] <AppRun1>:" + ex.getMessage());
                }
                try { Thread.sleep(time); }  catch (InterruptedException e)  {}
            }
        }
    }
    
    class AppRun2 implements Runnable {
        @Override
        public void run() {
            int hour = 3;
            int minute = 0;
            
            // 分时重启升级
            try {
                int num = Integer.parseInt(CDataMgr.DeviceID.substring(CDataMgr.DeviceID.length() - 1));
                switch (num) {
                    case 0:
                    case 1: minute = 0; break;
                    case 2:
                    case 3: minute = 10; break;
                    case 4:
                    case 5: minute = 20; break;
                    case 6:
                    case 7: minute = 30; break;
                    case 8:
                    case 9: minute = 40; break;
                }
            }
            catch (Exception ex) {}
            
            while (!m_bExit) {
                try { Thread.sleep(interval); }  catch (InterruptedException e)  {}
                
                // 每天3点重启电脑
                try {
                    if (Integer.parseInt(new SimpleDateFormat("HH").format(new Date())) == hour
                        && Integer.parseInt(new SimpleDateFormat("mm").format(new Date())) == minute) {
                        if (1 == Integer.parseInt(new SimpleDateFormat("dd").format(new Date()))) {
                            //CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_NetCount, "系统重启," + CSystemDAO.getInstance().GetNetCount() + ",离线总数:" + CCommondFunc.GetCount_OffLineData());
                            CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Error_HardWare, "系统重启");
                            try { Thread.sleep(60000); }  catch (InterruptedException e)  {}// 休眠1分钟后关闭
                            CCommondFunc.ReRunComputer();
                        }
                        else {
                            //CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_NetCount, "软件重启," + CSystemDAO.getInstance().GetNetCount() + ",离线总数:" + CCommondFunc.GetCount_OffLineData());
                            CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Error_HardWare, "软件重启");
                            try { Thread.sleep(60000); }  catch (InterruptedException e)  {}
                            System.exit(0);
                        }
                    }
                }
                catch (Exception ex)  {
                    CTxtHelp.AppendLog("[Error] <AppRun1>:" + ex.getMessage());
                }
            }
        }
    }
 
    class AppRun3 implements Runnable {
        @Override
        public void run() {
            String chr1 = System.getProperty("line.separator"); String chr = "##";
            ArrayList<COffDataProperty> lstOff = new ArrayList();           
            int time = 5000 * 1;  
            
            while (!m_bExit) {
                try { Thread.sleep(time); }  catch (InterruptedException e)  {}
                
                try {
                    lstOff.clear();

                    // 查询数据库中是否需要上传的rest数据
                    String strSql = "select fi_ID,fi_Type,fs_Data from tb_OffLineData order by fi_ID asc limit 0,50";
                    QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
                    if (result.hasData) {
                        ResultSet rs = result.dataRs;;
                        try {
                            while (rs.next()) {
                                COffDataProperty entity = new COffDataProperty();
                                entity.ID = Integer.parseInt(rs.getString("fi_ID")); 
                                entity.Type  = Integer.parseInt(rs.getString("fi_Type")); 
                                entity.Data = rs.getString("fs_Data");
                                if (entity.Data.contains(chr1)) entity.Data = entity.Data.replace(chr1, chr);// 特殊符号处理
                                lstOff.add(entity);
                            } 
                        }
                        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
                        finally {
                            CDBHelper.getInstance().closeQuery(result);
                        }
                    }
                    
                    boolean neterror = false;
                    for (int i = 0; i < lstOff.size(); i++) {
                        if (neterror) break; 
                        COffDataProperty entity1 = lstOff.get(i);
                        switch (entity1.Type) {
                            case func.CCommondFunc.OffLine_Execute:
                                if (CRestHelper.ExecuteNonQuery(CDataMgr.RestUrl_ExecuteNonQuery, entity1.Data) == PostResult.NETERROR) {
                                    neterror = true;
                                }
                                else {
                                    CDBHelper.getInstance().Execute("delete from tb_OffLineData where fi_ID=" + entity1.ID);
                                }
                                break;
                            case func.CCommondFunc.OffLine_Process:
                                PostResult entity2 = CRestHelper.Process(CDataMgr.RestUrl_Process, entity1.Data);
                                if (entity2.Code == PostResult.NETERROR) {
                                    neterror = true;
                                }
                                else {
                                    CDBHelper.getInstance().Execute("delete from tb_OffLineData where fi_ID=" + entity1.ID);
                                    String info = entity2.Info;
                                    String err = entity2.ErrMsg;
                                    if (0 == err.length()) {
                                        String[] contentItems = info.split("#");
                                        int ywbh = CDataHelper.String2Int(contentItems[0]);// 邮柜编号
                                       
                                        switch (ywbh) {
                                            case 6000:
                                                break;
                                            case 6002:
                                                // 交易报文
                                                break;
                                            case 6003:
                                                // 发送密码
                                                String ygbh = contentItems[1];// 邮柜编号
                                                String jdbh = contentItems[2];// 订单编号
                                                String gkbh = contentItems[3];// 格口编号
                                                String qjmm = CCommondFunc.GetMD5(contentItems[4]);// 取件密码
                                                CDBHelper.getInstance().Execute("update tb_Order set fs_QJMM='" + qjmm + "' where fi_DeviceID=" + ygbh + " and fi_BoxID=" + gkbh + " and fs_OrderID='" + jdbh + "' and fi_Status=" + CBaseEnum.Package_DeliverComplete);
                                                break;
                                        }
                                    }
                                }
                                break;
                        }
                    }
                }
                catch (Exception ex)  {
                    CTxtHelp.AppendLog("[Error] <AppRun3>:" + ex.getMessage());
                }
            }
        }
    }

    public void AddWebLog(int msgType, String msgContent) {
        String orderID = "";
        switch (CDataMgr.CurrentAction){
            case CBaseEnum.Action_TDYCJ: orderID = CDataMgr.TDYOrderID; break;
            case CBaseEnum.Action_TDYQJ: orderID = CDataMgr.TDYOrderID; break;
            case CBaseEnum.Action_YHQJ: orderID = CDataMgr.UserOrderID; break;
        }
        TimeEntity entity = CDateHelper.GetNowTimeWithEntity();        
//        String strSql = "insert into tb_DeviceLog (fi_DeviceID,fs_OrderID,fi_HappenTime,fs_HappenTime,fi_MsgType,fs_Note) values ('" + CDataMgr.DeviceID + "','"+ orderID + "'," + entity.TimeStamp + ",'" + entity.TimeValue + "'," + msgType + ",'" + msgContent + "')";// 管理平台数据库表
//        func.CCommondFunc.AddRest_Execute(strSql);
        CWebApiHandleBase.Process6000(orderID, entity.TimeStamp, entity.TimeValue, msgType, msgContent);
    }
}
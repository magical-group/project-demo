package UI;

import FuncClass.CCommondFunc;
import FuncClass.CDataMgr;
import UI.CBaseEnum.FormCase;
import UI.CBaseEnum.KeyType;
import UI.CBaseEnum.RedirectType;
import java.awt.CardLayout;
import java.awt.Cursor;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.image.MemoryImageSource;
import txt.CTxtHelp;

public final class MainForm extends javax.swing.JFrame {

    public MainForm() {
        initComponents();
    }

    public void Init() {
        getContentPane().setLayout(contentLayout);
        
        CTxtHelp.AppendLog("[Info] Login In");
        
        CCommondFunc.GetSystemType();

        AddForm();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(6, 57, 104));
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(1024, 768));
        getContentPane().setLayout(new java.awt.CardLayout());

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                CDataMgr.MainHandle =  new MainForm();
                CDataMgr.MainHandle.setVisible(true);
                CDataMgr.MainHandle.Init();
            }
        });
    }
    
    // 光标设置(0:隐藏;1:显示)
    
    public void SetCursorShow(boolean hide) {
       if (hide)
            this.setCursor(CursorDefsult);
       else
            this.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(CursorNone, new Point(0, 0), null));
    }
    
    void AddForm() {
        getContentPane().add(ofrmLoad, String.valueOf(FormCase.Form_Load)); 
        getContentPane().add(ofrmStandBy, String.valueOf(FormCase.Form_StandBy)); 
        getContentPane().add(ofrmDeliverLogin, String.valueOf(FormCase.Form_DeliverLogin)); 
        getContentPane().add(ofrmPwdInput, String.valueOf(FormCase.Form_PwdInput)); 
        getContentPane().add(ofrmDeliverSelect, String.valueOf(FormCase.Form_DeliverSelect)); 
        getContentPane().add(ofrmDeliverStep1, String.valueOf(FormCase.Form_DeliverStep1)); 
        getContentPane().add(ofrmDeliverStep2, String.valueOf(FormCase.Form_DeliverStep2)); 
        getContentPane().add(ofrmDeliverStep3, String.valueOf(FormCase.Form_DeliverStep3)); 
        getContentPane().add(ofrmDeliverTackStep1, String.valueOf(FormCase.Form_DeliverTackStep1));
        getContentPane().add(ofrmDeliverTackStep11, String.valueOf(FormCase.Form_DeliverTackStep11));
        getContentPane().add(ofrmUserPackageStep1, String.valueOf(FormCase.Form_UserPackageStep1));
        getContentPane().add(ofrmPackagePutResult, String.valueOf(FormCase.Form_PackagePutResult)); 
        getContentPane().add(ofrmPackageGetResult, String.valueOf(FormCase.Form_PackageGetResult));
        getContentPane().add(ofrmDevice, String.valueOf(FormCase.Form_Device));
        getContentPane().add(ofrmMsg, String.valueOf(FormCase.Form_Msg));
        getContentPane().add(ofrmOrderFiler, String.valueOf(FormCase.Form_OrderFiler));
        getContentPane().add(ofrmBoxError, String.valueOf(FormCase.Form_BoxError));
        getContentPane().add(ofrmAgree, String.valueOf(FormCase.Form_Agree));
        getContentPane().add(ofrmCFDX, String.valueOf(FormCase.Form_CFDX));
        getContentPane().add(ofrmYCXZ, String.valueOf(FormCase.Form_YCXZ));
        getContentPane().add(ofrmGKJK, String.valueOf(FormCase.Form_GKJK));
        
        OnEventShowForm(FormCase.Form_Load, RedirectType.Redirect_Next, null);
    }
   
    public void OnEventShowForm(FormCase formNext, RedirectType eRedirectType, Object oParam) {
        try {
            contentLayout.show(getContentPane(), String.valueOf(formNext));
        }
        catch (Exception e)  {
            String err = "页面跳转异常," + e.getMessage();
            txt.CTxtHelp.AppendLog("[Error]" + err);
            UI.CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_SoftException, err);
            System.exit(0);
        }
        
        m_eCurFormCase = formNext;
        
        CTxtHelp.AppendLog("[UI] " + m_eCurFormCase);   
        
        switch (m_eCurFormCase){
            case Form_Load: ofrmLoad.BeginForm(eRedirectType, oParam); break;
            case Form_StandBy:
                CLogicHandle.RemoveOpenBoxAll();
                ofrmStandBy.BeginForm(eRedirectType, oParam);
                break;
            case Form_DeliverLogin: ofrmDeliverLogin.BeginForm(eRedirectType, oParam); break;
            case Form_PwdInput: 
                //CLogicHandle.RemoveOpenBoxAll();
                ofrmPwdInput.BeginForm(eRedirectType, oParam); 
                break;
            case Form_DeliverSelect: ofrmDeliverSelect.BeginForm(eRedirectType, oParam); break;
            case Form_DeliverStep1:
                CLogicHandle.RemoveOpenBoxAll();
                ofrmDeliverStep1.BeginForm(eRedirectType, oParam);
                break;
            case Form_DeliverStep2: ofrmDeliverStep2.BeginForm(eRedirectType, oParam); break;
            case Form_DeliverStep3: ofrmDeliverStep3.BeginForm(eRedirectType, oParam); break;// 参数不能为null
            case Form_DeliverTackStep1:
                CLogicHandle.RemoveOpenBoxAll();
                ofrmDeliverTackStep1.BeginForm(eRedirectType, oParam);
                break;  
            case Form_DeliverTackStep11:
                CLogicHandle.RemoveOpenBoxAll();
                ofrmDeliverTackStep11.BeginForm(eRedirectType, oParam);
                break;
            case Form_UserPackageStep1:
                CLogicHandle.RemoveOpenBoxAll();
                ofrmUserPackageStep1.BeginForm(eRedirectType, oParam);
                break;
            case Form_PackagePutResult: ofrmPackagePutResult.BeginForm(eRedirectType, oParam); break;// 参数不能为null
            case Form_PackageGetResult: ofrmPackageGetResult.BeginForm(eRedirectType, oParam); break;
            case Form_OrderFiler: if (FormCase.Form_StandBy != m_eCurFormCase1) ofrmOrderFiler.BeginForm(eRedirectType, oParam); break;
            case Form_BoxError: 
                CLogicHandle.RemoveOpenBoxAll();
                ofrmBoxError.BeginForm(eRedirectType, oParam); 
                break;
            case Form_Device: ofrmDevice.BeginForm(eRedirectType, oParam); break;
            case Form_Agree: ofrmAgree.BeginForm(eRedirectType, oParam); break;
            case Form_CFDX: ofrmCFDX.BeginForm(eRedirectType, oParam); break;
            case Form_YCXZ: 
                CLogicHandle.RemoveOpenBoxAll();
                ofrmYCXZ.BeginForm(eRedirectType, oParam); 
                break;  
            case Form_GKJK: ofrmGKJK.BeginForm(eRedirectType, oParam); break;    
        }
        
        m_eCurFormCase1 = m_eCurFormCase;
    }

    public void OnTTKeyBoardInput(KeyType eKeyType, String strInput) {     
        strInput = strInput.trim();
        
        switch (m_eCurFormCase){
            case Form_StandBy: ofrmStandBy.TTkeyBoardInput(eKeyType, strInput); break;
            case Form_DeliverLogin: ofrmDeliverLogin.TTkeyBoardInput(eKeyType, strInput); break;
            case Form_PwdInput: ofrmPwdInput.TTkeyBoardInput(eKeyType, strInput); break;
            case Form_DeliverSelect: ofrmDeliverSelect.TTkeyBoardInput(eKeyType, strInput); break;
            case Form_DeliverStep1: ofrmDeliverStep1.TTkeyBoardInput(eKeyType, strInput); break;
            case Form_DeliverStep2: ofrmDeliverStep2.TTkeyBoardInput(eKeyType, strInput); break;
            case Form_DeliverStep3: ofrmDeliverStep3.TTkeyBoardInput(eKeyType, strInput); break;
            case Form_DeliverTackStep1: ofrmDeliverTackStep1.TTkeyBoardInput(eKeyType, strInput); break;
            case Form_DeliverTackStep11: ofrmDeliverTackStep11.TTkeyBoardInput(eKeyType, strInput); break;
            case Form_UserPackageStep1: ofrmUserPackageStep1.TTkeyBoardInput(eKeyType, strInput); break;
            case Form_PackagePutResult: ofrmPackagePutResult.TTkeyBoardInput(eKeyType, strInput); break;
            case Form_PackageGetResult: ofrmPackageGetResult.TTkeyBoardInput(eKeyType, strInput); break;
            case Form_Device: ofrmDevice.TTkeyBoardInput(eKeyType, strInput); break;
            case Form_OrderFiler: ofrmOrderFiler.TTkeyBoardInput(eKeyType, strInput); break;
            case Form_BoxError: ofrmBoxError.TTkeyBoardInput(eKeyType, strInput); break;
            case Form_Agree: ofrmAgree.TTkeyBoardInput(eKeyType, strInput); break;
            case Form_CFDX: ofrmCFDX.TTkeyBoardInput(eKeyType, strInput); break;
            case Form_YCXZ: ofrmYCXZ.TTkeyBoardInput(eKeyType, strInput); break;
        }
    }
 
    public void OnICInput(String cardid) {
//        if (m_eCurFormCase == FormCase.Form_StandBy) {
//            // 与服务端数据比对
//            ofrmStandBy.AdminIntoBackground(true, "正在进入管理后台...");
//            String err = CCommondFunc.AdminIntoBackground(cardid);
//            if ("".equals(err)) {
//                CTxtHelp.AppendLog("[Info] 管理员刷卡进入后台");
//                CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_Device, CBaseEnum.RedirectType.Redirect_Next, null);
//            }
//            else {
//                ofrmStandBy.AdminIntoBackground(false, err);
//            }
//        }
    }
    
    public FormCase GetCurFormCase() {
        return m_eCurFormCase;
    }
    
    public void OnErrorBox(String boxid) {
        String msg1 = "格口[" + CCommondFunc.GetFormatBoxID(boxid) + "]开启成功";
        String msg2 = "请关好格口[" + CCommondFunc.GetFormatBoxID(CDataMgr.CurrentBoxID) + "]";
                
        switch (m_eCurFormCase) {
            case Form_PackagePutResult: ofrmPackagePutResult.ErrorBox(msg1, msg2); break;
            case Form_PwdInput: ofrmPwdInput.ErrorBox(msg1 +  msg2); break;
            case Form_PackageGetResult: ofrmPackageGetResult.ErrorBox(msg1, msg2); break;
        }
    }

    Image CursorNone = Toolkit.getDefaultToolkit().createImage(new MemoryImageSource(0, 0, new int[0], 0, 0));// 空光标
    Cursor CursorDefsult = new Cursor(Cursor.DEFAULT_CURSOR);
    
    CardLayout contentLayout = new CardLayout();
    final UI.frmLoad ofrmLoad = new UI.frmLoad();
    public final UI.frmStandBy ofrmStandBy = new UI.frmStandBy();
    public final UI.frmDeliverLogin ofrmDeliverLogin = new UI.frmDeliverLogin();
    public final UI.frmPwdInput ofrmPwdInput = new UI.frmPwdInput();
    public final UI.frmDeliverSelect ofrmDeliverSelect =  new UI.frmDeliverSelect();
    public final UI.frmDeliverStep1 ofrmDeliverStep1 =  new UI.frmDeliverStep1();
    final UI.frmDeliverStep2 ofrmDeliverStep2 =  new UI.frmDeliverStep2();
    public final UI.frmDeliverStep3 ofrmDeliverStep3 =  new UI.frmDeliverStep3();
    final UI.frmDeliverTackStep1 ofrmDeliverTackStep1 = new UI.frmDeliverTackStep1();
    final UI.frmDeliverTackStep11 ofrmDeliverTackStep11 = new UI.frmDeliverTackStep11();
    public final UI.frmUserPackageStep1 ofrmUserPackageStep1 =  new UI.frmUserPackageStep1();
    final UI.frmPackagePutResult ofrmPackagePutResult = new UI.frmPackagePutResult();
    final UI.frmPackageGetResult ofrmPackageGetResult = new UI.frmPackageGetResult();
    final UI.frmOrderFiler ofrmOrderFiler = new UI.frmOrderFiler();
    final UI.frmBoxError ofrmBoxError = new UI.frmBoxError();
    public final UI.frmDevice ofrmDevice = new UI.frmDevice();
    final UI.frmMsg ofrmMsg = new UI.frmMsg();
    final UI.frmAgree ofrmAgree = new UI.frmAgree();
    public final UI.frmCFDX ofrmCFDX= new UI.frmCFDX();
    public final UI.frmYCXZ ofrmYCXZ = new UI.frmYCXZ();
    final UI.frmGKJK ofrmGKJK = new UI.frmGKJK();
    
    FormCase m_eCurFormCase;
    FormCase m_eCurFormCase1;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
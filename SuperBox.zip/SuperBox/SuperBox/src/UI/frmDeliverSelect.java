package UI;

import java.util.Date;
import java.awt.Graphics;
import javax.swing.ImageIcon;
import java.text.SimpleDateFormat;
import FuncClass.CCommondFunc;
import FuncClass.CDataMgr;
import java.io.IOException;
import mydate.CDateHelper;
import txt.CTxtHelp;

public class frmDeliverSelect extends javax.swing.JPanel {
    int m_countget;
    int m_countput;
    
    public frmDeliverSelect() {
        initComponents();
    }
    
    @Override
    public void paintComponent(Graphics g){       
        ImageIcon icon = new ImageIcon(getClass().getResource(CDataMgr.BackImg));
        g.drawImage(icon.getImage(), 0, 0, getSize().width, getSize().height, this);
    }
    
    void ClearData() {
        lblTipMsg.setText("...");
        btnBoxError.setVisible(false);
        // 数据重置
        CCommondFunc.EndOrder();
    }
    
    void VoiceTip(String msg) {
        CCommondFunc.VoiceTip(msg);
    }
    
    public void TTkeyBoardInput(CBaseEnum.KeyType eKeyType, String strInput) {
        FuncClass.CBaseTime.ReSetTime();// 重新计时
        
        switch (eKeyType) {
            case Key_NUMBER:
                switch (strInput) {
                    case "1": btnOverDueActionPerformed(null); break;
                    case "2": btnDeliverActionPerformed(null); break;
                    case "3": btnOrderFilterActionPerformed(null); break;
                    case "4": if (btnBoxError.isVisible()) btnBoxErrorActionPerformed(null); break;
                }
                break;
            case Key_ESC:
                CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_StandBy, CBaseEnum.RedirectType.Redirect_Null, null);
                break;
        }
    }
    
    public void BeginForm(CBaseEnum.RedirectType eRedirectType, Object oParam) {
        CSystemDAO.getInstance().OpenBarCode();
        ClearData();
        FuncClass.CBaseTime.StartTime(lblSeconds, 60);
        
        // 逾期控制
        CDataMgr.DueTime = CDateHelper.GetNowTime(); 
        
        m_countget = CCommondFunc.GetBoxCount_Get(new SimpleDateFormat("yyyy-MM-dd 23:59:59").format(new Date()));
        m_countput = CCommondFunc.GetBoxCount_Put();
        lblTitle.setText("快递公司[" + CDataMgr.KDGS + "]");
        lblDue.setText("共" + CCommondFunc.lpad(m_countget, 2) + "件未取");// 共00件未取
        lblUsable.setText("共" + CCommondFunc.lpad(m_countput, 2) + "个可用");// 共00个可用
        if (0 != m_countget) btnOverDue.setEnabled(true); else btnOverDue.setEnabled(false);
        if (0 != m_countput) btnDeliver.setEnabled(true); else btnDeliver.setEnabled(false);
        
        if (CCommondFunc.HasBoxError(CDataMgr.TDYPhone, CDataMgr.TDYPwd)) {
            btnBoxError.setVisible(true);
            VoiceTip("您有异常订单，请查看");
        }
        else {    
            VoiceTip("请选择逾期未取或开始投递");
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnExit = new javax.swing.JButton();
        lblTimeOut1 = new javax.swing.JLabel();
        lblSeconds = new javax.swing.JLabel();
        lblTimeOut2 = new javax.swing.JLabel();
        lblTitle = new javax.swing.JLabel();
        btnOverDue = new javax.swing.JButton();
        btnDeliver = new javax.swing.JButton();
        lblDue = new javax.swing.JLabel();
        lblUsable = new javax.swing.JLabel();
        pnlTipMsg = new javax.swing.JPanel();
        lblTipMsg = new javax.swing.JLabel();
        btnOrderFilter = new javax.swing.JButton();
        btnBoxError = new javax.swing.JButton();
        pnlDo = new javax.swing.JPanel();
        lblDo = new javax.swing.JLabel();
        btnYCXZ = new javax.swing.JButton();
        btnVideo = new javax.swing.JButton();

        setBackground(new java.awt.Color(6, 57, 104));
        setPreferredSize(new java.awt.Dimension(1024, 768));

        btnExit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/btnExit.png"))); // NOI18N
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        lblTimeOut1.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut1.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut1.setText("执行操作界面还剩");

        lblSeconds.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblSeconds.setForeground(new java.awt.Color(255, 0, 0));
        lblSeconds.setText("60");

        lblTimeOut2.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut2.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut2.setText("秒，即将退出操作返回首页");

        lblTitle.setFont(new java.awt.Font("微软雅黑", 0, 36)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setText("快递公司:0001");

        btnOverDue.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/OverDue.png"))); // NOI18N
        btnOverDue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOverDueActionPerformed(evt);
            }
        });

        btnDeliver.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/Deliver.png"))); // NOI18N
        btnDeliver.setEnabled(false);
        btnDeliver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeliverActionPerformed(evt);
            }
        });

        lblDue.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblDue.setForeground(new java.awt.Color(255, 255, 255));
        lblDue.setText("共00件未取");

        lblUsable.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblUsable.setForeground(new java.awt.Color(255, 255, 255));
        lblUsable.setText("共00个可用");

        lblTipMsg.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblTipMsg.setForeground(new java.awt.Color(255, 0, 0));
        lblTipMsg.setText("...");

        javax.swing.GroupLayout pnlTipMsgLayout = new javax.swing.GroupLayout(pnlTipMsg);
        pnlTipMsg.setLayout(pnlTipMsgLayout);
        pnlTipMsgLayout.setHorizontalGroup(
            pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTipMsgLayout.createSequentialGroup()
                .addGap(186, 186, 186)
                .addComponent(lblTipMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 650, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pnlTipMsgLayout.setVerticalGroup(
            pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTipMsgLayout.createSequentialGroup()
                .addComponent(lblTipMsg)
                .addGap(0, 10, Short.MAX_VALUE))
        );

        btnOrderFilter.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/查询订单.png"))); // NOI18N
        btnOrderFilter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOrderFilterActionPerformed(evt);
            }
        });

        btnBoxError.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/异常格口.png"))); // NOI18N
        btnBoxError.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBoxErrorActionPerformed(evt);
            }
        });

        pnlDo.setBackground(new java.awt.Color(15, 68, 120));

        lblDo.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblDo.setForeground(new java.awt.Color(255, 0, 0));
        lblDo.setText("...");

        javax.swing.GroupLayout pnlDoLayout = new javax.swing.GroupLayout(pnlDo);
        pnlDo.setLayout(pnlDoLayout);
        pnlDoLayout.setHorizontalGroup(
            pnlDoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDoLayout.createSequentialGroup()
                .addGap(413, 413, 413)
                .addComponent(lblDo)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlDoLayout.setVerticalGroup(
            pnlDoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDoLayout.createSequentialGroup()
                .addComponent(lblDo)
                .addGap(0, 10, Short.MAX_VALUE))
        );

        btnYCXZ.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/远程协助.png"))); // NOI18N
        btnYCXZ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnYCXZActionPerformed(evt);
            }
        });

        btnVideo.setBackground(new java.awt.Color(15, 68, 120));
        btnVideo.setFont(new java.awt.Font("微软雅黑", 1, 18)); // NOI18N
        btnVideo.setText("监控视频");
        btnVideo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVideoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(186, 186, 186)
                .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTimeOut1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblSeconds)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTimeOut2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnOrderFilter, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(182, Short.MAX_VALUE))
            .addComponent(pnlTipMsg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnlDo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(lblTitle)
                        .addGap(371, 371, 371))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnOverDue, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblDue))
                        .addGap(81, 81, 81)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnDeliver, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblUsable))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnVideo, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnYCXZ, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBoxError, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(31, 31, 31))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addComponent(lblTitle)
                .addGap(45, 45, 45)
                .addComponent(pnlDo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnBoxError, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnYCXZ, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnOverDue)
                    .addComponent(btnDeliver)
                    .addComponent(btnVideo, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblDue)
                    .addComponent(lblUsable))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 140, Short.MAX_VALUE)
                .addComponent(pnlTipMsg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTimeOut1)
                            .addComponent(lblSeconds)
                            .addComponent(lblTimeOut2))
                        .addGap(29, 29, 29))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnOrderFilter, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15))))
        );

        lblTitle.getAccessibleContext().setAccessibleName("lblTitle");
    }// </editor-fold>//GEN-END:initComponents

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        TTkeyBoardInput(CBaseEnum.KeyType.Key_ESC, "");
    }//GEN-LAST:event_btnExitActionPerformed

    private void btnDeliverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeliverActionPerformed
        if (m_countput != 0) {
            CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_DeliverStep1, CBaseEnum.RedirectType.Redirect_Next, null);
        }
        else {
            lblTipMsg.setText("无可用箱柜!");
        }
    }//GEN-LAST:event_btnDeliverActionPerformed

    private void btnOverDueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOverDueActionPerformed
        if (m_countget != 0) {
            CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_DeliverTackStep1, CBaseEnum.RedirectType.Redirect_Next, null);
        }
         else {
            lblTipMsg.setText("无可取包裹!");
        }
    }//GEN-LAST:event_btnOverDueActionPerformed

    private void btnOrderFilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOrderFilterActionPerformed
        CTxtHelp.AppendLog("[UI] 订单查询");
        CDataMgr.LocalPwdType = 3;
        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_PwdInput, CBaseEnum.RedirectType.Redirect_Next, null);
    }//GEN-LAST:event_btnOrderFilterActionPerformed

    private void btnBoxErrorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBoxErrorActionPerformed
        CTxtHelp.AppendLog("[UI] 快递员异常格口取件");
        CDataMgr.LocalPwdType = 7;
        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_BoxError, CBaseEnum.RedirectType.Redirect_Next, null);
    }//GEN-LAST:event_btnBoxErrorActionPerformed

    private void btnYCXZActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnYCXZActionPerformed
        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_YCXZ, CBaseEnum.RedirectType.Redirect_Next, null);
    }//GEN-LAST:event_btnYCXZActionPerformed

    private void btnVideoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVideoActionPerformed
        CDataMgr.MainHandle.setAlwaysOnTop(false);// 窗体置前
        
        // 监控视频
        switch (CDataMgr.ESystemType) {
             case WINDOW:
                try { Runtime.getRuntime().exec(System.getProperty("user.dir") + java.io.File.separator + "soft" + java.io.File.separator + "lib" + java.io.File.separator + "DVRTest.exe"); } catch (IOException ex) { };
                break;
             case LINUX:
                try { Runtime.getRuntime().exec("./" + "DVRStart.sh"); } catch (IOException ex) { };
                break;
        } 
    }//GEN-LAST:event_btnVideoActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBoxError;
    private javax.swing.JButton btnDeliver;
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnOrderFilter;
    private javax.swing.JButton btnOverDue;
    private javax.swing.JButton btnVideo;
    private javax.swing.JButton btnYCXZ;
    private javax.swing.JLabel lblDo;
    private javax.swing.JLabel lblDue;
    private javax.swing.JLabel lblSeconds;
    private javax.swing.JLabel lblTimeOut1;
    private javax.swing.JLabel lblTimeOut2;
    private javax.swing.JLabel lblTipMsg;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblUsable;
    private javax.swing.JPanel pnlDo;
    private javax.swing.JPanel pnlTipMsg;
    // End of variables declaration//GEN-END:variables
}

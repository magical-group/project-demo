package UI;

import CustomControl.ITableButtenEvent;
import CustomControl.JTableButton;
import CustomControl.JTableData;
import DB.CDBHelper;
import DB.QueryEntity;
import FuncClass.CCommondFunc;
import FuncClass.CDataMgr;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import txt.CTxtHelp;

public class frmDeliverTackStep11 extends javax.swing.JPanel implements ITableButtenEvent {
    
    int columnIndex = 6;
    String[] columnNames = { "运单号", "格口号", "派件时间", "投递员-存", "取件时间", "用户", " " };
    final String m_strFileds = "fs_OrderID,fi_BoxID,substr(fs_DeliverTime,6,11) as fs_DeliverTime,fs_DeliverUid,substr(fs_PickUpTime,6,11) as fs_PickUpTime,fs_Phone";
    final int PageSize = 8;  //分頁行數
    int CurrentPageIndex = 1;   //現在選取的分頁編號
    int TotalPage = 0;  //總共多少分頁
    String m_strWhere = "";
    
    public frmDeliverTackStep11() {
        initComponents();
        JTableData.initTable(tableData, 50);
    }

    @Override
    public void paintComponent(Graphics g){
        ImageIcon icon = new ImageIcon(getClass().getResource(CDataMgr.BackImg));
        g.drawImage(icon.getImage(), 0, 0, getSize().width, getSize().height, this);
    }

    void VoiceTip() {
        CCommondFunc.VoiceTip("请选择需要取回的包裹");
    }

    public void TTkeyBoardInput(CBaseEnum.KeyType eKeyType, String strInput) {
        FuncClass.CBaseTime.ReSetTime();// 重新计时
        
        switch (eKeyType) {
            case Key_ESC:
                CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_StandBy, CBaseEnum.RedirectType.Redirect_Null, null);
                break;
        }
    }
    
    public void BeginForm(CBaseEnum.RedirectType eRedirectType, Object oParam) {
        FuncClass.CBaseTime.StartTime(lblSeconds, 60);
        VoiceTip();
        
        m_strWhere =  " fi_DeviceID=" + CDataMgr.DeviceID +
                    " and fi_UnitID ='" + CDataMgr.KDGS + "'" +
                    " and fi_Status=" + CBaseEnum.Package_DeliverComplete + 
                    " and fs_DeliverTime <='" + CDataMgr.DueTime + "'";
        GetTotalPages();
        btnFirstPageActionPerformed(null);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnExit = new javax.swing.JButton();
        lblTimeOut1 = new javax.swing.JLabel();
        lblSeconds = new javax.swing.JLabel();
        lblTimeOut2 = new javax.swing.JLabel();
        btnPreStep = new javax.swing.JButton();
        lblTitle = new javax.swing.JLabel();
        btnFirstPage = new javax.swing.JButton();
        btnPrevPage = new javax.swing.JButton();
        lbCurrentPage = new javax.swing.JLabel();
        lblSpace = new javax.swing.JLabel();
        lbTotalPage = new javax.swing.JLabel();
        btnNextPage = new javax.swing.JButton();
        btnLastPage = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableData = new javax.swing.JTable();

        setBackground(new java.awt.Color(6, 57, 104));

        btnExit.setBackground(new java.awt.Color(6, 57, 104));
        btnExit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/btnExit.png"))); // NOI18N
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        lblTimeOut1.setBackground(new java.awt.Color(6, 57, 104));
        lblTimeOut1.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut1.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut1.setText("执行操作界面还剩");

        lblSeconds.setBackground(new java.awt.Color(6, 57, 104));
        lblSeconds.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblSeconds.setForeground(new java.awt.Color(255, 0, 0));
        lblSeconds.setText("60");

        lblTimeOut2.setBackground(new java.awt.Color(6, 57, 104));
        lblTimeOut2.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut2.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut2.setText("秒，即将退出操作返回首页");

        btnPreStep.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/btnBack.png"))); // NOI18N
        btnPreStep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreStepActionPerformed(evt);
            }
        });

        lblTitle.setBackground(new java.awt.Color(6, 57, 104));
        lblTitle.setFont(new java.awt.Font("微软雅黑", 0, 36)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setText("批量取回");

        btnFirstPage.setFont(new java.awt.Font("微软雅黑", 1, 18)); // NOI18N
        btnFirstPage.setText("首页");
        btnFirstPage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstPageActionPerformed(evt);
            }
        });

        btnPrevPage.setFont(new java.awt.Font("微软雅黑", 1, 18)); // NOI18N
        btnPrevPage.setText("上一页");
        btnPrevPage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrevPageActionPerformed(evt);
            }
        });

        lbCurrentPage.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lbCurrentPage.setForeground(new java.awt.Color(255, 255, 255));
        lbCurrentPage.setText("0");

        lblSpace.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblSpace.setForeground(new java.awt.Color(255, 255, 255));
        lblSpace.setText("/");

        lbTotalPage.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lbTotalPage.setForeground(new java.awt.Color(255, 255, 255));
        lbTotalPage.setText("0");

        btnNextPage.setFont(new java.awt.Font("微软雅黑", 1, 18)); // NOI18N
        btnNextPage.setText("下一页");
        btnNextPage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextPageActionPerformed(evt);
            }
        });

        btnLastPage.setFont(new java.awt.Font("微软雅黑", 1, 18)); // NOI18N
        btnLastPage.setLabel("末页");
        btnLastPage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastPageActionPerformed(evt);
            }
        });

        tableData.setFont(new java.awt.Font("微软雅黑", 0, 15)); // NOI18N
        tableData.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tableData);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(100, 100, 100)
                        .addComponent(lblTitle))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(186, 186, 186)
                        .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnFirstPage, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnPrevPage, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(33, 33, 33)
                                .addComponent(lbCurrentPage)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lblSpace)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lbTotalPage)
                                .addGap(34, 34, 34)
                                .addComponent(btnNextPage, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnLastPage, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblTimeOut1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblSeconds)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblTimeOut2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnPreStep, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(179, Short.MAX_VALUE))
            .addComponent(jScrollPane2)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addComponent(lblTitle)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 497, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnFirstPage, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevPage, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNextPage, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLastPage, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbCurrentPage)
                    .addComponent(lblSpace)
                    .addComponent(lbTotalPage))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnPreStep, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTimeOut1)
                            .addComponent(lblSeconds)
                            .addComponent(lblTimeOut2))
                        .addGap(28, 28, 28))))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        TTkeyBoardInput(CBaseEnum.KeyType.Key_ESC, "");
    }//GEN-LAST:event_btnExitActionPerformed

    private void btnPreStepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreStepActionPerformed
        CDataMgr.MainHandle.OnEventShowForm(UI.CBaseEnum.FormCase.Form_DeliverTackStep1, CBaseEnum.RedirectType.Redirect_Pre, null);
    }//GEN-LAST:event_btnPreStepActionPerformed

    private void btnFirstPageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstPageActionPerformed
        // 首页
        CurrentPageIndex = 1;
        GetCurrentRecords(CurrentPageIndex);
    }//GEN-LAST:event_btnFirstPageActionPerformed

    private void btnPrevPageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrevPageActionPerformed
        // 上一页
        if (this.CurrentPageIndex > 1) {
            CurrentPageIndex--;
            GetCurrentRecords(CurrentPageIndex);
        }
    }//GEN-LAST:event_btnPrevPageActionPerformed

    private void btnNextPageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextPageActionPerformed
        // 下一页
        if (CurrentPageIndex < TotalPage) {
            CurrentPageIndex++;
            GetCurrentRecords(CurrentPageIndex);
        }
    }//GEN-LAST:event_btnNextPageActionPerformed

    private void btnLastPageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastPageActionPerformed
        // 末页
        CurrentPageIndex = TotalPage;
        GetCurrentRecords(CurrentPageIndex);
    }//GEN-LAST:event_btnLastPageActionPerformed
    
    void JumpPwdInput(String orderid) {
        CDataMgr.TDYOrderID = orderid;
        CDataMgr.LocalPwdType = 5;
        CDataMgr.MainHandle.OnEventShowForm(UI.CBaseEnum.FormCase.Form_PwdInput, CBaseEnum.RedirectType.Redirect_Pre, null);
    }

    // 计算页数
    void GetTotalPages() {
        String strSql = "select count(fi_ID) as nCount from tb_Order where " + m_strWhere + " order by fi_ID desc";
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (!result.hasData) { return ; }
        
        ResultSet rs = result.dataRs;;
        int rowCount = 0;
        
        try { if (rs.next()) { rowCount = CCommondFunc.GetIntDB(rs.getString("nCount")); } } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally { CDBHelper.getInstance().closeQuery(result); }
        
        TotalPage = rowCount / PageSize;
        if (rowCount % PageSize > 0) TotalPage += 1;//不足一個分頁行數的還是算一頁
        lbTotalPage.setText(String.valueOf(TotalPage));
    }
    
    //取得該分頁資料
    private void GetCurrentRecords(int page) {
        
        FuncClass.CBaseTime.ReSetTime();// 重新计时
        
        JTableData.setData(tableData, null, columnNames, columnIndex, this);
        lbCurrentPage.setText(String.valueOf(CurrentPageIndex)); 
        
        String strSql = "";
        if (page == 1)
           strSql = "select " + m_strFileds + " from tb_Order where " + m_strWhere + " order by fi_ID desc limit 0, " + PageSize;
        else
        {
            int PreviousPageOffSet = (page - 1) * PageSize;
            strSql = "select " + m_strFileds + " from tb_Order where " + m_strWhere +
                    " and fi_ID not in (select fi_ID from tb_Order where " + m_strWhere + " order by fi_ID desc limit 0, " + PreviousPageOffSet + ")" +
                    " order by fi_ID desc limit 0, " + PageSize;
        }

        QueryEntity result = CDBHelper.getInstance().QueryWithCount(strSql);
        if (!result.hasData) { lbCurrentPage.setText("0"); return ; } 
        
        lbCurrentPage.setText(String.valueOf(CurrentPageIndex));
        Object[][] rowData = JTableData.resultSetToObjectArray(result, "开箱");
        JTableData.setData(tableData, rowData, columnNames, columnIndex, this);
    }

    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnFirstPage;
    private javax.swing.JButton btnLastPage;
    private javax.swing.JButton btnNextPage;
    private javax.swing.JButton btnPreStep;
    private javax.swing.JButton btnPrevPage;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lbCurrentPage;
    private javax.swing.JLabel lbTotalPage;
    private javax.swing.JLabel lblSeconds;
    private javax.swing.JLabel lblSpace;
    private javax.swing.JLabel lblTimeOut1;
    private javax.swing.JLabel lblTimeOut2;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JTable tableData;
    // End of variables declaration//GEN-END:variables

    @Override
    public void invoke(ActionEvent e) {
        JTableButton button = (JTableButton)e.getSource();
        int row = button.getRow();
        String ddbh = String.valueOf(tableData.getValueAt(row, 0)); 
        JumpPwdInput(ddbh);
    }
}

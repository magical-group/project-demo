package UI;

import java.awt.Graphics;
import javax.swing.ImageIcon;

public class frmMsg extends javax.swing.JPanel {

    public frmMsg() {
        initComponents();
    }
    
    @Override
    public void paintComponent(Graphics g){
        ImageIcon icon = new ImageIcon(getClass().getResource(FuncClass.CDataMgr.BackImg));
        g.drawImage(icon.getImage(), 0, 0, getSize().width, getSize().height, this);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        lblTipMsg = new javax.swing.JLabel();
        lblTipMsg1 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(6, 57, 104));

        lblTitle.setFont(new java.awt.Font("微软雅黑", 0, 36)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setText("系统消息提示");

        lblTipMsg.setBackground(new java.awt.Color(255, 0, 0));
        lblTipMsg.setFont(new java.awt.Font("微软雅黑", 0, 30)); // NOI18N
        lblTipMsg.setForeground(new java.awt.Color(255, 255, 255));
        lblTipMsg.setText("检测到系统掉电,系统将停止使用!");

        lblTipMsg1.setBackground(new java.awt.Color(255, 0, 0));
        lblTipMsg1.setFont(new java.awt.Font("微软雅黑", 0, 30)); // NOI18N
        lblTipMsg1.setForeground(new java.awt.Color(255, 255, 255));
        lblTipMsg1.setText("来电后系统将自动切换回待机界面... ");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(100, 100, 100)
                        .addComponent(lblTitle))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(227, 227, 227)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblTipMsg1, javax.swing.GroupLayout.PREFERRED_SIZE, 529, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblTipMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 467, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(268, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addComponent(lblTitle)
                .addGap(212, 212, 212)
                .addComponent(lblTipMsg)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTipMsg1)
                .addContainerGap(331, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel lblTipMsg;
    private javax.swing.JLabel lblTipMsg1;
    private javax.swing.JLabel lblTitle;
    // End of variables declaration//GEN-END:variables
}

package UI;

import java.awt.Graphics;
import javax.swing.ImageIcon;
import FuncClass.CCommondFunc;
import FuncClass.CDataMgr;
import txt.CTxtHelp;

public class frmPackageGetResult extends javax.swing.JPanel {
    CBoxProperty property;
    CFormPassParam param;
    boolean DoIng = false;
    
    public frmPackageGetResult() {
        initComponents();
    }
    
    @Override
    public void paintComponent(Graphics g){
        ImageIcon icon = new ImageIcon(getClass().getResource(CDataMgr.BackImg));
        g.drawImage(icon.getImage(), 0, 0, getSize().width, getSize().height, this);
    }
    
    void ClearData() {
        btnSuccess.setVisible(false);
    }
    
    void VoiceTip() {
        CCommondFunc.VoiceTip(lblTipMsg1.getText() + lblTipMsg2.getText());
    }
    
    public void TTkeyBoardInput(CBaseEnum.KeyType eKeyType, String strInput) {
        if (DoIng) return;
        FuncClass.CBaseTime.ReSetTime();// 重新计时
        
        switch (eKeyType)
        {
            case Key_NUMBER:
                switch (strInput) {
                    case "0": if (btnSuccess.isVisible()) btnSuccessActionPerformed(null); break;
                    case "1": if (btnReOpen.isVisible()) btnReOpenActionPerformed(null); break;
                }
                break;
        }
    }
        
    public void BeginForm(CBaseEnum.RedirectType eRedirectType, Object oParam) {
        if (DoIng) return;
        FuncClass.CBaseTime.StartTime(lblSeconds, 60);
        
        if (eRedirectType != CBaseEnum.RedirectType.Redirect_Pre) {
            ClearData();
            param = (CFormPassParam)oParam;
            property = (CBoxProperty)param.GetParam();
            ShowTipMsg(property.BoxID, property.Result, property.Error);
            VoiceTip();
        }
    }
    
    public void ShowTipMsg(String nBoxID, int nType, boolean error) {
        //System.out.println("ShowTipMsg:" + nBoxID + ";nType:" + nType);
        String boxid = CCommondFunc.GetFormatBoxID(nBoxID); // 001

        btnPreStep.setVisible(true);
            
        if (0 == nType)
        {
            btnSuccess.setVisible(true);
            lblTipMsg1.setText("格口[" + boxid + "]开启失败");
            lblTipMsg2.setText("请重开箱门！");
        }
        else if (1 == nType)
        {
            lblTipMsg1.setText("格口[" + boxid + "]开启成功");
            lblTipMsg2.setText("请取出包裹！");
        }
        else if (3 == nType)
        {
            lblTipMsg1.setText("格口[" + boxid + "]已经关闭！");
            lblTipMsg2.setText("");
        }
        else if (4 == nType) 
        {
            lblTipMsg1.setText("格口[" + boxid + "]还有包裹");
            lblTipMsg2.setText("请取出包裹！");
        }
        else if (-1 == nType)
        {
            btnPreStep.setVisible(false);
            lblTipMsg1.setText("格口[" + boxid + "]与格口[" + CCommondFunc.GetFormatBoxID(CDataMgr.CurrentBoxID) + "]不符！");
            lblTipMsg2.setText("");
        }
        
        //CCommondFunc.UpdateBoxFaultStatus(nType, nBoxID);// 取件格口不设置为故障
        
        if (error) ErrorBox("格口[" + boxid + "]错误关闭", "请确认并关好格口[" + CCommondFunc.GetFormatBoxID(CDataMgr.CurrentBoxID) + "]！");

        CTxtHelp.AppendLog("[UI] " + lblTipMsg1.getText() + lblTipMsg2.getText());
        
        VoiceTip();
    }
    
    public void ErrorBox(String msg1, String msg2) {
        btnSuccess.setVisible(false);
        lblTipMsg1.setText(msg1);
        lblTipMsg2.setText(msg2);
        VoiceTip();
    }
     
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        lblTimeOut1 = new javax.swing.JLabel();
        lblSeconds = new javax.swing.JLabel();
        lblTimeOut2 = new javax.swing.JLabel();
        btnPreStep = new javax.swing.JButton();
        btnSuccess = new javax.swing.JButton();
        btnReOpen = new javax.swing.JButton();
        pnlTipMsg = new javax.swing.JPanel();
        lblTipMsg1 = new javax.swing.JLabel();
        lblTipMsg2 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(6, 57, 104));

        lblTitle.setFont(new java.awt.Font("微软雅黑", 0, 36)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setText("箱门反馈");

        lblTimeOut1.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut1.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut1.setText("执行操作界面还剩");

        lblSeconds.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblSeconds.setForeground(new java.awt.Color(255, 0, 0));
        lblSeconds.setText("60");

        lblTimeOut2.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut2.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut2.setText("秒，即将退出操作返回首页");

        btnPreStep.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/btnBack.png"))); // NOI18N
        btnPreStep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreStepActionPerformed(evt);
            }
        });

        btnSuccess.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/取件成功.png"))); // NOI18N
        btnSuccess.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuccessActionPerformed(evt);
            }
        });

        btnReOpen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/重开箱门.png"))); // NOI18N
        btnReOpen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReOpenActionPerformed(evt);
            }
        });

        lblTipMsg1.setBackground(new java.awt.Color(255, 0, 0));
        lblTipMsg1.setFont(new java.awt.Font("微软雅黑", 0, 30)); // NOI18N
        lblTipMsg1.setForeground(new java.awt.Color(255, 0, 0));
        lblTipMsg1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTipMsg1.setText("格口[000]开启成功");

        lblTipMsg2.setBackground(new java.awt.Color(255, 0, 0));
        lblTipMsg2.setFont(new java.awt.Font("微软雅黑", 0, 30)); // NOI18N
        lblTipMsg2.setForeground(new java.awt.Color(255, 0, 0));
        lblTipMsg2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout pnlTipMsgLayout = new javax.swing.GroupLayout(pnlTipMsg);
        pnlTipMsg.setLayout(pnlTipMsgLayout);
        pnlTipMsgLayout.setHorizontalGroup(
            pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTipMsgLayout.createSequentialGroup()
                .addGap(211, 211, 211)
                .addGroup(pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTipMsg2, javax.swing.GroupLayout.PREFERRED_SIZE, 563, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTipMsg1, javax.swing.GroupLayout.PREFERRED_SIZE, 563, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        pnlTipMsgLayout.setVerticalGroup(
            pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTipMsgLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTipMsg1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblTipMsg2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(100, 100, 100)
                        .addComponent(lblTitle))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(186, 186, 186)
                        .addComponent(btnReOpen, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblTimeOut1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblSeconds)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblTimeOut2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSuccess, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(btnPreStep, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(51, 51, 51))
            .addComponent(pnlTipMsg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addComponent(lblTitle)
                .addGap(179, 179, 179)
                .addComponent(pnlTipMsg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 278, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnReOpen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnSuccess, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnPreStep, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTimeOut1)
                            .addComponent(lblSeconds)
                            .addComponent(lblTimeOut2))
                        .addGap(28, 28, 28))))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnPreStepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreStepActionPerformed
        //CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Normal, "交易开始/结束");
        FuncClass.CCommondFunc.EndOrder();
        CDataMgr.MainHandle.OnEventShowForm(param.GetFormSource(), CBaseEnum.RedirectType.Redirect_Pre, null);
    }//GEN-LAST:event_btnPreStepActionPerformed

    private void btnSuccessActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuccessActionPerformed
        if (DoIng) return;
        DoIng = true;
        CTxtHelp.AppendLog("[UI] 用户取件成功");
        // 取件成功
        switch (property.TriggerType) {
            case CBaseEnum.Lock_DispRevokeOpen:
                // 快递员取货开锁（订单更改+更新格口）
                CLogicHandle.onPackageGetSuccess(CDataMgr.TDYOrderID, CDataMgr.CurrentBoxID, CBaseEnum.Package_RevokeComplete, CBaseEnum.Lock_DispRevokeOpen, property.TriggerID, "快递员取件");
                break;
            case CBaseEnum.Lock_UserOpen:
                // 用户取货开锁（订单更改+更新格口）
                CLogicHandle.onPackageGetSuccess(CDataMgr.UserOrderID, CDataMgr.CurrentBoxID, CBaseEnum.Package_UserTackComplete, CBaseEnum.Lock_UserOpen, property.TriggerID, "用户取件");
                break;
        }
        btnPreStepActionPerformed(null);
        DoIng = false;
    }//GEN-LAST:event_btnSuccessActionPerformed

    private void btnReOpenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReOpenActionPerformed
        if (DoIng) return;
        DoIng = true;
        // 重开箱门(错误重开箱及失败重开箱)
        switch (CDataMgr.CurrentAction) {
            case CBaseEnum.Action_TDYQJ:
                CTxtHelp.AppendLog("[UI] 快递员取回重开箱门");
                CDataMgr.LocalPwdType = 12;
                CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_PwdInput, CBaseEnum.RedirectType.Redirect_Next, property);
                break;
            case CBaseEnum.Action_YHQJ:
                CTxtHelp.AppendLog("[UI] 用户取件重开箱门");
                CDataMgr.LocalPwdType = 11;
                CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_PwdInput, CBaseEnum.RedirectType.Redirect_Next, property);
                break;
            default:
                CTxtHelp.AppendLog("[UI] 取件重开箱门--无效,CurrentAction:" + CDataMgr.CurrentAction);
                break;
        }
        DoIng = false;
    }//GEN-LAST:event_btnReOpenActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnPreStep;
    private javax.swing.JButton btnReOpen;
    private javax.swing.JButton btnSuccess;
    private javax.swing.JLabel lblSeconds;
    private javax.swing.JLabel lblTimeOut1;
    private javax.swing.JLabel lblTimeOut2;
    private javax.swing.JLabel lblTipMsg1;
    private javax.swing.JLabel lblTipMsg2;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JPanel pnlTipMsg;
    // End of variables declaration//GEN-END:variables
}

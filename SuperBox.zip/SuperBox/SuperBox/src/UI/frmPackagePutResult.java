package UI;

import FuncClass.CCommondFunc;
import FuncClass.CDataMgr;
import UI.CBaseEnum.FormCase;
import txt.CTxtHelp;

public class frmPackagePutResult extends javax.swing.JPanel {
    String m_nBoxID;
    CBoxProperty property = null;
    boolean DoIng = false;
    
    public frmPackagePutResult() {
        initComponents();
        
        // 设置控件一加载时候的状态
        btnReOpen.setEnabled(true);
        btnReChangBox.setVisible(false);
        btnSuccess.setVisible(false);
        btnCancel.setVisible(false);
    }
    
    void ClearData() {
        m_nBoxID = "0";
        property = null;
    }
    
    void VoiceTip() {
        CCommondFunc.VoiceTip(lblTipMsg1.getText() + lblTipMsg2.getText());
    }
    
    public void TTkeyBoardInput(CBaseEnum.KeyType eKeyType, String strInput) {
        if (DoIng) return;
        
        FuncClass.CBaseTime.ReSetTime();// 重新计时
        
        switch (eKeyType)
        {
            case Key_NUMBER:
                switch (strInput) {
                    case "1": if (btnReOpen.isEnabled()) btnReOpenActionPerformed(null); break;
                    case "2": if (btnReChangBox.isVisible()) btnReChangBoxActionPerformed(null); break;
                    case "3": if (btnSuccess.isVisible()) btnSuccessActionPerformed(null); break;
                    case "4": if (btnCancel.isVisible()) btnCancelActionPerformed(null); break;
                }
                break;
        }
    }
    
    public void BeginForm(CBaseEnum.RedirectType eRedirectType, Object oParam) {
        if (DoIng) return;
          
        CFormPassParam param = (CFormPassParam)oParam;
        
        // && param.GetFormSource() == FormCase.Form_DeliverStep3//也有可能是投递员关闭了用户取件完未关闭的格口
        if (oParam != null) {
           property = (CBoxProperty)param.GetParam();
           ShowTipMsg(property.BoxID, property.Result, property.Error, property.FaultCount);
        }
        
        FuncClass.CBaseTime.StartTimeWithParam(lblSeconds, 300, 0 , CBaseEnum.FormCase.Form_StandBy, new CFormPassParam(FormCase.Form_PackagePutResult, null, "投递员投件超时:" + lblTipMsg1.getText()));// 重新计时
        
        VoiceTip();
    }
    
    public void ShowTipMsg(String nBoxID, int nType, boolean error, int faultcount) {
        //System.out.println("ShowTipMsg:" + nBoxID + ";nType:" + nType);
        this.m_nBoxID = nBoxID;
        String boxid = CCommondFunc.GetFormatBoxID(this.m_nBoxID); // 001
       
        CBoxProperty temp = CCommondFunc.GetBox1(this.m_nBoxID);
        
        if (0 == nType)
        {
            if (faultcount > 4) {
                lblTipMsg1.setText("格口[" + boxid + "]故障");
                lblTipMsg2.setText("请取消投递！");
                btnReOpen.setEnabled(false);
                btnReChangBox.setVisible(false);
                btnSuccess.setVisible(false);
                btnCancel.setVisible(true);
            }
            else {
                lblTipMsg1.setText("格口[" + boxid + "]开启失败");
                lblTipMsg2.setText("请勿投放包裹！");
                btnReOpen.setEnabled(true);
                btnReChangBox.setVisible(true);
                btnSuccess.setVisible(false);
                btnCancel.setVisible(true);
            }
        }
        else if (1 == nType)
        {
            if (CBaseEnum.BoxStatus.Box_Fault.ordinal() != temp.BoxStatus) {
                btnReOpen.setEnabled(true);
                btnReChangBox.setVisible(true);
                btnSuccess.setVisible(true);
                btnCancel.setVisible(true);
                lblTipMsg1.setText("格口[" + boxid + "]开启成功 ");
                lblTipMsg2.setText("请投递包裹并关好格口！");
            }
            else {
                lblTipMsg1.setText("格口[" + boxid + "]状态异常 ");
                lblTipMsg2.setText("请取消投递！");
                btnReOpen.setEnabled(false);
                btnReChangBox.setVisible(false);
                btnSuccess.setVisible(false);
                btnCancel.setVisible(true);
            }
        }
        else if(2 == nType)
        {
            btnReOpen.setEnabled(true);
            btnReChangBox.setVisible(true);
            btnSuccess.setVisible(true);
            btnCancel.setVisible(true);
            lblTipMsg1.setText("格口[" + boxid + "]没有检测到包裹！");
            lblTipMsg2.setText("");
        }
        
        CCommondFunc.UpdateBoxFaultStatus(nType, this.m_nBoxID);
        
        if (error) ErrorBox("格口[" + boxid + "]错误关闭", "请确认并关好格口[" + CCommondFunc.GetFormatBoxID(CDataMgr.CurrentBoxID) + "]！");
       
        CTxtHelp.AppendLog("[UI] " + lblTipMsg1.getText());
    }
    
    public void ErrorBox(String msg1, String msg2) {
        btnReOpen.setEnabled(true);
        btnReChangBox.setVisible(false);
        btnSuccess.setVisible(false);
        btnCancel.setVisible(false);
        lblTipMsg1.setText(msg1);
        lblTipMsg2.setText(msg2);
        VoiceTip();
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        btnReOpen = new javax.swing.JButton();
        lblTimeOut1 = new javax.swing.JLabel();
        lblSeconds = new javax.swing.JLabel();
        lblTimeOut2 = new javax.swing.JLabel();
        btnReChangBox = new javax.swing.JButton();
        btnSuccess = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        pnlTipMsg = new javax.swing.JPanel();
        lblTipMsg1 = new javax.swing.JLabel();
        lblTipMsg2 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(6, 57, 104));

        lblTitle.setFont(new java.awt.Font("微软雅黑", 0, 36)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setText("箱门反馈");

        btnReOpen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/重开箱门.png"))); // NOI18N
        btnReOpen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReOpenActionPerformed(evt);
            }
        });

        lblTimeOut1.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut1.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut1.setText("执行操作界面还剩");

        lblSeconds.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblSeconds.setForeground(new java.awt.Color(255, 0, 0));
        lblSeconds.setText("300");

        lblTimeOut2.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut2.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut2.setText("秒，即将退出操作返回首页");

        btnReChangBox.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/重选格口.png"))); // NOI18N
        btnReChangBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReChangBoxActionPerformed(evt);
            }
        });

        btnSuccess.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/投递成功.png"))); // NOI18N
        btnSuccess.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuccessActionPerformed(evt);
            }
        });

        btnCancel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/取消投递.png"))); // NOI18N
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });

        lblTipMsg1.setBackground(new java.awt.Color(255, 0, 0));
        lblTipMsg1.setFont(new java.awt.Font("微软雅黑", 0, 30)); // NOI18N
        lblTipMsg1.setForeground(new java.awt.Color(255, 0, 0));
        lblTipMsg1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTipMsg1.setText("格口[001]已经开启 请投递包裹并关好格口");

        lblTipMsg2.setBackground(new java.awt.Color(255, 0, 0));
        lblTipMsg2.setFont(new java.awt.Font("微软雅黑", 0, 30)); // NOI18N
        lblTipMsg2.setForeground(new java.awt.Color(255, 0, 0));
        lblTipMsg2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout pnlTipMsgLayout = new javax.swing.GroupLayout(pnlTipMsg);
        pnlTipMsg.setLayout(pnlTipMsgLayout);
        pnlTipMsgLayout.setHorizontalGroup(
            pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTipMsgLayout.createSequentialGroup()
                .addGap(211, 211, 211)
                .addGroup(pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTipMsg2, javax.swing.GroupLayout.PREFERRED_SIZE, 563, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTipMsg1, javax.swing.GroupLayout.PREFERRED_SIZE, 563, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        pnlTipMsgLayout.setVerticalGroup(
            pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTipMsgLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTipMsg1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblTipMsg2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblTipMsg1.getAccessibleContext().setAccessibleName("");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(100, 100, 100)
                .addComponent(lblTitle)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(btnReOpen, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTimeOut1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblSeconds, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTimeOut2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addComponent(btnReChangBox, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSuccess, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
            .addComponent(pnlTipMsg, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addComponent(lblTitle)
                .addGap(179, 179, 179)
                .addComponent(pnlTipMsg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(278, 278, 278)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnCancel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnReChangBox, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnSuccess, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnReOpen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblSeconds)
                            .addComponent(lblTimeOut2)
                            .addComponent(lblTimeOut1))
                        .addGap(27, 27, 27))))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnReOpenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReOpenActionPerformed
        if (CCommondFunc.txtOrderID_Validated(CDataMgr.TDYOrderID, " and fi_Status=" + CBaseEnum.Package_DeliverComplete, null, 0)) {
            CTxtHelp.AppendLog("[Error] 存在相同的未取订单(普通业务),不允许[重开箱门],订单:" + CDataMgr.TDYOrderID);
            return;
        }
        if (DoIng) return;
        DoIng = true;
        CTxtHelp.AppendLog("[UI] 快递员重开箱门");
        CDataMgr.LocalPwdType = 0;
        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_PwdInput, CBaseEnum.RedirectType.Redirect_Next, property);
        DoIng = false;
    }//GEN-LAST:event_btnReOpenActionPerformed

    private void btnReChangBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReChangBoxActionPerformed
        if (CCommondFunc.txtOrderID_Validated(CDataMgr.TDYOrderID, " and fi_Status=" + CBaseEnum.Package_DeliverComplete, null, 0)) {
            CTxtHelp.AppendLog("[Error] 存在相同的未取订单(普通业务),不允许[重选格口],订单:" + CDataMgr.TDYOrderID);
            return;
        }
        if (DoIng) return;
        DoIng = true;
        CTxtHelp.AppendLog("[UI] 重选格口");
        CDataMgr.LocalPwdType = 1;
        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_PwdInput, CBaseEnum.RedirectType.Redirect_Next, property);
        DoIng = false;
    }//GEN-LAST:event_btnReChangBoxActionPerformed

    private void btnSuccessActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuccessActionPerformed
        if (CCommondFunc.txtOrderID_Validated(CDataMgr.TDYOrderID, " and fi_Status=" + CBaseEnum.Package_DeliverComplete, null, 0)) {
            CTxtHelp.AppendLog("[Error] 存在相同的未取订单(普通业务),不允许[投递成功],订单:" + CDataMgr.TDYOrderID);
            return;
        }
        if (DoIng) return;
        DoIng = true;
        btnReOpen.setEnabled(false); btnReChangBox.setVisible(false); btnSuccess.setVisible(false); btnCancel.setVisible(false);
        // 投递成功(新增订单--无物)
        CLogicHandle.onPackagePutSuccess(m_nBoxID, 0, lblTipMsg1.getText());
        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_DeliverStep1, CBaseEnum.RedirectType.Redirect_Next, null);
        DoIng = false;
    }//GEN-LAST:event_btnSuccessActionPerformed

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        if (CCommondFunc.txtOrderID_Validated(CDataMgr.TDYOrderID, " and fi_Status=" + CBaseEnum.Package_DeliverComplete, null, 0)) {
            CTxtHelp.AppendLog("[Error] 存在相同的未取订单(普通业务),不允许[取消投递],订单:" + CDataMgr.TDYOrderID);
            return;
        }
        if (DoIng) return;
        DoIng = true;
        CTxtHelp.AppendLog("[UI] 取消投递");
        CDataMgr.LocalPwdType = 2;
        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_PwdInput, CBaseEnum.RedirectType.Redirect_Next, property);
        DoIng = false;
    }//GEN-LAST:event_btnCancelActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnReChangBox;
    private javax.swing.JButton btnReOpen;
    private javax.swing.JButton btnSuccess;
    private javax.swing.JLabel lblSeconds;
    private javax.swing.JLabel lblTimeOut1;
    private javax.swing.JLabel lblTimeOut2;
    private javax.swing.JLabel lblTipMsg1;
    private javax.swing.JLabel lblTipMsg2;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JPanel pnlTipMsg;
    // End of variables declaration//GEN-END:variables
}

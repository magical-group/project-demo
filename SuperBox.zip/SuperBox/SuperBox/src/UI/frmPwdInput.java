package UI;

import java.awt.Graphics;
import javax.swing.ImageIcon;
import FuncClass.CCommondFunc;
import FuncClass.CDataMgr;
import HLDClient.CWebApiHandleBase;
import txt.CTxtHelp;

public final class frmPwdInput extends javax.swing.JPanel {
    
    // 动态码输入/本地校验码输入/用户取件密码输入
    int m_len;

    int index = 30;
    
    CBoxProperty property = null;
    boolean m_blNextClick;
    
    public frmPwdInput() {
        initComponents();
        (new Thread(new RunTimeThread())).start();
    }

    @Override
    public void paintComponent(Graphics g){
        ImageIcon icon = new ImageIcon(getClass().getResource(CDataMgr.BackImg));
        g.drawImage(icon.getImage(), 0, 0, getSize().width, getSize().height, this);
    }
    
    void ClearData() {
        txtPwd.Clear(); txtPwd.SetCenter();
        lblTipMsg.setText("...");
        m_blNextClick = false;
        property = null;
    }
    
    void VoiceTip() {
        
    }
    
    void SetTextBox() {
        btnReDTM.setVisible(false);
        btnPreStep.setVisible(true);
        
        // 0:重新开箱;1:重选格口;2:取消投递;3:运单号查询;4:用户重开箱门;5:批量取回逾期件;6:动态码认证;7:快递员异常格口取件(跳过);8:用户异常格口取件(跳过);9:扫一扫中取消投递
        if (CDataMgr.LocalPwdType == 6 || CDataMgr.LocalPwdType == 9 || CDataMgr.LocalPwdType == 10 || CDataMgr.LocalPwdType == 11) {
            m_len = 6;
            txtPwd.SetTextBox(1, m_len);
            index = 30;

            if (CDataMgr.LocalPwdType == 6) {
                btnReDTM.setVisible(true);
                btnReDTM.setEnabled(false);
                btnPreStep.setVisible(false);
                btnExit.setEnabled(true);
                
                FuncClass.CBaseTime.StartTime(lblSeconds, 90);
                
                if (!"".equals(CDataMgr.TDYDTM)) {
                    txtPwd.SetDefaultValue(CDataMgr.TDYDTM);
                    TTkeyBoardInput(CBaseEnum.KeyType.Key_ENTER, "");
                }
            }
            else if (CDataMgr.LocalPwdType == 9 || CDataMgr.LocalPwdType == 10) {
                btnExit.setEnabled(false);
            }
            
            CCommondFunc.VoiceTip("请输入6位校验码");
        }
        else {
            m_len = 4;
            txtPwd.SetTextBox(1, m_len);
            btnPreStep.setVisible(true);
            btnExit.setEnabled(false);
            
            CCommondFunc.VoiceTip("请输入4位校验码");
        }
    }

    class RunTimeThread implements Runnable {
        @Override
        public void run() {
            while (true) {
                if (CDataMgr.LocalPwdType == 6) {
                    btnReDTM.setText("重新获取动态码(" + (index--) +")");
                    if (index <= 0) {
                        btnReDTM.setText("重新获取动态码");
                        btnReDTM.setEnabled(true);
                    }
                }
                try { Thread.sleep(1000); }  catch (InterruptedException e)  {}
            }
        }
    }
     
    public void TTkeyBoardInput(CBaseEnum.KeyType eKeyType, String strInput) {
        if (m_blNextClick) return ;
        
        FuncClass.CBaseTime.ReSetTime();// 重新计时
        
        lblTipMsg.setText("...");
        
        // 按键信息
        switch (eKeyType) {
            case Key_NUMBER:
                txtPwd.InputText(strInput);  
                if (txtPwd.GetText().trim().length() == m_len)  {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            NextStep();
                        }
                    }).start();
                }
                break;
            case Key_SPACE:
                txtPwd.InputText(strInput);
                break;
            case Key_ENTER:
                if (txtPwd.GetText().length() != m_len) 
                    lblTipMsg.setText("格式不正确，请重新输入！");
                else
                    NextStep();
                break;
            case Key_ESC:
                if (btnExit.isEnabled())
                    CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_StandBy, CBaseEnum.RedirectType.Redirect_Null, null);
                break;
        }
    }
    
    // 快递员认证
    public void PacketInput(String content) {
        lblTipMsg.setText(content);// 错误输出
        m_blNextClick = false;
        CCommondFunc.VoiceTip(content);
    }
    
    public void ShowTipMsg(String content) {
        lblTipMsg.setText(content);
        m_blNextClick = false;
        CCommondFunc.VoiceTip(content);
    }
    
    public void BeginForm(CBaseEnum.RedirectType eRedirectType, Object oParam) {
        FuncClass.CBaseTime.StartTime(lblSeconds, 60);
        ClearData();
        SetTextBox();

        if (null != oParam) {
            property = (CBoxProperty)oParam;
        }
        
        SetTime();
    }

    void SetTime() {
        // 0:重新开箱;1:重选格口;2:取消投递;3:运单号查询;4:用户用开箱门;5:批量取回逾期件;6:动态码认证
        int localPwdType = CDataMgr.LocalPwdType;
        if (localPwdType == 0 || localPwdType == 1 || localPwdType == 2 || localPwdType == 5 || localPwdType == 9 || localPwdType == 10) {
            FuncClass.CBaseTime.StartTimeWithParam(lblSeconds, 60, 0 , CBaseEnum.FormCase.Form_StandBy, new CFormPassParam(CBaseEnum.FormCase.Form_PackagePutResult, null, "选择超时"));
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        txtPwd = new CustomControl.TextBoxInput();
        btnExit = new javax.swing.JButton();
        lblTimeOut1 = new javax.swing.JLabel();
        lblSeconds = new javax.swing.JLabel();
        lblTimeOut2 = new javax.swing.JLabel();
        pnlTipMsg = new javax.swing.JPanel();
        lblTipMsg = new javax.swing.JLabel();
        numberKeyPad1 = new CustomControl.NumberKeyPad();
        btnReDTM = new javax.swing.JButton();
        btnPreStep = new javax.swing.JButton();

        setBackground(new java.awt.Color(6, 57, 104));

        lblTitle.setBackground(new java.awt.Color(6, 57, 104));
        lblTitle.setFont(new java.awt.Font("微软雅黑", 0, 36)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setText("密码输入");

        btnExit.setBackground(new java.awt.Color(6, 57, 104));
        btnExit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/btnExit.png"))); // NOI18N
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        lblTimeOut1.setBackground(new java.awt.Color(6, 57, 104));
        lblTimeOut1.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut1.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut1.setText("执行操作界面还剩");

        lblSeconds.setBackground(new java.awt.Color(6, 57, 104));
        lblSeconds.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblSeconds.setForeground(new java.awt.Color(255, 0, 0));
        lblSeconds.setText("60");

        lblTimeOut2.setBackground(new java.awt.Color(6, 57, 104));
        lblTimeOut2.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut2.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut2.setText("秒，即将退出操作返回首页");

        lblTipMsg.setFont(new java.awt.Font("黑体", 0, 24)); // NOI18N
        lblTipMsg.setForeground(new java.awt.Color(255, 0, 0));
        lblTipMsg.setText("...");

        javax.swing.GroupLayout pnlTipMsgLayout = new javax.swing.GroupLayout(pnlTipMsg);
        pnlTipMsg.setLayout(pnlTipMsgLayout);
        pnlTipMsgLayout.setHorizontalGroup(
            pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTipMsgLayout.createSequentialGroup()
                .addGap(186, 186, 186)
                .addComponent(lblTipMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 650, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(178, 178, 178))
        );
        pnlTipMsgLayout.setVerticalGroup(
            pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTipMsgLayout.createSequentialGroup()
                .addComponent(lblTipMsg)
                .addGap(0, 10, Short.MAX_VALUE))
        );

        btnReDTM.setFont(new java.awt.Font("微软雅黑", 1, 18)); // NOI18N
        btnReDTM.setText("重新获取动态码");
        btnReDTM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReDTMActionPerformed(evt);
            }
        });

        btnPreStep.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/btnBack.png"))); // NOI18N
        btnPreStep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreStepActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlTipMsg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(110, 110, 110)
                        .addComponent(lblTitle))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(186, 186, 186)
                        .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblTimeOut1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblSeconds, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblTimeOut2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnPreStep, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(numberKeyPad1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtPwd, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnReDTM, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(339, 339, 339))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addComponent(lblTitle)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 56, Short.MAX_VALUE)
                .addComponent(txtPwd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(numberKeyPad1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnReDTM, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(52, 52, 52)
                .addComponent(pnlTipMsg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(btnPreStep, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnExit, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTimeOut1)
                            .addComponent(lblSeconds)
                            .addComponent(lblTimeOut2))))
                .addGap(15, 15, 15))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        TTkeyBoardInput(CBaseEnum.KeyType.Key_ESC, "");
    }//GEN-LAST:event_btnExitActionPerformed

    private void btnReDTMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReDTMActionPerformed
        // 重新获取动态码
        CWebApiHandleBase.Process6001(CBaseEnum.Auth.Step1);
        btnReDTM.setEnabled(false);
        index = 30;
        FuncClass.CBaseTime.ReSetTime();// 重新计时
    }//GEN-LAST:event_btnReDTMActionPerformed

    private void btnPreStepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreStepActionPerformed
        if (m_blNextClick) { lblTipMsg.setText("请等待操作完成..."); return ; }
        
        CFormPassParam param = new CFormPassParam(CBaseEnum.FormCase.Form_PwdInput, property, "返回");
        
        switch (CDataMgr.LocalPwdType) {
            case 6:break;
            // 重开箱门
            case 0: CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_PackagePutResult, CBaseEnum.RedirectType.Redirect_Pre, param); break;
            // 重选格口
            case 1: CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_PackagePutResult, CBaseEnum.RedirectType.Redirect_Pre, param); break;
            // 取消投递
            case 2: CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_PackagePutResult, CBaseEnum.RedirectType.Redirect_Pre, param); break;
            // 运单号查询
            case 3: CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_DeliverSelect, CBaseEnum.RedirectType.Redirect_Pre, param); break;
//            // 用户用开箱门
//            case 4: CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_PackageGetResult, CBaseEnum.RedirectType.Redirect_Pre, param); break;
            // 批量取回逾期件
            case 5: CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_DeliverTackStep11, CBaseEnum.RedirectType.Redirect_Pre, param); break;
            // 用户取件重开箱门
            case 11: CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_PackageGetResult, CBaseEnum.RedirectType.Redirect_Pre, CBaseEnum.FormCase.Form_PwdInput); break;
            // 快递员取回重开箱门
            case 12: CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_PackageGetResult, CBaseEnum.RedirectType.Redirect_Pre, CBaseEnum.FormCase.Form_PwdInput); break;
        }
    }//GEN-LAST:event_btnPreStepActionPerformed
    
    void BoxDone() {
        lblTipMsg.setText("等待中，请勿操作...");
        CDataMgr.CurrentBoxHasOpen = false;
        CDataMgr.CurrentBoxHasClose = false;
    }
    
    void NextStep() {
        if (m_blNextClick) return;// 防止多次点击
        m_blNextClick = true;
        
        // 0:重新开箱;1:重选格口;2:取消投递;3:运单号查询;4:用户用开箱门;5:批量取回逾期件;6:动态码认证
        switch (CDataMgr.LocalPwdType) {
            case 6:
                btnReDTM.setEnabled(false);
                index = 30;
                lblTipMsg.setText("认证中...");
                if (!CDataMgr.TDYMM.equals(txtPwd.GetText()))
                {
                    PacketInput("6位校验码错误");
                }
                else
                {
                    CWebApiHandleBase.Process6001(CBaseEnum.Auth.Step2);
                }
                break;
            case 0:
                // 重开箱门
                if (Check_TDY()) {
                    if (!property.Error) BoxDone();
                    CCommondFunc.UpdateBoxTrigger(property.BoxID, CBaseEnum.Lock_DispStoreOpen, CDataMgr.TDYPhone);// 更新数据库中触发者类型
                    CLogicHandle.onBoxAction(property.BoxID, CBaseEnum.BoxAction.ReOpen);
                }
                break;
            case 1:
                // 重选格口
                if (Check_TDY()) {
                    BoxDone();
                    CCommondFunc.UpdateBoxTrigger(property.BoxID, CBaseEnum.Lock_DispStoreOpen, CDataMgr.TDYPhone);// 更新数据库中触发者类型
                    CLogicHandle.onBoxAction(property.BoxID, CBaseEnum.BoxAction.ReChoose);
                    CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_DeliverStep3, CBaseEnum.RedirectType.Redirect_Next, new CFormPassParam(CBaseEnum.FormCase.Form_PackagePutResult, property, ""));
                 }
                break;
            case 2:
                // 取消投递
                if (Check_TDY()) {
                    BoxDone();
                    CBoxProperty temp = CCommondFunc.GetBox1(CDataMgr.CurrentBoxID);
                    CCommondFunc.UpdateBox(property.BoxID, CBaseEnum.BoxStatus.Box_Ideal.ordinal(), CBaseEnum.Lock_DispStoreOpen, CDataMgr.TDYPhone, true);
                    CLogicHandle.onBoxAction(property.BoxID, CBaseEnum.BoxAction.Cancle);
                }
                break;
            case 3:
                // 运单号查询
                if (Check_TDY()) {
                    CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_OrderFiler, CBaseEnum.RedirectType.Redirect_Pre, CBaseEnum.FormCase.Form_DeliverSelect);
                }
                break;
            case 4:
                // 用户重开箱门
                if (Check_YH()) {
                    BoxDone();
                    CCommondFunc.UpdateBoxTrigger(property.BoxID, CBaseEnum.Lock_UserOpen, CDataMgr.UserPID);// 更新数据库中触发者类型
                    CLogicHandle.onBoxAction(property.BoxID, CBaseEnum.BoxAction.ReOpen);
                }
                break;
            case 5:
                // 批量取回逾期件
                if (Check_TDY()) {
                    BoxDone();
                    CTxtHelp.AppendLog("[Info] ===============================================================");
                    CTxtHelp.AppendLog("[Info] DeliverTackStep11,OrderID=" + CDataMgr.TDYOrderID);
                    
                    CDataMgr.BatchTake = true;
                    // 更新表tb_Order，逾期取件模式fi_PickUpFlag=2;BGetA
                    String strSql = "update tb_Order set fs_PickUpUid='" +  CDataMgr.TDYPhone + "',fs_PickUpPwd='" + CDataMgr.TDYPwd + "'" +
                                    " where fs_OrderID='" + CDataMgr.TDYOrderID + "' and fi_Status=" + CBaseEnum.Package_DeliverComplete + " and fi_DeviceID=" + CDataMgr.DeviceID;
                    func.CCommondFunc.SyncExecuteSql(strSql);
                    
                    CBoxProperty temp = CCommondFunc.GetOrderBox(CDataMgr.TDYOrderID, "");
                    if (null != temp) {
                        CLogicHandle.OpenBox(temp, CBaseEnum.Lock_DispRevokeOpen, CDataMgr.TDYPhone, CBaseEnum.Action_TDYQJ, "投递员批量取件开箱门");
                    }
                }
                break;
            case 11:
                // 用户取件重开箱门
                if (Check_YH()) {
                    BoxDone();
                    CCommondFunc.UpdateBoxTrigger(property.BoxID, CDataMgr.CurrentTriggerType, CDataMgr.CurrentTriggerID);// 将格口更新为当前操作人类型
                    CLogicHandle.onBoxAction(property.BoxID, CBaseEnum.BoxAction.ReOpen);
               }
               break;
            case 12: 
                // 快递员取回重开箱门
                if (Check_TDY()) {
                    BoxDone();
                    CCommondFunc.UpdateBoxTrigger(property.BoxID, CDataMgr.CurrentTriggerType, CDataMgr.CurrentTriggerID);// 将格口更新为当前操作人类型
                    CLogicHandle.onBoxAction(property.BoxID, CBaseEnum.BoxAction.ReOpen);
                }
                break;
        }
    }
    
    public void ErrorBox(String msg) {
        SetTime();
        lblTipMsg.setText(msg);
        CCommondFunc.VoiceTip(msg);
        m_blNextClick = false;
    }
    
    boolean Check_TDY() {
        if (!CDataMgr.TDYPwd.equals(txtPwd.GetText())) {
            lblTipMsg.setText("密码错误，请重新输入！");
            m_blNextClick = false;
            return false;
        }
        
        lblTipMsg.setText("...");
        return true;
    }
    
    boolean Check_YH() {
       if (!CDataMgr.UserPwd.equals(txtPwd.GetText())) {
           lblTipMsg.setText("密码错误，请重新输入！");
           m_blNextClick = false;
           return false;
       }
       
       lblTipMsg.setText("...");
       return true;
    }
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnPreStep;
    private javax.swing.JButton btnReDTM;
    private javax.swing.JLabel lblSeconds;
    private javax.swing.JLabel lblTimeOut1;
    private javax.swing.JLabel lblTimeOut2;
    private javax.swing.JLabel lblTipMsg;
    private javax.swing.JLabel lblTitle;
    private CustomControl.NumberKeyPad numberKeyPad1;
    private javax.swing.JPanel pnlTipMsg;
    private CustomControl.TextBoxInput txtPwd;
    // End of variables declaration//GEN-END:variables
}

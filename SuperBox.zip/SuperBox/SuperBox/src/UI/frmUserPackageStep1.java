package UI;

import FuncClass.CCommondFunc;
import FuncClass.CDataMgr;
import HLDClient.CWebApiHandleBase;
import java.awt.Graphics;
import javax.swing.ImageIcon;
import txt.CTxtHelp;

public class frmUserPackageStep1 extends javax.swing.JPanel {
    CustomControl.TextBoxInput m_Curtxt;
    String m_CurTabIndex;
    CBoxProperty property = null;
    boolean m_blNextClick = false;
    
    public frmUserPackageStep1() {
        initComponents();
    }
    
    @Override
    public void paintComponent(Graphics g){
        ImageIcon icon = new ImageIcon(getClass().getResource(CDataMgr.BackImg));
        g.drawImage(icon.getImage(), 0, 0, getSize().width, getSize().height, this);
    }
    
    void ClearData() {
        txtUserPID.Clear();
        txtUserPwd.Clear();
        lblTipMsg.setText("...");
        btnBoxError.setVisible(false);
        onNextClickStatus(false);
    }
    
    void VoiceTip(String msg) {
        CCommondFunc.VoiceTip(msg);
    }
    
    void SetTextBox() {
        txtUserPID.SetTextBox(1, 4);
        txtUserPwd.SetTextBox(2, 6);
        m_CurTabIndex = "1";
        m_Curtxt = txtUserPID;
        
        txtUserPID.setFocusable(true);
    }
    
    void onNextClickStatus(boolean flg) {
        m_blNextClick = flg;
        btnExit.setEnabled(!flg);
        btnOrderFilter.setEnabled(!flg);
        btnYCXZ.setEnabled(!flg);
    }

    public void TTkeyBoardInput(CBaseEnum.KeyType eKeyType, String strInput) {
        if (m_blNextClick) return ;
        
        FuncClass.CBaseTime.ReSetTime();// 重新计时
        
        if (eKeyType == CBaseEnum.KeyType.Key_TEXTBOX_FORCECHANGE || eKeyType == CBaseEnum.KeyType.Key_UP || eKeyType == CBaseEnum.KeyType.Key_DOWN) {
            AutoChangeForce(strInput); // 手动进行光标切换
        }
        else {
            // 按键信息
            switch (eKeyType) {
                case Key_BarCode:
                    //AnalysCode(strInput);
                    break;
                case Key_NUMBER:
                    if ("1".equals(m_CurTabIndex)) {
                        if (txtUserPID.GetText().trim().length() == 4) {
                            m_CurTabIndex = "2";
                            m_Curtxt = txtUserPwd;// 验证通过自动跳转到下个文本框
                        }
                    }
                    m_Curtxt.InputText(strInput);
                    if ("2".equals(m_CurTabIndex)) {
                        if (txtUserPID.GetText().trim().length() == 4 && txtUserPwd.GetText().trim().length() == 6 && null != CheckOrder()) {
                            NextStep();// 验证通过自动调用下一步
                        }
                    }
                    break;
                case Key_SPACE:
                    m_Curtxt.InputText(strInput);
                    if ("2".equals(m_CurTabIndex) && "".equals(txtUserPwd.GetText())) {
                        AutoChangeForce("1");// 焦点自动切换回上一个文本框
                    }
                    break;
                case Key_ENTER:
                    if (txtUserPID.GetText().trim().length() == 4 && txtUserPwd.GetText().trim().length() == 6 && null != CheckOrder()) {
                        NextStep();// 验证通过自动调用下一步
                    }
                    break;
                case Key_ESC:
                    CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_StandBy, CBaseEnum.RedirectType.Redirect_Null, null);
                    break;
            }
        }
    }
    
    void AutoChangeForce(String strInput) {
        m_CurTabIndex = strInput;
            
        switch (m_CurTabIndex) {
            case "1": m_Curtxt = txtUserPID; break;
            case "2": m_Curtxt = txtUserPwd; break;
            case CBaseEnum.PIN_PRESSED_UP:
            case CBaseEnum.PIN_PRESSED_DOWN:
                if (m_Curtxt == txtUserPID) {
                    m_CurTabIndex = "2"; m_Curtxt = txtUserPwd;
                }
                else {
                    m_CurTabIndex = "1"; m_Curtxt = txtUserPID;
                }
                break;
        }
        
        m_Curtxt.SetCursor();
    }
     
//    public void PacketInput(int code, String content) {
//        lblTipMsg.setText(content);// 错误输出
//        if (-1 == code) {
//            CTxtHelp.AppendLog("[Info] 网络超时,用户离线取件");
//            OpenBox();
//        }
//        else {
//            onNextClickStatus(false);
//        }
//    }
    
    public void BeginForm(CBaseEnum.RedirectType eRedirectType, Object oParam) {
        CSystemDAO.getInstance().OpenBarCode();
        ClearData();
        SetTextBox();
        FuncClass.CBaseTime.StartTime(lblSeconds, 60);
        VoiceTip("请输入用户取件信息");
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        btnExit = new javax.swing.JButton();
        lblTimeOut1 = new javax.swing.JLabel();
        lblSeconds = new javax.swing.JLabel();
        lblTimeOut2 = new javax.swing.JLabel();
        lblDelieverPhone = new javax.swing.JLabel();
        txtUserPID = new CustomControl.TextBoxInput();
        lblDelieverPwd = new javax.swing.JLabel();
        txtUserPwd = new CustomControl.TextBoxInput();
        numberKeyPad1 = new CustomControl.NumberKeyPad();
        pnlTipMsg = new javax.swing.JPanel();
        lblTipMsg = new javax.swing.JLabel();
        btnOrderFilter = new javax.swing.JButton();
        btnBoxError = new javax.swing.JButton();
        btnYCXZ = new javax.swing.JButton();

        setBackground(new java.awt.Color(6, 57, 104));
        setPreferredSize(new java.awt.Dimension(1024, 768));

        lblTitle.setFont(new java.awt.Font("微软雅黑", 0, 36)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setText("用户登录");

        btnExit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/btnExit.png"))); // NOI18N
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        lblTimeOut1.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut1.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut1.setText("执行操作界面还剩");

        lblSeconds.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblSeconds.setForeground(new java.awt.Color(255, 0, 0));
        lblSeconds.setText("60");

        lblTimeOut2.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut2.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut2.setText("秒，即将退出操作返回首页");

        lblDelieverPhone.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblDelieverPhone.setForeground(new java.awt.Color(255, 255, 255));
        lblDelieverPhone.setText("手机号后4位:");

        lblDelieverPwd.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblDelieverPwd.setForeground(new java.awt.Color(255, 255, 255));
        lblDelieverPwd.setText("6位密码:");

        lblTipMsg.setFont(new java.awt.Font("黑体", 0, 24)); // NOI18N
        lblTipMsg.setForeground(new java.awt.Color(255, 0, 0));
        lblTipMsg.setText("...");

        javax.swing.GroupLayout pnlTipMsgLayout = new javax.swing.GroupLayout(pnlTipMsg);
        pnlTipMsg.setLayout(pnlTipMsgLayout);
        pnlTipMsgLayout.setHorizontalGroup(
            pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTipMsgLayout.createSequentialGroup()
                .addGap(186, 186, 186)
                .addComponent(lblTipMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 650, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pnlTipMsgLayout.setVerticalGroup(
            pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTipMsgLayout.createSequentialGroup()
                .addComponent(lblTipMsg)
                .addGap(0, 10, Short.MAX_VALUE))
        );

        btnOrderFilter.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/查询订单1.png"))); // NOI18N
        btnOrderFilter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOrderFilterActionPerformed(evt);
            }
        });

        btnBoxError.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/异常格口1.png"))); // NOI18N
        btnBoxError.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBoxErrorActionPerformed(evt);
            }
        });

        btnYCXZ.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/远程协助.png"))); // NOI18N
        btnYCXZ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnYCXZActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlTipMsg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(186, 186, 186)
                        .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblTimeOut1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblSeconds, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblTimeOut2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnOrderFilter, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(252, 252, 252)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblDelieverPhone)
                            .addComponent(lblDelieverPwd, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtUserPID, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtUserPwd, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(numberKeyPad1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(110, 110, 110)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnBoxError, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnYCXZ, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(88, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 448, Short.MAX_VALUE)
                .addComponent(lblTitle)
                .addGap(432, 432, 432))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addComponent(lblTitle)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 69, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(lblDelieverPhone)
                        .addGap(28, 28, 28)
                        .addComponent(lblDelieverPwd))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtUserPID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13)
                        .addComponent(txtUserPwd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnYCXZ, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnBoxError, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(numberKeyPad1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 60, Short.MAX_VALUE)
                .addComponent(pnlTipMsg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnOrderFilter, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTimeOut1)
                            .addComponent(lblSeconds)
                            .addComponent(lblTimeOut2))))
                .addGap(15, 15, 15))
        );

        lblSeconds.getAccessibleContext().setAccessibleName("");
    }// </editor-fold>//GEN-END:initComponents

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_StandBy, CBaseEnum.RedirectType.Redirect_Null, null);
    }//GEN-LAST:event_btnExitActionPerformed

    private void btnOrderFilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOrderFilterActionPerformed
        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_OrderFiler, CBaseEnum.RedirectType.Redirect_Next, CBaseEnum.FormCase.Form_UserPackageStep1);
    }//GEN-LAST:event_btnOrderFilterActionPerformed

    private void btnBoxErrorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBoxErrorActionPerformed
        CTxtHelp.AppendLog("[Info] 用户异常格口取件");
        CDataMgr.UserPID = txtUserPID.GetText();
        CDataMgr.UserPwd = txtUserPwd.GetText();
        CDataMgr.LocalPwdType = 8;
        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_BoxError, CBaseEnum.RedirectType.Redirect_Next, null);// 已经校验过
    }//GEN-LAST:event_btnBoxErrorActionPerformed

    private void btnYCXZActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnYCXZActionPerformed
        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_YCXZ, CBaseEnum.RedirectType.Redirect_Next, null);
    }//GEN-LAST:event_btnYCXZActionPerformed
    
    void NextStep() {
        onNextClickStatus(true);
        
        lblTipMsg.setText("更新中...");
        
        CTxtHelp.AppendLog("[Info] ===============================================================");
        CTxtHelp.AppendLog("[Info] UserPackageStep1,pid=" + txtUserPID.GetText() + ",pwd=" + txtUserPwd.GetText());
        CDataMgr.UserPID = txtUserPID.GetText();
        CDataMgr.UserPwd = txtUserPwd.GetText();
        
        OpenBox();
    }
    
    CBoxProperty CheckOrder(){
        property = CCommondFunc.UserCheckOrder(txtUserPID.GetText(), txtUserPwd.GetText(), lblTipMsg);
        if (null != property) CDataMgr.UserOrderID = property.OrderID;
        return property;
    }

    void OpenBox() {
        if (property != null) {
            if (CBaseEnum.FormCase.Form_UserPackageStep1 == CDataMgr.MainHandle.GetCurFormCase()) {
                CLogicHandle.OpenBox(property, CBaseEnum.Lock_UserOpen, CDataMgr.UserPID, CBaseEnum.Action_YHQJ, "用户取件开箱门");
            }
        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBoxError;
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnOrderFilter;
    private javax.swing.JButton btnYCXZ;
    private javax.swing.JLabel lblDelieverPhone;
    private javax.swing.JLabel lblDelieverPwd;
    private javax.swing.JLabel lblSeconds;
    private javax.swing.JLabel lblTimeOut1;
    private javax.swing.JLabel lblTimeOut2;
    private javax.swing.JLabel lblTipMsg;
    private javax.swing.JLabel lblTitle;
    private CustomControl.NumberKeyPad numberKeyPad1;
    private javax.swing.JPanel pnlTipMsg;
    private CustomControl.TextBoxInput txtUserPID;
    private CustomControl.TextBoxInput txtUserPwd;
    // End of variables declaration//GEN-END:variables
}

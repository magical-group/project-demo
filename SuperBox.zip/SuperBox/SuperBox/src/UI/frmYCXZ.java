package UI;

import FuncClass.CCommondFunc;
import FuncClass.CDataMgr;
import HLDClient.CWebApiHandleBase;
import static UI.CBaseEnum.KeyType.Key_BarCode;
import java.awt.Graphics;
import javax.swing.ImageIcon;
import txt.CTxtHelp;

public class frmYCXZ extends javax.swing.JPanel {
    
    CustomControl.TextBoxInput m_Curtxt;
    String m_CurTabIndex;
    boolean m_blNextClick = false;
    String ddbh = "";
    int ddzt = 0;// 协助类型
    String m_dtm = "";
    int gkbh = 0;
    
    public frmYCXZ() {
        initComponents();
    }
    
    @Override
    public void paintComponent(Graphics g){
        ImageIcon icon = new ImageIcon(getClass().getResource(CDataMgr.BackImg));
        g.drawImage(icon.getImage(), 0, 0, getSize().width, getSize().height, this);
    }
    
    void ClearData() {
        txtDDH.Clear();
        txtQJSJ.Clear();
        txtDTM.Clear();
        txtKXM.Clear();
        lblTipMsg.setText("...");
        lblKXM.setVisible(false);
        txtKXM.setVisible(false);
        btnKG.setVisible(false);
        ddbh = "";
        m_blNextClick = false;
        ddzt = 0;
        m_dtm = "";
        gkbh = 0;
    }
    
    void VoiceTip() {
        CCommondFunc.VoiceTip("请输入远程协助信息");
    }
    
    void SetTextBox() {
        txtDDH.SetTextBox(1, 20); 
        txtQJSJ.SetTextBox(2, 11); 
        txtDTM.SetTextBox(3, 6); 
        txtKXM.SetTextBox(4, 6); 
        
        m_CurTabIndex = "1";
        m_Curtxt = txtDDH;
        txtDDH.setFocusable(true);
    }
    
    void AutoChangeForce(String strInput) {
        m_CurTabIndex = strInput;
            
        switch (m_CurTabIndex) {
            case "1": m_Curtxt = txtDDH; break;
            case "2": m_Curtxt = txtQJSJ; break;
            case "3": m_Curtxt = txtDTM; break;
            case "4": m_Curtxt = txtKXM; break;
            case CBaseEnum.PIN_PRESSED_UP:
            case CBaseEnum.PIN_PRESSED_DOWN:
                if (m_Curtxt == txtDDH) {
                    m_CurTabIndex = "2"; m_Curtxt = txtQJSJ;
                }
                else if(m_Curtxt == txtQJSJ) {
                    m_CurTabIndex = "3"; m_Curtxt = txtDTM;
                }
                else if(m_Curtxt == txtDTM) {
                    m_CurTabIndex = "4"; m_Curtxt = txtKXM;
                }
                else if(m_Curtxt == txtKXM) {
                    m_CurTabIndex = "1"; m_Curtxt = txtDDH;
                }
                break;
        }
        
        m_Curtxt.SetCursor();
    }
    
    public void TTkeyBoardInput(CBaseEnum.KeyType eKeyType, String strInput) {
        FuncClass.CBaseTime.ReSetTime();// 重新计时
        
        if (eKeyType == CBaseEnum.KeyType.Key_TEXTBOX_FORCECHANGE || eKeyType == CBaseEnum.KeyType.Key_UP || eKeyType == CBaseEnum.KeyType.Key_DOWN) {
            AutoChangeForce(strInput);// 手动进行光标切换
        }
        else {
            // 按键信息
            switch (eKeyType) {
                case Key_BarCode:
                    txtDDH.SetDefaultValue(strInput);
                    break;
                case Key_NUMBER:
                    m_Curtxt.InputText(strInput);
                    break;
                case Key_SPACE:
                    m_Curtxt.InputText(strInput);
                    break;
                case Key_ESC:
                    CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_StandBy, CBaseEnum.RedirectType.Redirect_Null, null);
                    break;
            }
        }
    }
    
    public void BeginForm(CBaseEnum.RedirectType eRedirectType, Object oParam) {
        if (eRedirectType != CBaseEnum.RedirectType.Redirect_Pre) {
            ClearData();
        }
        
        FuncClass.CBaseTime.StartTime(lblSeconds, 180);
        CDataMgr.AllKeyPadHandle = zTKeyPad1;// 加载全键盘
        SetTextBox();
        ClearData();
        VoiceTip();
        
        if (CDataMgr.IsTDY == false) {
            ddzt = CBaseEnum.Package_UserTackComplete;
            lblDTM.setVisible(true);
            txtDTM.setVisible(true);
            lblXYLX.setText("[用户] 取件后误关箱门");
        }
        else {
            ddzt = CBaseEnum.Package_RevokeComplete;
            lblDTM.setVisible(false);
            txtDTM.setVisible(false);
            lblXYLX.setText("[快递员] 确认回收后误关箱门");
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        btnExit = new javax.swing.JButton();
        lblTimeOut1 = new javax.swing.JLabel();
        lblSeconds = new javax.swing.JLabel();
        lblTimeOut2 = new javax.swing.JLabel();
        btnPreStep = new javax.swing.JButton();
        zTKeyPad1 = new CustomControl.ZTKeyPad();
        pnlTipMsg = new javax.swing.JPanel();
        lblTipMsg = new javax.swing.JLabel();
        lblDDH = new javax.swing.JLabel();
        txtDDH = new CustomControl.TextBoxInput();
        lblQJSJ = new javax.swing.JLabel();
        txtQJSJ = new CustomControl.TextBoxInput();
        lblXYLX1 = new javax.swing.JLabel();
        lblXYLX = new javax.swing.JLabel();
        pnlKXM = new javax.swing.JPanel();
        lblKXM = new javax.swing.JLabel();
        txtKXM = new CustomControl.TextBoxInput();
        btnKG = new javax.swing.JButton();
        lblDTM = new javax.swing.JLabel();
        txtDTM = new CustomControl.TextBoxInput();
        btnYCXZ = new javax.swing.JButton();

        setBackground(new java.awt.Color(6, 57, 104));

        lblTitle.setBackground(new java.awt.Color(6, 57, 104));
        lblTitle.setFont(new java.awt.Font("微软雅黑", 0, 36)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setText("远程协助");

        btnExit.setBackground(new java.awt.Color(6, 57, 104));
        btnExit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/btnExit.png"))); // NOI18N
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        lblTimeOut1.setBackground(new java.awt.Color(6, 57, 104));
        lblTimeOut1.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut1.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut1.setText("执行操作界面还剩");

        lblSeconds.setBackground(new java.awt.Color(6, 57, 104));
        lblSeconds.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblSeconds.setForeground(new java.awt.Color(255, 0, 0));
        lblSeconds.setText("60");

        lblTimeOut2.setBackground(new java.awt.Color(6, 57, 104));
        lblTimeOut2.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut2.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut2.setText("秒，即将退出操作返回首页");

        btnPreStep.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/btnBack.png"))); // NOI18N
        btnPreStep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreStepActionPerformed(evt);
            }
        });

        lblTipMsg.setFont(new java.awt.Font("黑体", 0, 24)); // NOI18N
        lblTipMsg.setForeground(new java.awt.Color(255, 0, 0));
        lblTipMsg.setText("...");

        javax.swing.GroupLayout pnlTipMsgLayout = new javax.swing.GroupLayout(pnlTipMsg);
        pnlTipMsg.setLayout(pnlTipMsgLayout);
        pnlTipMsgLayout.setHorizontalGroup(
            pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTipMsgLayout.createSequentialGroup()
                .addGap(186, 186, 186)
                .addComponent(lblTipMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 650, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pnlTipMsgLayout.setVerticalGroup(
            pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTipMsgLayout.createSequentialGroup()
                .addComponent(lblTipMsg)
                .addGap(0, 10, Short.MAX_VALUE))
        );

        lblDDH.setBackground(new java.awt.Color(6, 57, 104));
        lblDDH.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblDDH.setForeground(new java.awt.Color(255, 255, 255));
        lblDDH.setText("运单号");

        lblQJSJ.setBackground(new java.awt.Color(6, 57, 104));
        lblQJSJ.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblQJSJ.setForeground(new java.awt.Color(255, 255, 255));
        lblQJSJ.setText("取件手机号");

        lblXYLX1.setBackground(new java.awt.Color(6, 57, 104));
        lblXYLX1.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblXYLX1.setForeground(new java.awt.Color(255, 255, 255));
        lblXYLX1.setText("协助类型");

        lblXYLX.setBackground(new java.awt.Color(6, 57, 104));
        lblXYLX.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblXYLX.setForeground(new java.awt.Color(255, 255, 255));
        lblXYLX.setText("取消投递后误关箱门");

        pnlKXM.setBackground(new java.awt.Color(6, 57, 104));

        lblKXM.setBackground(new java.awt.Color(6, 57, 104));
        lblKXM.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblKXM.setForeground(new java.awt.Color(255, 255, 255));
        lblKXM.setText("开箱码");

        btnKG.setFont(new java.awt.Font("微软雅黑", 1, 18)); // NOI18N
        btnKG.setText("确定");
        btnKG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKGActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlKXMLayout = new javax.swing.GroupLayout(pnlKXM);
        pnlKXM.setLayout(pnlKXMLayout);
        pnlKXMLayout.setHorizontalGroup(
            pnlKXMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlKXMLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblKXM)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txtKXM, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnKG, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50))
        );
        pnlKXMLayout.setVerticalGroup(
            pnlKXMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlKXMLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblKXM)
                .addContainerGap(17, Short.MAX_VALUE))
            .addGroup(pnlKXMLayout.createSequentialGroup()
                .addGroup(pnlKXMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(btnKG, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtKXM, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        lblDTM.setBackground(new java.awt.Color(6, 57, 104));
        lblDTM.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblDTM.setForeground(new java.awt.Color(255, 255, 255));
        lblDTM.setText("取件密码");

        btnYCXZ.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/远程协助.png"))); // NOI18N
        btnYCXZ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnYCXZActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlTipMsg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(zTKeyPad1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 23, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(186, 186, 186)
                        .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblTimeOut1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblSeconds)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblTimeOut2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnPreStep, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(100, 100, 100)
                        .addComponent(lblTitle))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(162, 162, 162)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblXYLX1)
                                    .addComponent(lblDDH))
                                .addGap(34, 34, 34)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblXYLX)
                                    .addComponent(txtDDH, javax.swing.GroupLayout.PREFERRED_SIZE, 641, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblDTM)
                                    .addComponent(lblQJSJ))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtQJSJ, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtDTM, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(pnlKXM, javax.swing.GroupLayout.PREFERRED_SIZE, 372, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnYCXZ, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addComponent(lblTitle)
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblXYLX)
                    .addComponent(lblXYLX1))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtDDH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblDDH)
                        .addGap(18, 18, 18)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(pnlKXM, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(3, 3, 3)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(9, 9, 9)
                                .addComponent(lblDTM))
                            .addComponent(btnYCXZ, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(14, 14, 14))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblQJSJ)
                            .addComponent(txtQJSJ, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtDTM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(zTKeyPad1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlTipMsg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnPreStep, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnExit, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTimeOut1)
                            .addComponent(lblSeconds)
                            .addComponent(lblTimeOut2))
                        .addGap(13, 13, 13)))
                .addGap(15, 15, 15))
        );

        lblTitle.getAccessibleContext().setAccessibleName("");
        lblXYLX1.getAccessibleContext().setAccessibleName("");
    }// </editor-fold>//GEN-END:initComponents

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        TTkeyBoardInput(CBaseEnum.KeyType.Key_ESC, "");
    }//GEN-LAST:event_btnExitActionPerformed

    private void btnPreStepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreStepActionPerformed
        if (CDataMgr.IsTDY == false) 
            CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_UserPackageStep1, CBaseEnum.RedirectType.Redirect_Next, null);
        else
            CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_DeliverSelect, CBaseEnum.RedirectType.Redirect_Next, null);
    }//GEN-LAST:event_btnPreStepActionPerformed

    private void btnYCXZActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnYCXZActionPerformed
        if (CDataMgr.IsTDY) {
            if (!Phone_Validated()) return;
        }
        else {
            if (!CCommondFunc.Data_Validated(txtDTM, lblTipMsg, "动态码")) return;
        }
        
        if (!OrderID_Validated()) return;
        
        NextStep();
    }//GEN-LAST:event_btnYCXZActionPerformed

    private void btnKGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKGActionPerformed
        // 开箱
        if (!CCommondFunc.Data_Validated(txtKXM, lblTipMsg, "开箱码")) return;
        if (!m_dtm.equals(CCommondFunc.GetMD5(txtKXM.GetText().trim()))) { lblTipMsg.setText("开箱码错误"); return; }

        CBoxProperty property = CCommondFunc.GetBox1(String.valueOf(gkbh));
        CLogicHandle.OpenBox(property, CBaseEnum.Lock_YCXZOpen, "YCXZ", CBaseEnum.Action_YCXZQJ, "远程协助");
    }//GEN-LAST:event_btnKGActionPerformed
    
    boolean OrderID_Validated() {
        boolean ret = false;
        ddbh = CCommondFunc.OrderID_Deal(txtDDH.GetText().trim());
        String strWhere = " and fi_Status=" + ddzt;
        if (CDataMgr.IsTDY) {
            ret = CCommondFunc.txtOrderID_Validated(ddbh, " and fs_Phone='" + txtQJSJ.GetText().trim() + "'" + strWhere, lblTipMsg, 1);
        }
        else {
            ret = CCommondFunc.txtOrderID_Validated(ddbh, " and fs_QJMM='" + CCommondFunc.GetMD5(txtDTM.GetText().trim()) + "'" + strWhere, lblTipMsg, 1);
        }
        
        return  ret;
    }
        
    boolean Phone_Validated() {
        return CCommondFunc.Phone_Validated(txtQJSJ.GetText(), lblTipMsg, "取件手机号");
    }
    
    void NextStep() {
        CTxtHelp.AppendLog("[Info] ===============================================================");
        CTxtHelp.AppendLog("[Info] YCXZ");
        
        gkbh = CCommondFunc.GetBoxID_YCXZ(ddbh, ddzt);
        lblTipMsg.setText("发送中...");
        m_blNextClick = true;
        CWebApiHandleBase.Process6004(ddbh, gkbh, ddzt, txtQJSJ.GetText().trim(), txtDTM.GetText().trim());
    }
    
    public void ShowTipMsg(String content) {
        lblTipMsg.setText(content);
        CCommondFunc.VoiceTip(content);
    }
    
    public void PacketInput(String err, String dtm) {
        m_blNextClick = false;
        
        if (!"".equals(err)) {
            lblTipMsg.setText("远程协助错误:" + err);// 错误输出
        }
        else {
            m_dtm = dtm;
            lblTipMsg.setText("远程协助成功:" + CCommondFunc.GetFormatBoxID(String.valueOf(gkbh)) + ",请和客服人员联系:000-000-0000");
            lblKXM.setVisible(true);
            txtKXM.setVisible(true);
            btnKG.setVisible(true);
        }
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnKG;
    private javax.swing.JButton btnPreStep;
    private javax.swing.JButton btnYCXZ;
    private javax.swing.JLabel lblDDH;
    private javax.swing.JLabel lblDTM;
    private javax.swing.JLabel lblKXM;
    private javax.swing.JLabel lblQJSJ;
    private javax.swing.JLabel lblSeconds;
    private javax.swing.JLabel lblTimeOut1;
    private javax.swing.JLabel lblTimeOut2;
    private javax.swing.JLabel lblTipMsg;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblXYLX;
    private javax.swing.JLabel lblXYLX1;
    private javax.swing.JPanel pnlKXM;
    private javax.swing.JPanel pnlTipMsg;
    private CustomControl.TextBoxInput txtDDH;
    private CustomControl.TextBoxInput txtDTM;
    private CustomControl.TextBoxInput txtKXM;
    private CustomControl.TextBoxInput txtQJSJ;
    private CustomControl.ZTKeyPad zTKeyPad1;
    // End of variables declaration//GEN-END:variables
}
